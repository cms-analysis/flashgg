import FWCore.ParameterSet.Config as cms

process = cms.Process("FLASHggSyst")

process.source = cms.Source("PoolSource",
    fileNames = cms.untracked.vstring(
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_201.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_202.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_203.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_204.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_205.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_206.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_207.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_208.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_209.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_210.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_211.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_212.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_213.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_214.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_215.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_216.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_217.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_218.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_219.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_220.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_221.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_222.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_223.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_224.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_225.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_226.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_227.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_228.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_229.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_230.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_232.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_233.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_234.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_235.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_236.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_237.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_238.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_239.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_240.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_241.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_242.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_243.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_244.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_245.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_246.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_247.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_248.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_249.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_250.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_251.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_252.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_253.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_254.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_255.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_256.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_257.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_258.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_259.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_260.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_261.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_262.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_263.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_264.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_265.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_266.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_267.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_269.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_270.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_271.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_272.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_273.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_274.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_275.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_276.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_277.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_278.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_279.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_281.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_282.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_283.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_284.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_285.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_286.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_287.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_288.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_289.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_290.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_291.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_292.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_293.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_294.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_295.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_296.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_297.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_298.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_299.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_300.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_301.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_302.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_303.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_304.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_305.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_306.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_307.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_308.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_309.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_310.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_311.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_312.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_313.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_314.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_315.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_316.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_317.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_318.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_319.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_320.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_321.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_322.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_323.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_324.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_325.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_326.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_327.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_329.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_330.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_331.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_332.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_333.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_334.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_335.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_336.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_337.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_338.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_339.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_340.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_341.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_342.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_343.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_344.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_345.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_346.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_347.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_348.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_349.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_350.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_351.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_352.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_353.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_354.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_355.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_356.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_357.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_358.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_359.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_360.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_361.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_362.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_363.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_364.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_365.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_366.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_367.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_368.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_369.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_370.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_371.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_372.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_373.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_374.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_375.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_376.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_377.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_378.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_379.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_381.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_382.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_383.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_384.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_385.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_386.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_387.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_388.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_389.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_390.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_391.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_392.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_393.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_394.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_395.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_396.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_397.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_398.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_399.root', 
        'root://eosuser.cern.ch//eos/user/c/chuw/flashgg/Non_res_withTau/94X_mc2017-RunIIFall18/GluGluToHHTo_WWgg_lnulnugg_node8/Non_res_withTau-94X_mc2017-RunIIFall18-v0-wangjin-100000events_wPU_MINIAOD-5f646ecd4e1c7a39ab0ed099ff55ceb9/200808_111340/0000//myMicroAODOutputFile_400.root'
    )
)
process.CondDB = cms.PSet(
    DBParameters = cms.PSet(
        authenticationPath = cms.untracked.string(''),
        authenticationSystem = cms.untracked.int32(0),
        messageLevel = cms.untracked.int32(0),
        security = cms.untracked.string('')
    ),
    connect = cms.string('')
)

process.FNUFBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.0007),
            upBounds = cms.vdouble(1.5, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.94),
            uncertainties = cms.vdouble(-0.0007),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.0007),
            upBounds = cms.vdouble(6.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.94),
            uncertainties = cms.vdouble(-0.0007),
            upBounds = cms.vdouble(6.0, 999.0),
            values = cms.vdouble(0.0)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.FNUFEB = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.0007),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(-0.0007),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0007),
                upBounds = cms.vdouble(6.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(-0.0007),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('FNUFEB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.FNUFEE = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.0007),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(-0.0007),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0007),
                upBounds = cms.vdouble(6.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(-0.0007),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('FNUFEE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.FracRVNvtxWeight = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(-0.5),
                uncertainties = cms.vdouble(0.00155068, 0.00155068, 0.00918045, 0.00918045),
                upBounds = cms.vdouble(10.5),
                values = cms.vdouble(1.02898, 0.828452)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(10.5),
                uncertainties = cms.vdouble(0.0013211, 0.0013211, 0.00679271, 0.00679271),
                upBounds = cms.vdouble(12.5),
                values = cms.vdouble(1.00775, 0.960156)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(12.5),
                uncertainties = cms.vdouble(0.00113947, 0.00113947, 0.00535269, 0.00535269),
                upBounds = cms.vdouble(14.5),
                values = cms.vdouble(1.00406, 0.980929)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(14.5),
                uncertainties = cms.vdouble(0.00109956, 0.00109956, 0.00493888, 0.00493888),
                upBounds = cms.vdouble(16.5),
                values = cms.vdouble(1.00159, 0.992869)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(16.5),
                uncertainties = cms.vdouble(0.00112887, 0.00112887, 0.00481407, 0.00481407),
                upBounds = cms.vdouble(18.5),
                values = cms.vdouble(0.993201, 1.02899)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(18.5),
                uncertainties = cms.vdouble(0.0012414, 0.0012414, 0.00502105, 0.00502105),
                upBounds = cms.vdouble(20.5),
                values = cms.vdouble(0.991425, 1.03468)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(20.5),
                uncertainties = cms.vdouble(0.00142369, 0.00142369, 0.00545553, 0.00545553),
                upBounds = cms.vdouble(22.5),
                values = cms.vdouble(0.989716, 1.03941)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(22.5),
                uncertainties = cms.vdouble(0.00147513, 0.00147513, 0.00538112, 0.00538112),
                upBounds = cms.vdouble(25.5),
                values = cms.vdouble(0.98674, 1.04837)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(25.5),
                uncertainties = cms.vdouble(0.00188024, 0.00188024, 0.00643049, 0.00643049),
                upBounds = cms.vdouble(30.5),
                values = cms.vdouble(0.976922, 1.07893)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(30.5),
                uncertainties = cms.vdouble(0.00440431, 0.00440431, 0.0142389, 0.0142389),
                upBounds = cms.vdouble(100.5),
                values = cms.vdouble(0.959731, 1.13018)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(100.5),
                uncertainties = cms.vdouble(0.0, 0.0, 0.0, 0.0),
                upBounds = cms.vdouble(999999999),
                values = cms.vdouble(1, 1)
            )
        ),
        variables = cms.vstring('nVert')
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('FracRVNvtxWeight'),
    MethodName = cms.string('FlashggDiPhotonWeightFromFracRV'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('nVert<99999')
)

process.FracRVWeight = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0),
                uncertainties = cms.vdouble(0.00167952, 0.00167952, 0.00243437, 0.00243437),
                upBounds = cms.vdouble(5),
                values = cms.vdouble(1.00046, 0.999332)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(5),
                uncertainties = cms.vdouble(0.00132967, 0.00132967, 0.00199484, 0.00199484),
                upBounds = cms.vdouble(10),
                values = cms.vdouble(1.01403, 0.978954)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(10),
                uncertainties = cms.vdouble(0.00127284, 0.00127284, 0.00222552, 0.00222552),
                upBounds = cms.vdouble(15),
                values = cms.vdouble(1.0031, 0.99458)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(15),
                uncertainties = cms.vdouble(0.00122729, 0.00122729, 0.00270787, 0.00270787),
                upBounds = cms.vdouble(20),
                values = cms.vdouble(0.992237, 1.01713)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(20),
                uncertainties = cms.vdouble(0.000854325, 0.000854325, 0.00266531, 0.00266531),
                upBounds = cms.vdouble(30),
                values = cms.vdouble(0.990433, 1.02985)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(30),
                uncertainties = cms.vdouble(0.000847473, 0.000847473, 0.00415923, 0.00415923),
                upBounds = cms.vdouble(40),
                values = cms.vdouble(0.988515, 1.05637)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(40),
                uncertainties = cms.vdouble(0.000864982, 0.000864982, 0.00601261, 0.00601261),
                upBounds = cms.vdouble(50),
                values = cms.vdouble(0.988526, 1.07976)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(50),
                uncertainties = cms.vdouble(0.000909363, 0.000909363, 0.00921419, 0.00921419),
                upBounds = cms.vdouble(60),
                values = cms.vdouble(0.988509, 1.11643)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(60),
                uncertainties = cms.vdouble(0.000690743, 0.000690743, 0.00982573, 0.00982573),
                upBounds = cms.vdouble(80),
                values = cms.vdouble(0.989606, 1.14786)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(80),
                uncertainties = cms.vdouble(0.000759541, 0.000759541, 0.0150743, 0.0150743),
                upBounds = cms.vdouble(100),
                values = cms.vdouble(0.991492, 1.16885)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(100),
                uncertainties = cms.vdouble(0.00066297, 0.00066297, 0.0173001, 0.0173001),
                upBounds = cms.vdouble(140),
                values = cms.vdouble(0.997022, 1.07771)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(140),
                uncertainties = cms.vdouble(0.000738493, 0.000738493, 0.0291629, 0.0291629),
                upBounds = cms.vdouble(200),
                values = cms.vdouble(0.999255, 1.02942)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(200),
                uncertainties = cms.vdouble(0.000985164, 0.000985164, 0.0710487, 0.0710487),
                upBounds = cms.vdouble(400),
                values = cms.vdouble(1.00079, 0.943138)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(400),
                uncertainties = cms.vdouble(0.0, 0.0, 0.0, 0.0),
                upBounds = cms.vdouble(999999999),
                values = cms.vdouble(1, 1)
            )
        ),
        variables = cms.vstring('pt')
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('FracRVWeight'),
    MethodName = cms.string('FlashggDiPhotonWeightFromFracRV'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('pt<99999')
)

process.HFRecalParameterBlock = cms.PSet(
    HFdepthOneParameterA = cms.vdouble(
        0.004123, 0.00602, 0.008201, 0.010489, 0.013379, 
        0.016997, 0.021464, 0.027371, 0.034195, 0.044807, 
        0.058939, 0.125497
    ),
    HFdepthOneParameterB = cms.vdouble(
        -4e-06, -2e-06, 0.0, 4e-06, 1.5e-05, 
        2.6e-05, 6.3e-05, 8.4e-05, 0.00016, 0.000107, 
        0.000425, 0.000209
    ),
    HFdepthTwoParameterA = cms.vdouble(
        0.002861, 0.004168, 0.0064, 0.008388, 0.011601, 
        0.014425, 0.018633, 0.023232, 0.028274, 0.035447, 
        0.051579, 0.086593
    ),
    HFdepthTwoParameterB = cms.vdouble(
        -2e-06, -0.0, -7e-06, -6e-06, -2e-06, 
        1e-06, 1.9e-05, 3.1e-05, 6.7e-05, 1.2e-05, 
        0.000157, -3e-06
    )
)

process.HTXSInputTags = cms.PSet(
    ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
    njets = cms.InputTag("rivetProducerHTXS","njets"),
    pTH = cms.InputTag("rivetProducerHTXS","pTH"),
    pTV = cms.InputTag("rivetProducerHTXS","pTV"),
    stage0cat = cms.InputTag("rivetProducerHTXS","stage0cat"),
    stage1cat = cms.InputTag("rivetProducerHTXS","stage1cat")
)

process.LooseMvaSF = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.0001),
                upBounds = cms.vdouble(1.5, 0.85),
                values = cms.vdouble(0.9999)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85),
                uncertainties = cms.vdouble(0.0),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(1.0003)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0),
                upBounds = cms.vdouble(6.0, 0.9),
                values = cms.vdouble(1.0003)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9),
                uncertainties = cms.vdouble(0.0),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(1.0004)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('LooseMvaSF'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('1'),
    PhotonMethodName = cms.string('FlashggPhotonWeight')
)

process.MCScaleGain1EB_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCScaleGain1EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('hasSwitchToGain1&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
    UncertaintyBitMask = cms.string('100')
)

process.MCScaleGain6EB_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCScaleGain6EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('hasSwitchToGain6&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
    UncertaintyBitMask = cms.string('100')
)

process.MCScaleHighR9EB = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MCScaleHighR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MCScaleHighR9EB_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCScaleHighR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
    UncertaintyBitMask = cms.string('011')
)

process.MCScaleHighR9EE = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MCScaleHighR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MCScaleHighR9EE_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCScaleHighR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
    UncertaintyBitMask = cms.string('011')
)

process.MCScaleLowR9EB = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MCScaleLowR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<0.94&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MCScaleLowR9EB_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCScaleLowR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<0.94&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
    UncertaintyBitMask = cms.string('011')
)

process.MCScaleLowR9EE = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MCScaleLowR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<0.94&&abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MCScaleLowR9EE_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCScaleLowR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<0.94&&abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
    UncertaintyBitMask = cms.string('011')
)

process.MCSmearHighR9EB = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCSmearHighR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonSmearConstant'),
    RandomLabel = cms.string('rnd_g_E')
)

process.MCSmearHighR9EB_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    FirstParameterName = cms.string('Rho'),
    Label = cms.string('MCSmearHighR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
    NSigmas = cms.PSet(
        firstVar = cms.vint32(1, -1, 0, 0),
        secondVar = cms.vint32(0, 0, 1, -1)
    ),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
    RandomLabel = cms.string('rnd_g_E'),
    SecondParameterName = cms.string('Phi')
)

process.MCSmearHighR9EE = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCSmearHighR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonSmearConstant'),
    RandomLabel = cms.string('rnd_g_E')
)

process.MCSmearHighR9EE_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    FirstParameterName = cms.string('Rho'),
    Label = cms.string('MCSmearHighR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
    NSigmas = cms.PSet(
        firstVar = cms.vint32(1, -1, 0, 0),
        secondVar = cms.vint32(0, 0, 1, -1)
    ),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
    RandomLabel = cms.string('rnd_g_E'),
    SecondParameterName = cms.string('Phi')
)

process.MCSmearLowR9EB = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCSmearLowR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonSmearConstant'),
    RandomLabel = cms.string('rnd_g_E')
)

process.MCSmearLowR9EB_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    FirstParameterName = cms.string('Rho'),
    Label = cms.string('MCSmearLowR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
    NSigmas = cms.PSet(
        firstVar = cms.vint32(1, -1, 0, 0),
        secondVar = cms.vint32(0, 0, 1, -1)
    ),
    OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
    RandomLabel = cms.string('rnd_g_E'),
    SecondParameterName = cms.string('Phi')
)

process.MCSmearLowR9EE = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCSmearLowR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<0.94&&abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonSmearConstant'),
    RandomLabel = cms.string('rnd_g_E')
)

process.MCSmearLowR9EE_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    FirstParameterName = cms.string('Rho'),
    Label = cms.string('MCSmearLowR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
    NSigmas = cms.PSet(
        firstVar = cms.vint32(1, -1, 0, 0),
        secondVar = cms.vint32(0, 0, 1, -1)
    ),
    OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
    RandomLabel = cms.string('rnd_g_E'),
    SecondParameterName = cms.string('Phi')
)

process.MaterialCentralBarrel = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.000455),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(0.000233),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.002089),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(0.002089),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.00109),
                upBounds = cms.vdouble(999.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.002377),
                upBounds = cms.vdouble(999.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MaterialCentralBarrel'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(superCluster.eta)<1.0'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MaterialForward = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.000455),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(0.000233),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.002089),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(0.002089),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.00109),
                upBounds = cms.vdouble(999.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.002377),
                upBounds = cms.vdouble(999.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MaterialForward'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MaterialOuterBarrel = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.000455),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(0.000233),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.002089),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(0.002089),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.00109),
                upBounds = cms.vdouble(999.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.002377),
                upBounds = cms.vdouble(999.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MaterialOuterBarrel'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(superCluster.eta)>=1.0&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MvaShift = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(cms.PSet(
            lowBounds = cms.vdouble(0.0),
            uncertainties = cms.vdouble(0.0),
            upBounds = cms.vdouble(999.0),
            values = cms.vdouble(0.0)
        )),
        variables = cms.vstring('abs(superCluster.eta)')
    ),
    CorrectionFile = cms.FileInPath('flashgg/Systematics/data/SystematicsIDMVA_LegRunII_v1_2017.root'),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MvaShift'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('1'),
    PhotonMethodName = cms.string('FlashggPhotonMvaTransform')
)

process.PixelSeedWeight = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, -0.1),
                uncertainties = cms.vdouble(-0.00401807),
                upBounds = cms.vdouble(1.5, 0.85, 0.1),
                values = cms.vdouble(0.978)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85, -0.1),
                uncertainties = cms.vdouble(-0.00200421),
                upBounds = cms.vdouble(1.5, 999.0, 0.1),
                values = cms.vdouble(0.9824)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0, -0.1),
                uncertainties = cms.vdouble(-0.0224756),
                upBounds = cms.vdouble(6.0, 0.9, 0.1),
                values = cms.vdouble(0.9168)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9, -0.1),
                uncertainties = cms.vdouble(-0.00631264),
                upBounds = cms.vdouble(6.0, 999.0, 0.1),
                values = cms.vdouble(0.9403)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 0.9),
                uncertainties = cms.vdouble(0.0162106),
                upBounds = cms.vdouble(1.5, 0.85, 1.1),
                values = cms.vdouble(1.08876)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85, 0.9),
                uncertainties = cms.vdouble(0.0678807),
                upBounds = cms.vdouble(1.5, 999.0, 1.1),
                values = cms.vdouble(1.5961)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0, 0.9),
                uncertainties = cms.vdouble(0.0263745),
                upBounds = cms.vdouble(6.0, 0.9, 1.1),
                values = cms.vdouble(1.09763)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9, 0.9),
                uncertainties = cms.vdouble(0.0214274),
                upBounds = cms.vdouble(6.0, 999.0, 1.1),
                values = cms.vdouble(1.20264)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9', 
            'hasPixelSeed'
        )
    ),
    BinList2 = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, -0.1),
                uncertainties = cms.vdouble(-0.00415083),
                upBounds = cms.vdouble(1.5, 0.85, 0.1),
                values = cms.vdouble(0.978)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85, -0.1),
                uncertainties = cms.vdouble(-0.00280026),
                upBounds = cms.vdouble(1.5, 999.0, 0.1),
                values = cms.vdouble(0.9824)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0, -0.1),
                uncertainties = cms.vdouble(-0.0225538),
                upBounds = cms.vdouble(6.0, 0.9, 0.1),
                values = cms.vdouble(0.9168)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9, -0.1),
                uncertainties = cms.vdouble(-0.00655045),
                upBounds = cms.vdouble(6.0, 999.0, 0.1),
                values = cms.vdouble(0.9403)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 0.9),
                uncertainties = cms.vdouble(0.0248967),
                upBounds = cms.vdouble(1.5, 0.85, 1.1),
                values = cms.vdouble(1.13196)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85, 0.9),
                uncertainties = cms.vdouble(0.0978689),
                upBounds = cms.vdouble(1.5, 999.0, 1.1),
                values = cms.vdouble(1.61512)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0, 0.9),
                uncertainties = cms.vdouble(0.0287957),
                upBounds = cms.vdouble(6.0, 0.9, 1.1),
                values = cms.vdouble(1.10623)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9, 0.9),
                uncertainties = cms.vdouble(0.0222861),
                upBounds = cms.vdouble(6.0, 999.0, 1.1),
                values = cms.vdouble(1.20311)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9', 
            'hasPixelSeed'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('PixelSeedWeight'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('pt<99999'),
    PhotonMethodName = cms.string('FlashggPhotonWeight')
)

process.PreselSF = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.005),
                upBounds = cms.vdouble(1.5, 0.85),
                values = cms.vdouble(0.998)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85),
                uncertainties = cms.vdouble(0.003),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(1.001)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.006),
                upBounds = cms.vdouble(6.0, 0.9),
                values = cms.vdouble(0.989)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9),
                uncertainties = cms.vdouble(0.009),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(1.002)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('PreselSF'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('1'),
    PhotonMethodName = cms.string('FlashggPhotonWeight')
)

process.RVBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0),
            uncertainties = cms.vdouble(0.00167952, 0.00167952, 0.00243437, 0.00243437),
            upBounds = cms.vdouble(5),
            values = cms.vdouble(1.00046, 0.999332)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(5),
            uncertainties = cms.vdouble(0.00132967, 0.00132967, 0.00199484, 0.00199484),
            upBounds = cms.vdouble(10),
            values = cms.vdouble(1.01403, 0.978954)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(10),
            uncertainties = cms.vdouble(0.00127284, 0.00127284, 0.00222552, 0.00222552),
            upBounds = cms.vdouble(15),
            values = cms.vdouble(1.0031, 0.99458)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(15),
            uncertainties = cms.vdouble(0.00122729, 0.00122729, 0.00270787, 0.00270787),
            upBounds = cms.vdouble(20),
            values = cms.vdouble(0.992237, 1.01713)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(20),
            uncertainties = cms.vdouble(0.000854325, 0.000854325, 0.00266531, 0.00266531),
            upBounds = cms.vdouble(30),
            values = cms.vdouble(0.990433, 1.02985)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(30),
            uncertainties = cms.vdouble(0.000847473, 0.000847473, 0.00415923, 0.00415923),
            upBounds = cms.vdouble(40),
            values = cms.vdouble(0.988515, 1.05637)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(40),
            uncertainties = cms.vdouble(0.000864982, 0.000864982, 0.00601261, 0.00601261),
            upBounds = cms.vdouble(50),
            values = cms.vdouble(0.988526, 1.07976)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(50),
            uncertainties = cms.vdouble(0.000909363, 0.000909363, 0.00921419, 0.00921419),
            upBounds = cms.vdouble(60),
            values = cms.vdouble(0.988509, 1.11643)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(60),
            uncertainties = cms.vdouble(0.000690743, 0.000690743, 0.00982573, 0.00982573),
            upBounds = cms.vdouble(80),
            values = cms.vdouble(0.989606, 1.14786)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(80),
            uncertainties = cms.vdouble(0.000759541, 0.000759541, 0.0150743, 0.0150743),
            upBounds = cms.vdouble(100),
            values = cms.vdouble(0.991492, 1.16885)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(100),
            uncertainties = cms.vdouble(0.00066297, 0.00066297, 0.0173001, 0.0173001),
            upBounds = cms.vdouble(140),
            values = cms.vdouble(0.997022, 1.07771)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(140),
            uncertainties = cms.vdouble(0.000738493, 0.000738493, 0.0291629, 0.0291629),
            upBounds = cms.vdouble(200),
            values = cms.vdouble(0.999255, 1.02942)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(200),
            uncertainties = cms.vdouble(0.000985164, 0.000985164, 0.0710487, 0.0710487),
            upBounds = cms.vdouble(400),
            values = cms.vdouble(1.00079, 0.943138)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(400),
            uncertainties = cms.vdouble(0.0, 0.0, 0.0, 0.0),
            upBounds = cms.vdouble(999999999),
            values = cms.vdouble(1, 1)
        )
    ),
    variables = cms.vstring('pt')
)

process.RVBinsNvtx = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(-0.5),
            uncertainties = cms.vdouble(0.00155068, 0.00155068, 0.00918045, 0.00918045),
            upBounds = cms.vdouble(10.5),
            values = cms.vdouble(1.02898, 0.828452)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(10.5),
            uncertainties = cms.vdouble(0.0013211, 0.0013211, 0.00679271, 0.00679271),
            upBounds = cms.vdouble(12.5),
            values = cms.vdouble(1.00775, 0.960156)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(12.5),
            uncertainties = cms.vdouble(0.00113947, 0.00113947, 0.00535269, 0.00535269),
            upBounds = cms.vdouble(14.5),
            values = cms.vdouble(1.00406, 0.980929)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(14.5),
            uncertainties = cms.vdouble(0.00109956, 0.00109956, 0.00493888, 0.00493888),
            upBounds = cms.vdouble(16.5),
            values = cms.vdouble(1.00159, 0.992869)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(16.5),
            uncertainties = cms.vdouble(0.00112887, 0.00112887, 0.00481407, 0.00481407),
            upBounds = cms.vdouble(18.5),
            values = cms.vdouble(0.993201, 1.02899)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(18.5),
            uncertainties = cms.vdouble(0.0012414, 0.0012414, 0.00502105, 0.00502105),
            upBounds = cms.vdouble(20.5),
            values = cms.vdouble(0.991425, 1.03468)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(20.5),
            uncertainties = cms.vdouble(0.00142369, 0.00142369, 0.00545553, 0.00545553),
            upBounds = cms.vdouble(22.5),
            values = cms.vdouble(0.989716, 1.03941)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(22.5),
            uncertainties = cms.vdouble(0.00147513, 0.00147513, 0.00538112, 0.00538112),
            upBounds = cms.vdouble(25.5),
            values = cms.vdouble(0.98674, 1.04837)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(25.5),
            uncertainties = cms.vdouble(0.00188024, 0.00188024, 0.00643049, 0.00643049),
            upBounds = cms.vdouble(30.5),
            values = cms.vdouble(0.976922, 1.07893)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(30.5),
            uncertainties = cms.vdouble(0.00440431, 0.00440431, 0.0142389, 0.0142389),
            upBounds = cms.vdouble(100.5),
            values = cms.vdouble(0.959731, 1.13018)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(100.5),
            uncertainties = cms.vdouble(0.0, 0.0, 0.0, 0.0),
            upBounds = cms.vdouble(999999999),
            values = cms.vdouble(1, 1)
        )
    ),
    variables = cms.vstring('nVert')
)

process.ShowerShapeHighR9EB = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(-0.0001),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(-0.0006),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(-0.0011),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0015),
                upBounds = cms.vdouble(2.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.0),
                uncertainties = cms.vdouble(0.0004),
                upBounds = cms.vdouble(6.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(2.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.94),
                uncertainties = cms.vdouble(0.0003),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('ShowerShapeHighR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.ShowerShapeHighR9EE = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(-0.0001),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(-0.0006),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(-0.0011),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0015),
                upBounds = cms.vdouble(2.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.0),
                uncertainties = cms.vdouble(0.0004),
                upBounds = cms.vdouble(6.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(2.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.94),
                uncertainties = cms.vdouble(0.0003),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('ShowerShapeHighR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.ShowerShapeLowR9EB = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(-0.0001),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(-0.0006),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(-0.0011),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0015),
                upBounds = cms.vdouble(2.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.0),
                uncertainties = cms.vdouble(0.0004),
                upBounds = cms.vdouble(6.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(2.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.94),
                uncertainties = cms.vdouble(0.0003),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('ShowerShapeLowR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.ShowerShapeLowR9EE = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(-0.0001),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(-0.0006),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(-0.0011),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0015),
                upBounds = cms.vdouble(2.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.0),
                uncertainties = cms.vdouble(0.0004),
                upBounds = cms.vdouble(6.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(2.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.94),
                uncertainties = cms.vdouble(0.0003),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('ShowerShapeLowR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.SigmaEOverEShift = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(cms.PSet(
            lowBounds = cms.vdouble(0.0),
            uncertainties = cms.vdouble(0.05),
            upBounds = cms.vdouble(999.0),
            values = cms.vdouble(0.0)
        )),
        variables = cms.vstring('abs(superCluster.eta)')
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('SigmaEOverEShift'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('1'),
    PhotonMethodName = cms.string('FlashggPhotonSigEOverEShift')
)

process.SigmaEOverESmearing = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('SigmaEOverESmearing'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(),
    OverallRange = cms.string('1'),
    PhotonMethodName = cms.string('FlashggPhotonSigEoverESmearing')
)

process.SigmaEOverESmearing_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('SigmaEOverESmearing'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(),
    OverallRange = cms.string('1'),
    PhotonMethodName = cms.string('FlashggPhotonSigEoverESmearingEGMTool')
)

process.TriggerWeight = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 0.0),
                uncertainties = cms.vdouble(0.0015550248, 0.0015550248),
                upBounds = cms.vdouble(0.54, 1.5, 37.0),
                values = cms.vdouble(0.9204369513)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 37),
                uncertainties = cms.vdouble(0.0012001964, 0.0012001964),
                upBounds = cms.vdouble(0.54, 1.5, 40.0),
                values = cms.vdouble(0.9268543618)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 40.0),
                uncertainties = cms.vdouble(0.0010500218, 0.0010500218),
                upBounds = cms.vdouble(0.54, 1.5, 45.0),
                values = cms.vdouble(0.9296864506)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 45.0),
                uncertainties = cms.vdouble(0.0016928371, 0.0016928371),
                upBounds = cms.vdouble(0.54, 1.5, 50.0),
                values = cms.vdouble(0.9312181087)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 50.0),
                uncertainties = cms.vdouble(0.0024479457, 0.0024479457),
                upBounds = cms.vdouble(0.54, 1.5, 60.0),
                values = cms.vdouble(0.9349061049)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 60.0),
                uncertainties = cms.vdouble(0.0052975139, 0.0052975139),
                upBounds = cms.vdouble(0.54, 1.5, 70.0),
                values = cms.vdouble(0.9425532022)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 70.0),
                uncertainties = cms.vdouble(0.0089854906, 0.0089854906),
                upBounds = cms.vdouble(0.54, 1.5, 90.0),
                values = cms.vdouble(0.9347621741)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 90.0),
                uncertainties = cms.vdouble(0.017714307, 0.017714307),
                upBounds = cms.vdouble(0.54, 1.5, 99999999),
                values = cms.vdouble(0.9489236873)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 0.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 37.0),
                values = cms.vdouble(0.9505374744)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 37.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 40.0),
                values = cms.vdouble(0.9559316002)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 45.0),
                values = cms.vdouble(0.960322746)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 45.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 50.0),
                values = cms.vdouble(0.9628461917)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 50.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 60.0),
                values = cms.vdouble(0.9662884361)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 60.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 70.0),
                values = cms.vdouble(0.9715136996)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 70.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 90.0),
                values = cms.vdouble(0.9753661262)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 90.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 99999999),
                values = cms.vdouble(0.9818196687)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 0.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 37.0),
                values = cms.vdouble(0.9630117411)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 37.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 40.0),
                values = cms.vdouble(0.9680310533)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 45.0),
                values = cms.vdouble(0.9721152461)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 45.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 50.0),
                values = cms.vdouble(0.9748189645)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 50.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 60.0),
                values = cms.vdouble(0.9747597366)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 60.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 70.0),
                values = cms.vdouble(0.9753162174)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 70.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 90.0),
                values = cms.vdouble(0.9803243059)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 90.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 99999999),
                values = cms.vdouble(0.9865482764)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 0.0),
                uncertainties = cms.vdouble(0.0017122892, 0.0017122892),
                upBounds = cms.vdouble(0.84, 3.0, 37.0),
                values = cms.vdouble(0.9093169942)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 37.0),
                uncertainties = cms.vdouble(0.0012578761, 0.0012578761),
                upBounds = cms.vdouble(0.84, 3.0, 40.0),
                values = cms.vdouble(0.9214136806)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.84, 3.0, 45.0),
                values = cms.vdouble(0.9396498081)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 45.0),
                uncertainties = cms.vdouble(0.0013009169, 0.0013009169),
                upBounds = cms.vdouble(0.84, 3.0, 50.0),
                values = cms.vdouble(0.9455103913)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 50.0),
                uncertainties = cms.vdouble(0.00165793, 0.00165793),
                upBounds = cms.vdouble(0.84, 3.0, 60.0),
                values = cms.vdouble(0.9519493209)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 60.0),
                uncertainties = cms.vdouble(0.0031358462, 0.0031358462),
                upBounds = cms.vdouble(0.84, 3.0, 70.0),
                values = cms.vdouble(0.9560088523)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 70.0),
                uncertainties = cms.vdouble(0.0036329374, 0.0036329374),
                upBounds = cms.vdouble(0.84, 3.0, 90.0),
                values = cms.vdouble(0.9638480843)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 90.0),
                uncertainties = cms.vdouble(0.0051321702, 0.0051321702),
                upBounds = cms.vdouble(0.84, 3.0, 99999999),
                values = cms.vdouble(0.9714734218)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 0.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 37.0),
                values = cms.vdouble(0.961495108)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 37.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 40.0),
                values = cms.vdouble(0.9750837371)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 45.0),
                values = cms.vdouble(0.9814701227)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 45.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 50.0),
                values = cms.vdouble(0.9835352074)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 50.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 60.0),
                values = cms.vdouble(0.9851237595)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 60.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 70.0),
                values = cms.vdouble(0.9869551174)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 70.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 90.0),
                values = cms.vdouble(0.9916069861)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 90.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 99999999),
                values = cms.vdouble(0.9958525312)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 0.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 37.0),
                values = cms.vdouble(0.9470889409)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 37.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 40.0),
                values = cms.vdouble(0.9646677794)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 45.0),
                values = cms.vdouble(0.9738993606)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 45.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 50.0),
                values = cms.vdouble(0.9784039943)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 50.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 60.0),
                values = cms.vdouble(0.980234517)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 60.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 70.0),
                values = cms.vdouble(0.9828741312)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 70.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 90.0),
                values = cms.vdouble(0.9870534958)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 90.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 99999999),
                values = cms.vdouble(0.9891255039)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 3.0, 0),
                uncertainties = cms.vdouble(1.0, 1.0),
                upBounds = cms.vdouble(999, 999, 999999),
                values = cms.vdouble(1.0)
            )
        ),
        variables = cms.vstring(
            'full5x5_r9', 
            'abs(superCluster.eta)', 
            'pt'
        )
    ),
    BinList2 = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 0.0),
                uncertainties = cms.vdouble(0.001420359, 0.001420359),
                upBounds = cms.vdouble(0.54, 1.5, 28.0),
                values = cms.vdouble(0.9503915847)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 28.0),
                uncertainties = cms.vdouble(0.0011666773, 0.0011666773),
                upBounds = cms.vdouble(0.54, 1.5, 31.0),
                values = cms.vdouble(0.9563040539)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 31.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.54, 1.5, 35.0),
                values = cms.vdouble(0.9554701294)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 35.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.54, 1.5, 40.0),
                values = cms.vdouble(0.9573495211)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.54, 1.5, 45.0),
                values = cms.vdouble(0.9615640328)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 45.0),
                uncertainties = cms.vdouble(0.0012149116, 0.0012149116),
                upBounds = cms.vdouble(0.54, 1.5, 50.0),
                values = cms.vdouble(0.9635847522)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 50.0),
                uncertainties = cms.vdouble(0.0018398439, 0.0018398439),
                upBounds = cms.vdouble(0.54, 1.5, 60.0),
                values = cms.vdouble(0.9613424282)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 60.0),
                uncertainties = cms.vdouble(0.0046295174, 0.0046295174),
                upBounds = cms.vdouble(0.54, 1.5, 70.0),
                values = cms.vdouble(0.953179846)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 70.0),
                uncertainties = cms.vdouble(0.0082547803, 0.0082547803),
                upBounds = cms.vdouble(0.54, 1.5, 90.0),
                values = cms.vdouble(0.9427949472)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 90.0),
                uncertainties = cms.vdouble(0.0210727517, 0.0210727517),
                upBounds = cms.vdouble(0.54, 1.5, 99999999),
                values = cms.vdouble(0.9180892383)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 0.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 28.0),
                values = cms.vdouble(0.9821722615)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 28.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 31.0),
                values = cms.vdouble(0.9846684256)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 31.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 35.0),
                values = cms.vdouble(0.9853409044)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 35.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 40.0),
                values = cms.vdouble(0.9851741151)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 45.0),
                values = cms.vdouble(0.9847237955)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 45.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 50.0),
                values = cms.vdouble(0.9836985511)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 50.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 60.0),
                values = cms.vdouble(0.9818687985)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 60.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 70.0),
                values = cms.vdouble(0.9793978257)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 70.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 90.0),
                values = cms.vdouble(0.9766027088)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 90.0),
                uncertainties = cms.vdouble(0.0011171683, 0.0011171683),
                upBounds = cms.vdouble(0.85, 1.5, 99999999),
                values = cms.vdouble(0.972331437)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 0.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 28.0),
                values = cms.vdouble(0.9997101832)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 28.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 31.0),
                values = cms.vdouble(0.9998675478)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 31.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 35.0),
                values = cms.vdouble(0.9999351175)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 35.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 40.0),
                values = cms.vdouble(0.999954156)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 45.0),
                values = cms.vdouble(0.9999645283)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 45.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 50.0),
                values = cms.vdouble(0.9999677894)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 50.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 60.0),
                values = cms.vdouble(0.9999665309)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 60.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 70.0),
                values = cms.vdouble(0.9999602573)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 70.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 90.0),
                values = cms.vdouble(0.9999369329)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 90.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 99999999),
                values = cms.vdouble(0.9999456063)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 0.0),
                uncertainties = cms.vdouble(0.0027302573, 0.0027302573),
                upBounds = cms.vdouble(0.84, 3.0, 28.0),
                values = cms.vdouble(0.8799714219)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 28.0),
                uncertainties = cms.vdouble(0.0021032366, 0.0021032366),
                upBounds = cms.vdouble(0.84, 3.0, 31.0),
                values = cms.vdouble(0.8962741603)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 31.0),
                uncertainties = cms.vdouble(0.0014198635, 0.0014198635),
                upBounds = cms.vdouble(0.84, 3.0, 35.0),
                values = cms.vdouble(0.9042685088)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 35.0),
                uncertainties = cms.vdouble(0.0010478241, 0.0010478241),
                upBounds = cms.vdouble(0.84, 3.0, 40.0),
                values = cms.vdouble(0.9130894467)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 40.0),
                uncertainties = cms.vdouble(0.0010511874, 0.0010511874),
                upBounds = cms.vdouble(0.84, 3.0, 45.0),
                values = cms.vdouble(0.9236887059)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 45.0),
                uncertainties = cms.vdouble(0.0015068743, 0.0015068743),
                upBounds = cms.vdouble(0.84, 3.0, 50.0),
                values = cms.vdouble(0.926909296)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 50.0),
                uncertainties = cms.vdouble(0.001993287, 0.001993287),
                upBounds = cms.vdouble(0.84, 3.0, 60.0),
                values = cms.vdouble(0.9300621013)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 60.0),
                uncertainties = cms.vdouble(0.0038708618, 0.0038708618),
                upBounds = cms.vdouble(0.84, 3.0, 70.0),
                values = cms.vdouble(0.9313708557)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 70.0),
                uncertainties = cms.vdouble(0.0046452036, 0.0046452036),
                upBounds = cms.vdouble(0.84, 3.0, 90.0),
                values = cms.vdouble(0.9387860583)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 90.0),
                uncertainties = cms.vdouble(0.007718235, 0.007718235),
                upBounds = cms.vdouble(0.84, 3.0, 99999999),
                values = cms.vdouble(0.9316696569)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 0.0),
                uncertainties = cms.vdouble(0.0011380402, 0.0011380402),
                upBounds = cms.vdouble(0.9, 3.0, 28.0),
                values = cms.vdouble(0.9482346612)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 28.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 31.0),
                values = cms.vdouble(0.9753440965)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 31.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 35.0),
                values = cms.vdouble(0.9760310914)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 35.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 40.0),
                values = cms.vdouble(0.9752981073)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 45.0),
                values = cms.vdouble(0.973705016)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 45.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 50.0),
                values = cms.vdouble(0.9719236369)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 50.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 60.0),
                values = cms.vdouble(0.9704295117)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 60.0),
                uncertainties = cms.vdouble(0.0014503236, 0.0014503236),
                upBounds = cms.vdouble(0.9, 3.0, 70.0),
                values = cms.vdouble(0.9692422639)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 70.0),
                uncertainties = cms.vdouble(0.0018171502, 0.0018171502),
                upBounds = cms.vdouble(0.9, 3.0, 90.0),
                values = cms.vdouble(0.9692330221)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 90.0),
                uncertainties = cms.vdouble(0.0024173224, 0.0024173224),
                upBounds = cms.vdouble(0.9, 3.0, 99999999),
                values = cms.vdouble(0.972663036)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 0.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 28.0),
                values = cms.vdouble(0.9706915047)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 28.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 31.0),
                values = cms.vdouble(0.9975115605)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 31.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 35.0),
                values = cms.vdouble(0.9992706525)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 35.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 40.0),
                values = cms.vdouble(0.9995305126)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 45.0),
                values = cms.vdouble(0.9995836941)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 45.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 50.0),
                values = cms.vdouble(0.9996279004)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 50.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 60.0),
                values = cms.vdouble(0.9995678968)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 60.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 70.0),
                values = cms.vdouble(0.9996782105)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 70.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 90.0),
                values = cms.vdouble(0.9997202663)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 90.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 99999999),
                values = cms.vdouble(0.9993842985)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 3.0, 0),
                uncertainties = cms.vdouble(1.0, 1.0),
                upBounds = cms.vdouble(999, 999, 999999),
                values = cms.vdouble(1.0)
            )
        ),
        variables = cms.vstring(
            'full5x5_r9', 
            'abs(superCluster.eta)', 
            'pt'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('TriggerWeight'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('pt<99999'),
    PhotonMethodName = cms.string('FlashggPhotonWeight')
)

process.binInfo2016 = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(-6.0, 0.0),
            uncertainties = cms.vdouble(0.0001),
            upBounds = cms.vdouble(-2.5, 9999999.0),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 0),
            uncertainties = cms.vdouble(0.0001),
            upBounds = cms.vdouble(-2, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 10),
            uncertainties = cms.vdouble(0.021),
            upBounds = cms.vdouble(-2, 20),
            values = cms.vdouble(1.014)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 20),
            uncertainties = cms.vdouble(0.009),
            upBounds = cms.vdouble(-2, 35),
            values = cms.vdouble(0.991)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 35),
            uncertainties = cms.vdouble(0.006),
            upBounds = cms.vdouble(-2, 50),
            values = cms.vdouble(0.999)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 50),
            uncertainties = cms.vdouble(0.008),
            upBounds = cms.vdouble(-2, 100),
            values = cms.vdouble(0.995)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 100),
            uncertainties = cms.vdouble(0.032),
            upBounds = cms.vdouble(-2, 200),
            values = cms.vdouble(1.014)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 200),
            uncertainties = cms.vdouble(0.089),
            upBounds = cms.vdouble(-2, 500),
            values = cms.vdouble(0.966)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 500),
            uncertainties = cms.vdouble(0.089),
            upBounds = cms.vdouble(-2, 999999999),
            values = cms.vdouble(0.966)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 0),
            uncertainties = cms.vdouble(0.0001),
            upBounds = cms.vdouble(-1.566, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 10),
            uncertainties = cms.vdouble(0.017),
            upBounds = cms.vdouble(-1.566, 20),
            values = cms.vdouble(0.962)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 20),
            uncertainties = cms.vdouble(0.012),
            upBounds = cms.vdouble(-1.566, 35),
            values = cms.vdouble(0.951)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 35),
            uncertainties = cms.vdouble(0.01),
            upBounds = cms.vdouble(-1.566, 50),
            values = cms.vdouble(0.968)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 50),
            uncertainties = cms.vdouble(0.002),
            upBounds = cms.vdouble(-1.566, 100),
            values = cms.vdouble(0.977)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 100),
            uncertainties = cms.vdouble(0.01),
            upBounds = cms.vdouble(-1.566, 200),
            values = cms.vdouble(0.983)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 200),
            uncertainties = cms.vdouble(0.043),
            upBounds = cms.vdouble(-1.566, 500),
            values = cms.vdouble(0.995)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 500),
            uncertainties = cms.vdouble(0.043),
            upBounds = cms.vdouble(-1.566, 99999999),
            values = cms.vdouble(0.995)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 0),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 10),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 10),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 20),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 20),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 35),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 35),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 50),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 50),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 100),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 100),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 200),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 200),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 500),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 500),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 9999999),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 0),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 10),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 10),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 20),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 20),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 35),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 35),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 50),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 50),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 100),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 100),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 200),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 200),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 500),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 500),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 9999999),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 0),
            uncertainties = cms.vdouble(0.001),
            upBounds = cms.vdouble(0, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 10),
            uncertainties = cms.vdouble(0.015),
            upBounds = cms.vdouble(0, 20),
            values = cms.vdouble(0.953)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 20),
            uncertainties = cms.vdouble(0.015),
            upBounds = cms.vdouble(0, 35),
            values = cms.vdouble(0.952)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 35),
            uncertainties = cms.vdouble(0.002),
            upBounds = cms.vdouble(0, 50),
            values = cms.vdouble(0.957)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 50),
            uncertainties = cms.vdouble(0.003),
            upBounds = cms.vdouble(0, 100),
            values = cms.vdouble(0.963)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 100),
            uncertainties = cms.vdouble(0.009),
            upBounds = cms.vdouble(0, 200),
            values = cms.vdouble(0.982)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 200),
            uncertainties = cms.vdouble(0.023),
            upBounds = cms.vdouble(0, 500),
            values = cms.vdouble(0.979)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 500),
            uncertainties = cms.vdouble(0.023),
            upBounds = cms.vdouble(0, 99999999),
            values = cms.vdouble(0.979)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 0),
            uncertainties = cms.vdouble(0.001),
            upBounds = cms.vdouble(0.8, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 10),
            uncertainties = cms.vdouble(0.015),
            upBounds = cms.vdouble(0.8, 20),
            values = cms.vdouble(0.954)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 20),
            uncertainties = cms.vdouble(0.015),
            upBounds = cms.vdouble(0.8, 35),
            values = cms.vdouble(0.966)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 35),
            uncertainties = cms.vdouble(0.002),
            upBounds = cms.vdouble(0.8, 50),
            values = cms.vdouble(0.976)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 50),
            uncertainties = cms.vdouble(0.003),
            upBounds = cms.vdouble(0.8, 100),
            values = cms.vdouble(0.979)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 100),
            uncertainties = cms.vdouble(0.009),
            upBounds = cms.vdouble(0.8, 200),
            values = cms.vdouble(0.991)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 200),
            uncertainties = cms.vdouble(0.023),
            upBounds = cms.vdouble(0.8, 500),
            values = cms.vdouble(0.976)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 500),
            uncertainties = cms.vdouble(0.023),
            upBounds = cms.vdouble(0.8, 99999999),
            values = cms.vdouble(0.976)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 0),
            uncertainties = cms.vdouble(0.001),
            upBounds = cms.vdouble(1.444, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 10),
            uncertainties = cms.vdouble(0.11),
            upBounds = cms.vdouble(1.444, 20),
            values = cms.vdouble(0.974)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 20),
            uncertainties = cms.vdouble(0.018),
            upBounds = cms.vdouble(1.444, 35),
            values = cms.vdouble(0.947)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 35),
            uncertainties = cms.vdouble(0.004),
            upBounds = cms.vdouble(1.444, 50),
            values = cms.vdouble(0.965)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 50),
            uncertainties = cms.vdouble(0.003),
            upBounds = cms.vdouble(1.444, 100),
            values = cms.vdouble(0.97)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 100),
            uncertainties = cms.vdouble(0.011),
            upBounds = cms.vdouble(1.444, 200),
            values = cms.vdouble(0.99)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 200),
            uncertainties = cms.vdouble(0.025),
            upBounds = cms.vdouble(1.444, 500),
            values = cms.vdouble(0.984)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 500),
            uncertainties = cms.vdouble(0.025),
            upBounds = cms.vdouble(1.444, 9999999),
            values = cms.vdouble(0.984)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 0),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 10),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 10),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 20),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 20),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 35),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 35),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 50),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 50),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 100),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 100),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 200),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 200),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 500),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 500),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 9999999),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 0),
            uncertainties = cms.vdouble(0.001),
            upBounds = cms.vdouble(2, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 10),
            uncertainties = cms.vdouble(0.017),
            upBounds = cms.vdouble(2, 20),
            values = cms.vdouble(0.971)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 20),
            uncertainties = cms.vdouble(0.012),
            upBounds = cms.vdouble(2, 35),
            values = cms.vdouble(0.933)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 35),
            uncertainties = cms.vdouble(0.01),
            upBounds = cms.vdouble(2, 50),
            values = cms.vdouble(0.957)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 50),
            uncertainties = cms.vdouble(0.002),
            upBounds = cms.vdouble(2, 100),
            values = cms.vdouble(0.968)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 100),
            uncertainties = cms.vdouble(0.011),
            upBounds = cms.vdouble(2, 200),
            values = cms.vdouble(0.995)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 200),
            uncertainties = cms.vdouble(0.043),
            upBounds = cms.vdouble(2, 500),
            values = cms.vdouble(0.952)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 500),
            uncertainties = cms.vdouble(0.043),
            upBounds = cms.vdouble(2, 99999999),
            values = cms.vdouble(0.952)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 0),
            uncertainties = cms.vdouble(0.001),
            upBounds = cms.vdouble(2.5, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 10),
            uncertainties = cms.vdouble(0.021),
            upBounds = cms.vdouble(2.5, 20),
            values = cms.vdouble(0.961)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 20),
            uncertainties = cms.vdouble(0.009),
            upBounds = cms.vdouble(2.5, 35),
            values = cms.vdouble(0.953)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 35),
            uncertainties = cms.vdouble(0.006),
            upBounds = cms.vdouble(2.5, 50),
            values = cms.vdouble(0.961)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 50),
            uncertainties = cms.vdouble(0.008),
            upBounds = cms.vdouble(2.5, 100),
            values = cms.vdouble(0.969)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 100),
            uncertainties = cms.vdouble(0.032),
            upBounds = cms.vdouble(2.5, 200),
            values = cms.vdouble(0.994)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 200),
            uncertainties = cms.vdouble(0.09),
            upBounds = cms.vdouble(2.5, 500),
            values = cms.vdouble(1.018)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 500),
            uncertainties = cms.vdouble(0.09),
            upBounds = cms.vdouble(2.5, 999999999),
            values = cms.vdouble(1.018)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2.5, 0.0),
            uncertainties = cms.vdouble(0.001),
            upBounds = cms.vdouble(6.0, 999999999.0),
            values = cms.vdouble(1.0)
        )
    ),
    variables = cms.vstring(
        'eta', 
        'pt'
    )
)

process.electronVetoBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.0023),
            upBounds = cms.vdouble(1.5, 0.85),
            values = cms.vdouble(0.982)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85),
            uncertainties = cms.vdouble(0.0006),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.9911)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.0076),
            upBounds = cms.vdouble(6.0, 0.9),
            values = cms.vdouble(0.9639)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9),
            uncertainties = cms.vdouble(0.002),
            upBounds = cms.vdouble(6.0, 999.0),
            values = cms.vdouble(0.983)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.electronVetoSF = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.0023),
                upBounds = cms.vdouble(1.5, 0.85),
                values = cms.vdouble(0.982)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85),
                uncertainties = cms.vdouble(0.0006),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.9911)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0076),
                upBounds = cms.vdouble(6.0, 0.9),
                values = cms.vdouble(0.9639)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9),
                uncertainties = cms.vdouble(0.002),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.983)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('electronVetoSF'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('1'),
    PhotonMethodName = cms.string('FlashggPhotonWeight')
)

process.emptyBins = cms.PSet(
    bins = cms.VPSet(),
    variables = cms.vstring('1')
)

process.emptySigma = cms.PSet(
    firstVar = cms.vint32(),
    secondVar = cms.vint32()
)

process.globalVariables = cms.PSet(
    dataPu = cms.vdouble(
        6.245e-06, 2.63e-05, 4.92e-05, 9.084e-05, 9.854e-05, 
        0.0001426, 0.0001557, 0.0001656, 0.0002269, 0.0005395, 
        0.001076, 0.002034, 0.003219, 0.004616, 0.006528, 
        0.009201, 0.01283, 0.01707, 0.02125, 0.0251, 
        0.02847, 0.03118, 0.03325, 0.03486, 0.03626, 
        0.03758, 0.0387, 0.03937, 0.03946, 0.03892, 
        0.03782, 0.03627, 0.03435, 0.03211, 0.02967, 
        0.02719, 0.02482, 0.02264, 0.0207, 0.01907, 
        0.01784, 0.01709, 0.01685, 0.0171, 0.01771, 
        0.01849, 0.01916, 0.01945, 0.01911, 0.01804, 
        0.01627, 0.01399, 0.01147, 0.008976, 0.006728, 
        0.004848, 0.003375, 0.002281, 0.001504, 0.0009715, 
        0.0006178, 0.0003882, 0.0002419, 0.0001501, 9.294e-05, 
        5.768e-05, 3.598e-05, 2.263e-05, 1.437e-05, 9.233e-06, 
        5.996e-06, 3.933e-06, 2.601e-06, 1.731e-06, 1.157e-06, 
        7.743e-07, 5.184e-07, 3.466e-07, 2.311e-07, 1.535e-07, 
        1.015e-07, 6.676e-08, 4.365e-08, 2.836e-08, 1.829e-08, 
        1.171e-08, 7.437e-09, 4.685e-09, 2.926e-09, 1.812e-09, 
        1.111e-09, 6.754e-10, 4.066e-10, 2.424e-10, 1.431e-10, 
        8.363e-11, 4.839e-11, 2.771e-11, 1.571e-11, 8.814e-12
    ),
    extraFloats = cms.PSet(

    ),
    mcPu = cms.vdouble(
        0.0238775, 0.000874622, 0.00124831, 0.00153105, 0.00147725, 
        0.00141303, 0.00126538, 0.00115647, 0.00218504, 0.00171699, 
        0.00229043, 0.00333221, 0.0048993, 0.00663561, 0.00897475, 
        0.011538, 0.0141801, 0.0169121, 0.0192551, 0.0214591, 
        0.0231318, 0.0243014, 0.0251415, 0.0257144, 0.0264036, 
        0.0272533, 0.0279565, 0.028333, 0.0282152, 0.0281867, 
        0.0280371, 0.0282786, 0.0282462, 0.0279432, 0.0276964, 
        0.0270571, 0.0259487, 0.0247456, 0.0239501, 0.0231562, 
        0.0214979, 0.0197288, 0.0179504, 0.0162761, 0.0148308, 
        0.0136544, 0.0125744, 0.0122772, 0.0120571, 0.0118004, 
        0.0120413, 0.0120674, 0.0120442, 0.0120637, 0.0119306, 
        0.0121372, 0.0119726, 0.0117524, 0.0113325, 0.0105063, 
        0.00941031, 0.00811139, 0.00662999, 0.00554745, 0.00434088, 
        0.00362642, 0.00318208, 0.00228125, 0.00171769, 0.00117662, 
        0.000909775, 0.000725548, 0.000478647, 0.000399337, 0.000367371, 
        0.000333013, 0.000231815, 0.000234494, 0.000226693, 0.000381801, 
        0.000485566, 0.000441125, 0.000234348, 0.000323903, 0.000166324, 
        0.000254228, 0.000143739, 0.000292395, 0.000254309, 0.000174261, 
        8.52316e-05, 5.89512e-05, 1.01815e-05, 3.82778e-05, 2.63483e-05, 
        0.000187418, 1.01005e-05, 2.22584e-05, 3.01709e-05, 3.36291e-05
    ),
    puBins = cms.vdouble(
        0.0, 1.0, 2.0, 3.0, 4.0, 
        5.0, 6.0, 7.0, 8.0, 9.0, 
        10.0, 11.0, 12.0, 13.0, 14.0, 
        15.0, 16.0, 17.0, 18.0, 19.0, 
        20.0, 21.0, 22.0, 23.0, 24.0, 
        25.0, 26.0, 27.0, 28.0, 29.0, 
        30.0, 31.0, 32.0, 33.0, 34.0, 
        35.0, 36.0, 37.0, 38.0, 39.0, 
        40.0, 41.0, 42.0, 43.0, 44.0, 
        45.0, 46.0, 47.0, 48.0, 49.0, 
        50.0, 51.0, 52.0, 53.0, 54.0, 
        55.0, 56.0, 57.0, 58.0, 59.0, 
        60.0, 61.0, 62.0, 63.0, 64.0, 
        65.0, 66.0, 67.0, 68.0, 69.0, 
        70.0, 71.0, 72.0, 73.0, 74.0, 
        75.0, 76.0, 77.0, 78.0, 79.0, 
        80.0, 81.0, 82.0, 83.0, 84.0, 
        85.0, 86.0, 87.0, 88.0, 89.0, 
        90.0, 91.0, 92.0, 93.0, 94.0, 
        95.0, 96.0, 97.0, 98.0, 99.0
    ),
    puInfo = cms.InputTag("slimmedAddPileupInfo"),
    puReWeight = cms.bool(True),
    rho = cms.InputTag("fixedGridRhoAll"),
    useTruePu = cms.bool(True),
    vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
)

process.leadPixelSeedBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, -0.1),
            uncertainties = cms.vdouble(-0.00401807),
            upBounds = cms.vdouble(1.5, 0.85, 0.1),
            values = cms.vdouble(0.978)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85, -0.1),
            uncertainties = cms.vdouble(-0.00200421),
            upBounds = cms.vdouble(1.5, 999.0, 0.1),
            values = cms.vdouble(0.9824)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0, -0.1),
            uncertainties = cms.vdouble(-0.0224756),
            upBounds = cms.vdouble(6.0, 0.9, 0.1),
            values = cms.vdouble(0.9168)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9, -0.1),
            uncertainties = cms.vdouble(-0.00631264),
            upBounds = cms.vdouble(6.0, 999.0, 0.1),
            values = cms.vdouble(0.9403)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 0.9),
            uncertainties = cms.vdouble(0.0162106),
            upBounds = cms.vdouble(1.5, 0.85, 1.1),
            values = cms.vdouble(1.08876)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85, 0.9),
            uncertainties = cms.vdouble(0.0678807),
            upBounds = cms.vdouble(1.5, 999.0, 1.1),
            values = cms.vdouble(1.5961)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0, 0.9),
            uncertainties = cms.vdouble(0.0263745),
            upBounds = cms.vdouble(6.0, 0.9, 1.1),
            values = cms.vdouble(1.09763)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9, 0.9),
            uncertainties = cms.vdouble(0.0214274),
            upBounds = cms.vdouble(6.0, 999.0, 1.1),
            values = cms.vdouble(1.20264)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9', 
        'hasPixelSeed'
    )
)

process.leadTriggerScaleBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 0.0),
            uncertainties = cms.vdouble(0.0015550248, 0.0015550248),
            upBounds = cms.vdouble(0.54, 1.5, 37.0),
            values = cms.vdouble(0.9204369513)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 37),
            uncertainties = cms.vdouble(0.0012001964, 0.0012001964),
            upBounds = cms.vdouble(0.54, 1.5, 40.0),
            values = cms.vdouble(0.9268543618)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 40.0),
            uncertainties = cms.vdouble(0.0010500218, 0.0010500218),
            upBounds = cms.vdouble(0.54, 1.5, 45.0),
            values = cms.vdouble(0.9296864506)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 45.0),
            uncertainties = cms.vdouble(0.0016928371, 0.0016928371),
            upBounds = cms.vdouble(0.54, 1.5, 50.0),
            values = cms.vdouble(0.9312181087)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 50.0),
            uncertainties = cms.vdouble(0.0024479457, 0.0024479457),
            upBounds = cms.vdouble(0.54, 1.5, 60.0),
            values = cms.vdouble(0.9349061049)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 60.0),
            uncertainties = cms.vdouble(0.0052975139, 0.0052975139),
            upBounds = cms.vdouble(0.54, 1.5, 70.0),
            values = cms.vdouble(0.9425532022)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 70.0),
            uncertainties = cms.vdouble(0.0089854906, 0.0089854906),
            upBounds = cms.vdouble(0.54, 1.5, 90.0),
            values = cms.vdouble(0.9347621741)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 90.0),
            uncertainties = cms.vdouble(0.017714307, 0.017714307),
            upBounds = cms.vdouble(0.54, 1.5, 99999999),
            values = cms.vdouble(0.9489236873)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 0.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 37.0),
            values = cms.vdouble(0.9505374744)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 37.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 40.0),
            values = cms.vdouble(0.9559316002)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 45.0),
            values = cms.vdouble(0.960322746)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 45.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 50.0),
            values = cms.vdouble(0.9628461917)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 50.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 60.0),
            values = cms.vdouble(0.9662884361)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 60.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 70.0),
            values = cms.vdouble(0.9715136996)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 70.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 90.0),
            values = cms.vdouble(0.9753661262)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 90.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 99999999),
            values = cms.vdouble(0.9818196687)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 0.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 37.0),
            values = cms.vdouble(0.9630117411)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 37.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 40.0),
            values = cms.vdouble(0.9680310533)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 45.0),
            values = cms.vdouble(0.9721152461)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 45.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 50.0),
            values = cms.vdouble(0.9748189645)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 50.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 60.0),
            values = cms.vdouble(0.9747597366)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 60.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 70.0),
            values = cms.vdouble(0.9753162174)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 70.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 90.0),
            values = cms.vdouble(0.9803243059)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 90.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 99999999),
            values = cms.vdouble(0.9865482764)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 0.0),
            uncertainties = cms.vdouble(0.0017122892, 0.0017122892),
            upBounds = cms.vdouble(0.84, 3.0, 37.0),
            values = cms.vdouble(0.9093169942)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 37.0),
            uncertainties = cms.vdouble(0.0012578761, 0.0012578761),
            upBounds = cms.vdouble(0.84, 3.0, 40.0),
            values = cms.vdouble(0.9214136806)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.84, 3.0, 45.0),
            values = cms.vdouble(0.9396498081)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 45.0),
            uncertainties = cms.vdouble(0.0013009169, 0.0013009169),
            upBounds = cms.vdouble(0.84, 3.0, 50.0),
            values = cms.vdouble(0.9455103913)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 50.0),
            uncertainties = cms.vdouble(0.00165793, 0.00165793),
            upBounds = cms.vdouble(0.84, 3.0, 60.0),
            values = cms.vdouble(0.9519493209)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 60.0),
            uncertainties = cms.vdouble(0.0031358462, 0.0031358462),
            upBounds = cms.vdouble(0.84, 3.0, 70.0),
            values = cms.vdouble(0.9560088523)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 70.0),
            uncertainties = cms.vdouble(0.0036329374, 0.0036329374),
            upBounds = cms.vdouble(0.84, 3.0, 90.0),
            values = cms.vdouble(0.9638480843)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 90.0),
            uncertainties = cms.vdouble(0.0051321702, 0.0051321702),
            upBounds = cms.vdouble(0.84, 3.0, 99999999),
            values = cms.vdouble(0.9714734218)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 0.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 37.0),
            values = cms.vdouble(0.961495108)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 37.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 40.0),
            values = cms.vdouble(0.9750837371)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 45.0),
            values = cms.vdouble(0.9814701227)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 45.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 50.0),
            values = cms.vdouble(0.9835352074)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 50.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 60.0),
            values = cms.vdouble(0.9851237595)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 60.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 70.0),
            values = cms.vdouble(0.9869551174)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 70.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 90.0),
            values = cms.vdouble(0.9916069861)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 90.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 99999999),
            values = cms.vdouble(0.9958525312)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 0.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 37.0),
            values = cms.vdouble(0.9470889409)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 37.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 40.0),
            values = cms.vdouble(0.9646677794)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 45.0),
            values = cms.vdouble(0.9738993606)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 45.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 50.0),
            values = cms.vdouble(0.9784039943)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 50.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 60.0),
            values = cms.vdouble(0.980234517)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 60.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 70.0),
            values = cms.vdouble(0.9828741312)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 70.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 90.0),
            values = cms.vdouble(0.9870534958)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 90.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 99999999),
            values = cms.vdouble(0.9891255039)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 3.0, 0),
            uncertainties = cms.vdouble(1.0, 1.0),
            upBounds = cms.vdouble(999, 999, 999999),
            values = cms.vdouble(1.0)
        )
    ),
    variables = cms.vstring(
        'full5x5_r9', 
        'abs(superCluster.eta)', 
        'pt'
    )
)

process.looseMvaBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.0001),
            upBounds = cms.vdouble(1.5, 0.85),
            values = cms.vdouble(0.9999)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85),
            uncertainties = cms.vdouble(0.0),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(1.0003)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.0),
            upBounds = cms.vdouble(6.0, 0.9),
            values = cms.vdouble(1.0003)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9),
            uncertainties = cms.vdouble(0.0),
            upBounds = cms.vdouble(6.0, 999.0),
            values = cms.vdouble(1.0004)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.materialBinsICHEP = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.0007),
            upBounds = cms.vdouble(1.5, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.94),
            uncertainties = cms.vdouble(0.00036),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.00089),
            upBounds = cms.vdouble(6.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9),
            uncertainties = cms.vdouble(0.0017),
            upBounds = cms.vdouble(6.0, 999.0),
            values = cms.vdouble(0.0)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.materialBinsMoriond17 = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.000455),
            upBounds = cms.vdouble(1.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.94),
            uncertainties = cms.vdouble(0.000233),
            upBounds = cms.vdouble(1.0, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.0, 0.0),
            uncertainties = cms.vdouble(0.002089),
            upBounds = cms.vdouble(1.5, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.0, 0.94),
            uncertainties = cms.vdouble(0.002089),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.00109),
            upBounds = cms.vdouble(999.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.94),
            uncertainties = cms.vdouble(0.002377),
            upBounds = cms.vdouble(999.0, 999.0),
            values = cms.vdouble(0.0)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.materialBinsRun1 = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.00035),
            upBounds = cms.vdouble(0.8, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.94),
            uncertainties = cms.vdouble(0.00033),
            upBounds = cms.vdouble(0.8, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 0.0),
            uncertainties = cms.vdouble(0.00058),
            upBounds = cms.vdouble(1.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 0.94),
            uncertainties = cms.vdouble(0.0012),
            upBounds = cms.vdouble(1.0, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.0, 0.0),
            uncertainties = cms.vdouble(0.0022),
            upBounds = cms.vdouble(1.5, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.0, 0.94),
            uncertainties = cms.vdouble(0.0034),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.0022),
            upBounds = cms.vdouble(999.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.94),
            uncertainties = cms.vdouble(0.0034),
            upBounds = cms.vdouble(999.0, 999.0),
            values = cms.vdouble(0.0)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.maxEvents = cms.untracked.PSet(
    input = cms.untracked.int32(-1)
)

process.metJecSmear = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    Debug = cms.untracked.bool(False),
    Label = cms.string('metJecUncertainty'),
    MethodName = cms.string('FlashggMetJecSmear'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(eta)<2.5')
)

process.metJerSmear = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    Debug = cms.untracked.bool(False),
    Label = cms.string('metJerUncertainty'),
    MethodName = cms.string('FlashggMetJerSmear'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(eta)<2.5')
)

process.metPhoSmear = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    Debug = cms.untracked.bool(False),
    Label = cms.string('metPhoUncertainty'),
    MethodName = cms.string('FlashggMetPhoSmear'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(eta)<2.5')
)

process.metUncSmear = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    Debug = cms.untracked.bool(False),
    Label = cms.string('metUncUncertainty'),
    MethodName = cms.string('FlashggMetUncSmear'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(eta)<2.5')
)

process.mvaShiftBins = cms.PSet(
    bins = cms.VPSet(cms.PSet(
        lowBounds = cms.vdouble(0.0),
        uncertainties = cms.vdouble(0.0),
        upBounds = cms.vdouble(999.0),
        values = cms.vdouble(0.0)
    )),
    variables = cms.vstring('abs(superCluster.eta)')
)

process.options = cms.untracked.PSet(
    allowUnscheduled = cms.untracked.bool(True),
    wantSummary = cms.untracked.bool(True)
)

process.photonScaleUncertBins = cms.PSet(

)

process.photonSmearBins = cms.PSet(

)

process.preselBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.005),
            upBounds = cms.vdouble(1.5, 0.85),
            values = cms.vdouble(0.998)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85),
            uncertainties = cms.vdouble(0.003),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(1.001)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.006),
            upBounds = cms.vdouble(6.0, 0.9),
            values = cms.vdouble(0.989)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9),
            uncertainties = cms.vdouble(0.009),
            upBounds = cms.vdouble(6.0, 999.0),
            values = cms.vdouble(1.002)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.regressionModifier = cms.PSet(
    eOverP_ECALTRKThr = cms.double(0.025),
    electron_config = cms.PSet(
        regressionKey = cms.vstring(
            'electron_eb_ECALonly_lowpt', 
            'electron_eb_ECALonly', 
            'electron_ee_ECALonly_lowpt', 
            'electron_ee_ECALonly', 
            'electron_eb_ECALTRK_lowpt', 
            'electron_eb_ECALTRK', 
            'electron_ee_ECALTRK_lowpt', 
            'electron_ee_ECALTRK'
        ),
        uncertaintyKey = cms.vstring(
            'electron_eb_ECALonly_lowpt_var', 
            'electron_eb_ECALonly_var', 
            'electron_ee_ECALonly_lowpt_var', 
            'electron_ee_ECALonly_var', 
            'electron_eb_ECALTRK_lowpt_var', 
            'electron_eb_ECALTRK_var', 
            'electron_ee_ECALTRK_lowpt_var', 
            'electron_ee_ECALTRK_var'
        )
    ),
    epDiffSig_ECALTRKThr = cms.double(15.0),
    epSig_ECALTRKThr = cms.double(10.0),
    forceHighEnergyEcalTrainingIfSaturated = cms.bool(True),
    highEnergy_ECALTRKThr = cms.double(200.0),
    lowEnergy_ECALTRKThr = cms.double(50.0),
    lowEnergy_ECALonlyThr = cms.double(99999.0),
    modifierName = cms.string('EGRegressionModifierV2'),
    photon_config = cms.PSet(
        regressionKey = cms.vstring(
            'photon_eb_ECALonly_lowpt', 
            'photon_eb_ECALonly', 
            'photon_ee_ECALonly_lowpt', 
            'photon_ee_ECALonly'
        ),
        uncertaintyKey = cms.vstring(
            'photon_eb_ECALonly_lowpt_var', 
            'photon_eb_ECALonly_var', 
            'photon_ee_ECALonly_lowpt_var', 
            'photon_ee_ECALonly_var'
        )
    ),
    rhoCollection = cms.InputTag("fixedGridRhoFastjetAll")
)

process.showerShapeBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(-0.0001),
            upBounds = cms.vdouble(1.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.0, 0.0),
            uncertainties = cms.vdouble(0.0002),
            upBounds = cms.vdouble(1.5, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.94),
            uncertainties = cms.vdouble(-0.0006),
            upBounds = cms.vdouble(1.0, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.0, 0.94),
            uncertainties = cms.vdouble(-0.0011),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.0015),
            upBounds = cms.vdouble(2.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2.0, 0.0),
            uncertainties = cms.vdouble(0.0004),
            upBounds = cms.vdouble(6.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.94),
            uncertainties = cms.vdouble(0.0002),
            upBounds = cms.vdouble(2.0, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2.0, 0.94),
            uncertainties = cms.vdouble(0.0003),
            upBounds = cms.vdouble(6.0, 999.0),
            values = cms.vdouble(0.0)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.sigmaEOverEShiftBins = cms.PSet(
    bins = cms.VPSet(cms.PSet(
        lowBounds = cms.vdouble(0.0),
        uncertainties = cms.vdouble(0.05),
        upBounds = cms.vdouble(999.0),
        values = cms.vdouble(0.0)
    )),
    variables = cms.vstring('abs(superCluster.eta)')
)

process.subleadPixelSeedBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, -0.1),
            uncertainties = cms.vdouble(-0.00415083),
            upBounds = cms.vdouble(1.5, 0.85, 0.1),
            values = cms.vdouble(0.978)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85, -0.1),
            uncertainties = cms.vdouble(-0.00280026),
            upBounds = cms.vdouble(1.5, 999.0, 0.1),
            values = cms.vdouble(0.9824)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0, -0.1),
            uncertainties = cms.vdouble(-0.0225538),
            upBounds = cms.vdouble(6.0, 0.9, 0.1),
            values = cms.vdouble(0.9168)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9, -0.1),
            uncertainties = cms.vdouble(-0.00655045),
            upBounds = cms.vdouble(6.0, 999.0, 0.1),
            values = cms.vdouble(0.9403)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 0.9),
            uncertainties = cms.vdouble(0.0248967),
            upBounds = cms.vdouble(1.5, 0.85, 1.1),
            values = cms.vdouble(1.13196)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85, 0.9),
            uncertainties = cms.vdouble(0.0978689),
            upBounds = cms.vdouble(1.5, 999.0, 1.1),
            values = cms.vdouble(1.61512)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0, 0.9),
            uncertainties = cms.vdouble(0.0287957),
            upBounds = cms.vdouble(6.0, 0.9, 1.1),
            values = cms.vdouble(1.10623)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9, 0.9),
            uncertainties = cms.vdouble(0.0222861),
            upBounds = cms.vdouble(6.0, 999.0, 1.1),
            values = cms.vdouble(1.20311)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9', 
        'hasPixelSeed'
    )
)

process.subleadTriggerScaleBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 0.0),
            uncertainties = cms.vdouble(0.001420359, 0.001420359),
            upBounds = cms.vdouble(0.54, 1.5, 28.0),
            values = cms.vdouble(0.9503915847)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 28.0),
            uncertainties = cms.vdouble(0.0011666773, 0.0011666773),
            upBounds = cms.vdouble(0.54, 1.5, 31.0),
            values = cms.vdouble(0.9563040539)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 31.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.54, 1.5, 35.0),
            values = cms.vdouble(0.9554701294)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 35.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.54, 1.5, 40.0),
            values = cms.vdouble(0.9573495211)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.54, 1.5, 45.0),
            values = cms.vdouble(0.9615640328)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 45.0),
            uncertainties = cms.vdouble(0.0012149116, 0.0012149116),
            upBounds = cms.vdouble(0.54, 1.5, 50.0),
            values = cms.vdouble(0.9635847522)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 50.0),
            uncertainties = cms.vdouble(0.0018398439, 0.0018398439),
            upBounds = cms.vdouble(0.54, 1.5, 60.0),
            values = cms.vdouble(0.9613424282)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 60.0),
            uncertainties = cms.vdouble(0.0046295174, 0.0046295174),
            upBounds = cms.vdouble(0.54, 1.5, 70.0),
            values = cms.vdouble(0.953179846)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 70.0),
            uncertainties = cms.vdouble(0.0082547803, 0.0082547803),
            upBounds = cms.vdouble(0.54, 1.5, 90.0),
            values = cms.vdouble(0.9427949472)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 90.0),
            uncertainties = cms.vdouble(0.0210727517, 0.0210727517),
            upBounds = cms.vdouble(0.54, 1.5, 99999999),
            values = cms.vdouble(0.9180892383)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 0.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 28.0),
            values = cms.vdouble(0.9821722615)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 28.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 31.0),
            values = cms.vdouble(0.9846684256)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 31.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 35.0),
            values = cms.vdouble(0.9853409044)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 35.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 40.0),
            values = cms.vdouble(0.9851741151)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 45.0),
            values = cms.vdouble(0.9847237955)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 45.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 50.0),
            values = cms.vdouble(0.9836985511)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 50.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 60.0),
            values = cms.vdouble(0.9818687985)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 60.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 70.0),
            values = cms.vdouble(0.9793978257)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 70.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 90.0),
            values = cms.vdouble(0.9766027088)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 90.0),
            uncertainties = cms.vdouble(0.0011171683, 0.0011171683),
            upBounds = cms.vdouble(0.85, 1.5, 99999999),
            values = cms.vdouble(0.972331437)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 0.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 28.0),
            values = cms.vdouble(0.9997101832)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 28.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 31.0),
            values = cms.vdouble(0.9998675478)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 31.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 35.0),
            values = cms.vdouble(0.9999351175)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 35.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 40.0),
            values = cms.vdouble(0.999954156)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 45.0),
            values = cms.vdouble(0.9999645283)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 45.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 50.0),
            values = cms.vdouble(0.9999677894)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 50.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 60.0),
            values = cms.vdouble(0.9999665309)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 60.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 70.0),
            values = cms.vdouble(0.9999602573)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 70.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 90.0),
            values = cms.vdouble(0.9999369329)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 90.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 99999999),
            values = cms.vdouble(0.9999456063)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 0.0),
            uncertainties = cms.vdouble(0.0027302573, 0.0027302573),
            upBounds = cms.vdouble(0.84, 3.0, 28.0),
            values = cms.vdouble(0.8799714219)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 28.0),
            uncertainties = cms.vdouble(0.0021032366, 0.0021032366),
            upBounds = cms.vdouble(0.84, 3.0, 31.0),
            values = cms.vdouble(0.8962741603)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 31.0),
            uncertainties = cms.vdouble(0.0014198635, 0.0014198635),
            upBounds = cms.vdouble(0.84, 3.0, 35.0),
            values = cms.vdouble(0.9042685088)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 35.0),
            uncertainties = cms.vdouble(0.0010478241, 0.0010478241),
            upBounds = cms.vdouble(0.84, 3.0, 40.0),
            values = cms.vdouble(0.9130894467)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 40.0),
            uncertainties = cms.vdouble(0.0010511874, 0.0010511874),
            upBounds = cms.vdouble(0.84, 3.0, 45.0),
            values = cms.vdouble(0.9236887059)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 45.0),
            uncertainties = cms.vdouble(0.0015068743, 0.0015068743),
            upBounds = cms.vdouble(0.84, 3.0, 50.0),
            values = cms.vdouble(0.926909296)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 50.0),
            uncertainties = cms.vdouble(0.001993287, 0.001993287),
            upBounds = cms.vdouble(0.84, 3.0, 60.0),
            values = cms.vdouble(0.9300621013)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 60.0),
            uncertainties = cms.vdouble(0.0038708618, 0.0038708618),
            upBounds = cms.vdouble(0.84, 3.0, 70.0),
            values = cms.vdouble(0.9313708557)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 70.0),
            uncertainties = cms.vdouble(0.0046452036, 0.0046452036),
            upBounds = cms.vdouble(0.84, 3.0, 90.0),
            values = cms.vdouble(0.9387860583)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 90.0),
            uncertainties = cms.vdouble(0.007718235, 0.007718235),
            upBounds = cms.vdouble(0.84, 3.0, 99999999),
            values = cms.vdouble(0.9316696569)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 0.0),
            uncertainties = cms.vdouble(0.0011380402, 0.0011380402),
            upBounds = cms.vdouble(0.9, 3.0, 28.0),
            values = cms.vdouble(0.9482346612)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 28.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 31.0),
            values = cms.vdouble(0.9753440965)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 31.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 35.0),
            values = cms.vdouble(0.9760310914)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 35.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 40.0),
            values = cms.vdouble(0.9752981073)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 45.0),
            values = cms.vdouble(0.973705016)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 45.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 50.0),
            values = cms.vdouble(0.9719236369)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 50.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 60.0),
            values = cms.vdouble(0.9704295117)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 60.0),
            uncertainties = cms.vdouble(0.0014503236, 0.0014503236),
            upBounds = cms.vdouble(0.9, 3.0, 70.0),
            values = cms.vdouble(0.9692422639)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 70.0),
            uncertainties = cms.vdouble(0.0018171502, 0.0018171502),
            upBounds = cms.vdouble(0.9, 3.0, 90.0),
            values = cms.vdouble(0.9692330221)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 90.0),
            uncertainties = cms.vdouble(0.0024173224, 0.0024173224),
            upBounds = cms.vdouble(0.9, 3.0, 99999999),
            values = cms.vdouble(0.972663036)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 0.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 28.0),
            values = cms.vdouble(0.9706915047)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 28.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 31.0),
            values = cms.vdouble(0.9975115605)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 31.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 35.0),
            values = cms.vdouble(0.9992706525)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 35.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 40.0),
            values = cms.vdouble(0.9995305126)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 45.0),
            values = cms.vdouble(0.9995836941)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 45.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 50.0),
            values = cms.vdouble(0.9996279004)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 50.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 60.0),
            values = cms.vdouble(0.9995678968)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 60.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 70.0),
            values = cms.vdouble(0.9996782105)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 70.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 90.0),
            values = cms.vdouble(0.9997202663)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 90.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 99999999),
            values = cms.vdouble(0.9993842985)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 3.0, 0),
            uncertainties = cms.vdouble(1.0, 1.0),
            upBounds = cms.vdouble(999, 999, 999999),
            values = cms.vdouble(1.0)
        )
    ),
    variables = cms.vstring(
        'full5x5_r9', 
        'abs(superCluster.eta)', 
        'pt'
    )
)

process.tagsDumpConfig = cms.PSet(
    categories = cms.VPSet(),
    className = cms.untracked.string(''),
    classifierCfg = cms.PSet(
        categories = cms.VPSet()
    ),
    dumpGlobalVariables = cms.untracked.bool(True),
    dumpHistos = cms.untracked.bool(False),
    dumpTrees = cms.untracked.bool(False),
    dumpWorkspace = cms.untracked.bool(False),
    generatorInfo = cms.InputTag("generator"),
    globalVariables = cms.PSet(
        dataPu = cms.vdouble(
            6.245e-06, 2.63e-05, 4.92e-05, 9.084e-05, 9.854e-05, 
            0.0001426, 0.0001557, 0.0001656, 0.0002269, 0.0005395, 
            0.001076, 0.002034, 0.003219, 0.004616, 0.006528, 
            0.009201, 0.01283, 0.01707, 0.02125, 0.0251, 
            0.02847, 0.03118, 0.03325, 0.03486, 0.03626, 
            0.03758, 0.0387, 0.03937, 0.03946, 0.03892, 
            0.03782, 0.03627, 0.03435, 0.03211, 0.02967, 
            0.02719, 0.02482, 0.02264, 0.0207, 0.01907, 
            0.01784, 0.01709, 0.01685, 0.0171, 0.01771, 
            0.01849, 0.01916, 0.01945, 0.01911, 0.01804, 
            0.01627, 0.01399, 0.01147, 0.008976, 0.006728, 
            0.004848, 0.003375, 0.002281, 0.001504, 0.0009715, 
            0.0006178, 0.0003882, 0.0002419, 0.0001501, 9.294e-05, 
            5.768e-05, 3.598e-05, 2.263e-05, 1.437e-05, 9.233e-06, 
            5.996e-06, 3.933e-06, 2.601e-06, 1.731e-06, 1.157e-06, 
            7.743e-07, 5.184e-07, 3.466e-07, 2.311e-07, 1.535e-07, 
            1.015e-07, 6.676e-08, 4.365e-08, 2.836e-08, 1.829e-08, 
            1.171e-08, 7.437e-09, 4.685e-09, 2.926e-09, 1.812e-09, 
            1.111e-09, 6.754e-10, 4.066e-10, 2.424e-10, 1.431e-10, 
            8.363e-11, 4.839e-11, 2.771e-11, 1.571e-11, 8.814e-12
        ),
        extraFloats = cms.PSet(

        ),
        mcPu = cms.vdouble(
            0.0238775, 0.000874622, 0.00124831, 0.00153105, 0.00147725, 
            0.00141303, 0.00126538, 0.00115647, 0.00218504, 0.00171699, 
            0.00229043, 0.00333221, 0.0048993, 0.00663561, 0.00897475, 
            0.011538, 0.0141801, 0.0169121, 0.0192551, 0.0214591, 
            0.0231318, 0.0243014, 0.0251415, 0.0257144, 0.0264036, 
            0.0272533, 0.0279565, 0.028333, 0.0282152, 0.0281867, 
            0.0280371, 0.0282786, 0.0282462, 0.0279432, 0.0276964, 
            0.0270571, 0.0259487, 0.0247456, 0.0239501, 0.0231562, 
            0.0214979, 0.0197288, 0.0179504, 0.0162761, 0.0148308, 
            0.0136544, 0.0125744, 0.0122772, 0.0120571, 0.0118004, 
            0.0120413, 0.0120674, 0.0120442, 0.0120637, 0.0119306, 
            0.0121372, 0.0119726, 0.0117524, 0.0113325, 0.0105063, 
            0.00941031, 0.00811139, 0.00662999, 0.00554745, 0.00434088, 
            0.00362642, 0.00318208, 0.00228125, 0.00171769, 0.00117662, 
            0.000909775, 0.000725548, 0.000478647, 0.000399337, 0.000367371, 
            0.000333013, 0.000231815, 0.000234494, 0.000226693, 0.000381801, 
            0.000485566, 0.000441125, 0.000234348, 0.000323903, 0.000166324, 
            0.000254228, 0.000143739, 0.000292395, 0.000254309, 0.000174261, 
            8.52316e-05, 5.89512e-05, 1.01815e-05, 3.82778e-05, 2.63483e-05, 
            0.000187418, 1.01005e-05, 2.22584e-05, 3.01709e-05, 3.36291e-05
        ),
        puBins = cms.vdouble(
            0.0, 1.0, 2.0, 3.0, 4.0, 
            5.0, 6.0, 7.0, 8.0, 9.0, 
            10.0, 11.0, 12.0, 13.0, 14.0, 
            15.0, 16.0, 17.0, 18.0, 19.0, 
            20.0, 21.0, 22.0, 23.0, 24.0, 
            25.0, 26.0, 27.0, 28.0, 29.0, 
            30.0, 31.0, 32.0, 33.0, 34.0, 
            35.0, 36.0, 37.0, 38.0, 39.0, 
            40.0, 41.0, 42.0, 43.0, 44.0, 
            45.0, 46.0, 47.0, 48.0, 49.0, 
            50.0, 51.0, 52.0, 53.0, 54.0, 
            55.0, 56.0, 57.0, 58.0, 59.0, 
            60.0, 61.0, 62.0, 63.0, 64.0, 
            65.0, 66.0, 67.0, 68.0, 69.0, 
            70.0, 71.0, 72.0, 73.0, 74.0, 
            75.0, 76.0, 77.0, 78.0, 79.0, 
            80.0, 81.0, 82.0, 83.0, 84.0, 
            85.0, 86.0, 87.0, 88.0, 89.0, 
            90.0, 91.0, 92.0, 93.0, 94.0, 
            95.0, 96.0, 97.0, 98.0, 99.0
        ),
        puInfo = cms.InputTag("slimmedAddPileupInfo"),
        puReWeight = cms.bool(True),
        rho = cms.InputTag("fixedGridRhoAll"),
        useTruePu = cms.bool(True),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    intLumi = cms.untracked.double(1000.0),
    lumiWeight = cms.double(1.08733561742e-05),
    maxCandPerEvent = cms.int32(-1),
    nameTemplate = cms.untracked.string('$PROCESS_$SQRTS_$CLASSNAME_$SUBCAT_$LABEL'),
    processId = cms.string('ggF_node8_WWgg_lnulnugg'),
    processIndex = cms.int32(-2147483647),
    quietRooFit = cms.untracked.bool(False),
    src = cms.InputTag(""),
    workspaceName = cms.untracked.string('cms_hgg_$SQRTS')
)

process.ak4CaloL1FastL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1FastjetCorrector", "ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector")
)


process.ak4CaloL1FastL2L3L6Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1FastjetCorrector", "ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector", "ak4CaloL6SLBCorrector")
)


process.ak4CaloL1FastL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1FastjetCorrector", "ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector", "ak4CaloResidualCorrector")
)


process.ak4CaloL1FastjetCorrector = cms.EDProducer("L1FastjetCorrectorProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L1FastJet'),
    srcRho = cms.InputTag("fixedGridRhoFastjetAllCalo")
)


process.ak4CaloL1L2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1OffsetCorrector", "ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector")
)


process.ak4CaloL1L2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1OffsetCorrector", "ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector", "ak4CaloResidualCorrector")
)


process.ak4CaloL1OffsetCorrector = cms.EDProducer("L1OffsetCorrectorProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L1Offset'),
    minVtxNdof = cms.int32(4),
    vertexCollection = cms.InputTag("offlinePrimaryVertices")
)


process.ak4CaloL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector")
)


process.ak4CaloL2L3L6Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector", "ak4CaloL6SLBCorrector")
)


process.ak4CaloL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector", "ak4CaloResidualCorrector")
)


process.ak4CaloL2RelativeCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L2Relative')
)


process.ak4CaloL3AbsoluteCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L3Absolute')
)


process.ak4CaloL6SLBCorrector = cms.EDProducer("L6SLBCorrectorProducer",
    addMuonToJet = cms.bool(True),
    algorithm = cms.string(''),
    level = cms.string('L6SLB'),
    srcBTagInfoElectron = cms.InputTag("ak4CaloJetsSoftElectronTagInfos"),
    srcBTagInfoMuon = cms.InputTag("ak4CaloJetsSoftMuonTagInfos")
)


process.ak4CaloResidualCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L2L3Residual')
)


process.ak4JPTL1FastL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1FastjetCorrector", "ak4L1JPTFastjetCorrector", "ak4JPTL2RelativeCorrector", "ak4JPTL3AbsoluteCorrector")
)


process.ak4JPTL1FastL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1FastjetCorrector", "ak4L1JPTFastjetCorrector", "ak4JPTL2RelativeCorrector", "ak4JPTL3AbsoluteCorrector", "ak4JPTResidualCorrector")
)


process.ak4JPTL1L2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1OffsetCorrector", "ak4L1JPTOffsetCorrector", "ak4JPTL2RelativeCorrector", "ak4JPTL3AbsoluteCorrector")
)


process.ak4JPTL1L2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1OffsetCorrector", "ak4L1JPTOffsetCorrector", "ak4JPTL2RelativeCorrector", "ak4JPTL3AbsoluteCorrector", "ak4JPTResidualCorrector")
)


process.ak4JPTL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1OffsetCorrector", "ak4L1JPTOffsetCorrector", "ak4JPTL2RelativeCorrector", "ak4JPTL3AbsoluteCorrector")
)


process.ak4JPTL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1OffsetCorrector", "ak4L1JPTOffsetCorrector", "ak4JPTL2RelativeCorrector", "ak4JPTL3AbsoluteCorrector", "ak4JPTResidualCorrector")
)


process.ak4JPTL2RelativeCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L2Relative')
)


process.ak4JPTL3AbsoluteCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L3Absolute')
)


process.ak4JPTResidualCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L2L3Residual')
)


process.ak4L1JPTFastjetCorrector = cms.EDProducer("L1JPTOffsetCorrectorProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L1JPTOffset'),
    offsetService = cms.InputTag("ak4CaloL1FastjetCorrector")
)


process.ak4L1JPTOffsetCorrector = cms.EDProducer("L1JPTOffsetCorrectorProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L1JPTOffset'),
    offsetService = cms.InputTag("ak4CaloL1OffsetCorrector")
)


process.ak4PFCHSL1FastL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFCHSL1FastjetCorrector", "ak4PFCHSL2RelativeCorrector", "ak4PFCHSL3AbsoluteCorrector")
)


process.ak4PFCHSL1FastL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFCHSL1FastjetCorrector", "ak4PFCHSL2RelativeCorrector", "ak4PFCHSL3AbsoluteCorrector", "ak4PFCHSResidualCorrector")
)


process.ak4PFCHSL1FastjetCorrector = cms.EDProducer("L1FastjetCorrectorProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L1FastJet'),
    srcRho = cms.InputTag("fixedGridRhoFastjetAll")
)


process.ak4PFCHSL1L2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFCHSL1OffsetCorrector", "ak4PFCHSL2RelativeCorrector", "ak4PFCHSL3AbsoluteCorrector")
)


process.ak4PFCHSL1L2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFCHSL1OffsetCorrector", "ak4PFCHSL2RelativeCorrector", "ak4PFCHSL3AbsoluteCorrector", "ak4PFCHSResidualCorrector")
)


process.ak4PFCHSL1OffsetCorrector = cms.EDProducer("L1OffsetCorrectorProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L1Offset'),
    minVtxNdof = cms.int32(4),
    vertexCollection = cms.InputTag("offlinePrimaryVertices")
)


process.ak4PFCHSL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFCHSL2RelativeCorrector", "ak4PFCHSL3AbsoluteCorrector")
)


process.ak4PFCHSL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFCHSL2RelativeCorrector", "ak4PFCHSL3AbsoluteCorrector", "ak4PFCHSResidualCorrector")
)


process.ak4PFCHSL2RelativeCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L2Relative')
)


process.ak4PFCHSL3AbsoluteCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L3Absolute')
)


process.ak4PFCHSResidualCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L2L3Residual')
)


process.ak4PFL1FastL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL1FastjetCorrector", "ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector")
)


process.ak4PFL1FastL2L3L6Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL1FastjetCorrector", "ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector", "ak4PFL6SLBCorrector")
)


process.ak4PFL1FastL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL1FastjetCorrector", "ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector", "ak4PFResidualCorrector")
)


process.ak4PFL1FastjetCorrector = cms.EDProducer("L1FastjetCorrectorProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L1FastJet'),
    srcRho = cms.InputTag("fixedGridRhoFastjetAll")
)


process.ak4PFL1L2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL1OffsetCorrector", "ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector")
)


process.ak4PFL1L2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL1OffsetCorrector", "ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector", "ak4PFResidualCorrector")
)


process.ak4PFL1OffsetCorrector = cms.EDProducer("L1OffsetCorrectorProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L1Offset'),
    minVtxNdof = cms.int32(4),
    vertexCollection = cms.InputTag("offlinePrimaryVertices")
)


process.ak4PFL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector")
)


process.ak4PFL2L3L6Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector", "ak4PFL6SLBCorrector")
)


process.ak4PFL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector", "ak4PFResidualCorrector")
)


process.ak4PFL2RelativeCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L2Relative')
)


process.ak4PFL3AbsoluteCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L3Absolute')
)


process.ak4PFL6SLBCorrector = cms.EDProducer("L6SLBCorrectorProducer",
    addMuonToJet = cms.bool(False),
    algorithm = cms.string(''),
    level = cms.string('L6SLB'),
    srcBTagInfoElectron = cms.InputTag("ak4PFJetsSoftElectronTagInfos"),
    srcBTagInfoMuon = cms.InputTag("ak4PFJetsSoftMuonTagInfos")
)


process.ak4PFPuppiL1FastL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFPuppiL1FastjetCorrector", "ak4PFPuppiL2RelativeCorrector", "ak4PFPuppiL3AbsoluteCorrector")
)


process.ak4PFPuppiL1FastL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFPuppiL1FastjetCorrector", "ak4PFPuppiL2RelativeCorrector", "ak4PFPuppiL3AbsoluteCorrector", "ak4PFPuppiResidualCorrector")
)


process.ak4PFPuppiL1FastjetCorrector = cms.EDProducer("L1FastjetCorrectorProducer",
    algorithm = cms.string('AK4PFPuppi'),
    level = cms.string('L1FastJet'),
    srcRho = cms.InputTag("fixedGridRhoFastjetAll")
)


process.ak4PFPuppiL1L2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFPuppiL1OffsetCorrector", "ak4PFPuppiL2RelativeCorrector", "ak4PFPuppiL3AbsoluteCorrector")
)


process.ak4PFPuppiL1L2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFPuppiL1OffsetCorrector", "ak4PFPuppiL2RelativeCorrector", "ak4PFPuppiL3AbsoluteCorrector", "ak4PFPuppiResidualCorrector")
)


process.ak4PFPuppiL1OffsetCorrector = cms.EDProducer("L1OffsetCorrectorProducer",
    algorithm = cms.string('AK4PFPuppi'),
    level = cms.string('L1Offset'),
    minVtxNdof = cms.int32(4),
    vertexCollection = cms.InputTag("offlinePrimaryVertices")
)


process.ak4PFPuppiL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFPuppiL2RelativeCorrector", "ak4PFPuppiL3AbsoluteCorrector")
)


process.ak4PFPuppiL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFPuppiL2RelativeCorrector", "ak4PFPuppiL3AbsoluteCorrector", "ak4PFPuppiResidualCorrector")
)


process.ak4PFPuppiL2RelativeCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PFPuppi'),
    level = cms.string('L2Relative')
)


process.ak4PFPuppiL3AbsoluteCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PFPuppi'),
    level = cms.string('L3Absolute')
)


process.ak4PFPuppiResidualCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PFPuppi'),
    level = cms.string('L2L3Residual')
)


process.ak4PFResidualCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L2L3Residual')
)


process.ak4TrackL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4TrackL2RelativeCorrector", "ak4TrackL3AbsoluteCorrector")
)


process.ak4TrackL2RelativeCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4TRK'),
    level = cms.string('L2Relative')
)


process.ak4TrackL3AbsoluteCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4TRK'),
    level = cms.string('L3Absolute')
)


process.flashggDiPhotonMVA = cms.EDProducer("FlashggDiPhotonMVAProducer",
    BeamSpotSigma = cms.double(3.7),
    BeamSpotTag = cms.InputTag("offlineBeamSpot"),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    Version = cms.string('new'),
    VertexProbParamsConv = cms.vdouble(-0.045, -0.148, -0.328, -0.184),
    VertexProbParamsNoConv = cms.vdouble(-0.366, -0.126, -0.119, -0.091),
    diphotonMVAweightfile = cms.FileInPath('flashgg/Taggers/data/Flashgg_DiPhoton_Moriond17.weights.xml'),
    doSigmaMdecorr = cms.bool(True),
    sigmaMdecorrFile = cms.FileInPath('flashgg/Taggers/data/diphoMVA_sigmaMoMdecorr_split_Mgg40_180.root')
)


process.flashggDiPhotonSystematics = cms.EDProducer("FlashggDiPhotonSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(

            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('MCScaleLowR9EE'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('full5x5_r9<0.94&&abs(superCluster.eta)>=1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
            UncertaintyBitMask = cms.string('011')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(

            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('MCScaleHighR9EE'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
            UncertaintyBitMask = cms.string('011')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(

            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('MCScaleLowR9EB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('full5x5_r9<0.94&&abs(superCluster.eta)<1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
            UncertaintyBitMask = cms.string('011')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(

            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('MCScaleHighR9EB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
            UncertaintyBitMask = cms.string('011')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(

            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('MCScaleGain6EB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('hasSwitchToGain6&&abs(superCluster.eta)<1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
            UncertaintyBitMask = cms.string('100')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(

            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('MCScaleGain1EB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('hasSwitchToGain1&&abs(superCluster.eta)<1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
            UncertaintyBitMask = cms.string('100')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.000455),
                        upBounds = cms.vdouble(1.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.94),
                        uncertainties = cms.vdouble(0.000233),
                        upBounds = cms.vdouble(1.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.0),
                        uncertainties = cms.vdouble(0.002089),
                        upBounds = cms.vdouble(1.5, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.94),
                        uncertainties = cms.vdouble(0.002089),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.00109),
                        upBounds = cms.vdouble(999.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.94),
                        uncertainties = cms.vdouble(0.002377),
                        upBounds = cms.vdouble(999.0, 999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('MaterialCentralBarrel'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(superCluster.eta)<1.0'),
            PhotonMethodName = cms.string('FlashggPhotonScale')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.000455),
                        upBounds = cms.vdouble(1.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.94),
                        uncertainties = cms.vdouble(0.000233),
                        upBounds = cms.vdouble(1.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.0),
                        uncertainties = cms.vdouble(0.002089),
                        upBounds = cms.vdouble(1.5, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.94),
                        uncertainties = cms.vdouble(0.002089),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.00109),
                        upBounds = cms.vdouble(999.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.94),
                        uncertainties = cms.vdouble(0.002377),
                        upBounds = cms.vdouble(999.0, 999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('MaterialOuterBarrel'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(superCluster.eta)>=1.0&&abs(superCluster.eta)<1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScale')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.000455),
                        upBounds = cms.vdouble(1.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.94),
                        uncertainties = cms.vdouble(0.000233),
                        upBounds = cms.vdouble(1.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.0),
                        uncertainties = cms.vdouble(0.002089),
                        upBounds = cms.vdouble(1.5, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.94),
                        uncertainties = cms.vdouble(0.002089),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.00109),
                        upBounds = cms.vdouble(999.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.94),
                        uncertainties = cms.vdouble(0.002377),
                        upBounds = cms.vdouble(999.0, 999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('MaterialForward'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(superCluster.eta)>=1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScale')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(-0.0001),
                        upBounds = cms.vdouble(1.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.0),
                        uncertainties = cms.vdouble(0.0002),
                        upBounds = cms.vdouble(1.5, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.94),
                        uncertainties = cms.vdouble(-0.0006),
                        upBounds = cms.vdouble(1.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.94),
                        uncertainties = cms.vdouble(-0.0011),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.0015),
                        upBounds = cms.vdouble(2.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 0.0),
                        uncertainties = cms.vdouble(0.0004),
                        upBounds = cms.vdouble(6.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.94),
                        uncertainties = cms.vdouble(0.0002),
                        upBounds = cms.vdouble(2.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 0.94),
                        uncertainties = cms.vdouble(0.0003),
                        upBounds = cms.vdouble(6.0, 999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('ShowerShapeHighR9EB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScale')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(-0.0001),
                        upBounds = cms.vdouble(1.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.0),
                        uncertainties = cms.vdouble(0.0002),
                        upBounds = cms.vdouble(1.5, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.94),
                        uncertainties = cms.vdouble(-0.0006),
                        upBounds = cms.vdouble(1.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.94),
                        uncertainties = cms.vdouble(-0.0011),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.0015),
                        upBounds = cms.vdouble(2.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 0.0),
                        uncertainties = cms.vdouble(0.0004),
                        upBounds = cms.vdouble(6.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.94),
                        uncertainties = cms.vdouble(0.0002),
                        upBounds = cms.vdouble(2.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 0.94),
                        uncertainties = cms.vdouble(0.0003),
                        upBounds = cms.vdouble(6.0, 999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('ShowerShapeHighR9EE'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScale')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(-0.0001),
                        upBounds = cms.vdouble(1.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.0),
                        uncertainties = cms.vdouble(0.0002),
                        upBounds = cms.vdouble(1.5, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.94),
                        uncertainties = cms.vdouble(-0.0006),
                        upBounds = cms.vdouble(1.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.94),
                        uncertainties = cms.vdouble(-0.0011),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.0015),
                        upBounds = cms.vdouble(2.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 0.0),
                        uncertainties = cms.vdouble(0.0004),
                        upBounds = cms.vdouble(6.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.94),
                        uncertainties = cms.vdouble(0.0002),
                        upBounds = cms.vdouble(2.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 0.94),
                        uncertainties = cms.vdouble(0.0003),
                        upBounds = cms.vdouble(6.0, 999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('ShowerShapeLowR9EB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)<1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScale')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(-0.0001),
                        upBounds = cms.vdouble(1.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.0),
                        uncertainties = cms.vdouble(0.0002),
                        upBounds = cms.vdouble(1.5, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.94),
                        uncertainties = cms.vdouble(-0.0006),
                        upBounds = cms.vdouble(1.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.94),
                        uncertainties = cms.vdouble(-0.0011),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.0015),
                        upBounds = cms.vdouble(2.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 0.0),
                        uncertainties = cms.vdouble(0.0004),
                        upBounds = cms.vdouble(6.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.94),
                        uncertainties = cms.vdouble(0.0002),
                        upBounds = cms.vdouble(2.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 0.94),
                        uncertainties = cms.vdouble(0.0003),
                        upBounds = cms.vdouble(6.0, 999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('ShowerShapeLowR9EE'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)>=1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScale')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.0007),
                        upBounds = cms.vdouble(1.5, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.94),
                        uncertainties = cms.vdouble(-0.0007),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.0007),
                        upBounds = cms.vdouble(6.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.94),
                        uncertainties = cms.vdouble(-0.0007),
                        upBounds = cms.vdouble(6.0, 999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('FNUFEB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(superCluster.eta)<1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScale')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.0007),
                        upBounds = cms.vdouble(1.5, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.94),
                        uncertainties = cms.vdouble(-0.0007),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.0007),
                        upBounds = cms.vdouble(6.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.94),
                        uncertainties = cms.vdouble(-0.0007),
                        upBounds = cms.vdouble(6.0, 999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('FNUFEE'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(superCluster.eta)>=1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScale')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(cms.PSet(
                    lowBounds = cms.vdouble(0.0),
                    uncertainties = cms.vdouble(0.0),
                    upBounds = cms.vdouble(999.0),
                    values = cms.vdouble(0.0)
                )),
                variables = cms.vstring('abs(superCluster.eta)')
            ),
            CorrectionFile = cms.FileInPath('flashgg/Systematics/data/SystematicsIDMVA_LegRunII_v1_2017.root'),
            Debug = cms.untracked.bool(False),
            Label = cms.string('MvaShift'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('1'),
            PhotonMethodName = cms.string('FlashggPhotonMvaTransform')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(1.5, 0.85),
                        values = cms.vdouble(0.998)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.85),
                        uncertainties = cms.vdouble(0.003),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(1.001)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.006),
                        upBounds = cms.vdouble(6.0, 0.9),
                        values = cms.vdouble(0.989)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.9),
                        uncertainties = cms.vdouble(0.009),
                        upBounds = cms.vdouble(6.0, 999.0),
                        values = cms.vdouble(1.002)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PreselSF'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('1'),
            PhotonMethodName = cms.string('FlashggPhotonWeight')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.0023),
                        upBounds = cms.vdouble(1.5, 0.85),
                        values = cms.vdouble(0.982)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.85),
                        uncertainties = cms.vdouble(0.0006),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.9911)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.0076),
                        upBounds = cms.vdouble(6.0, 0.9),
                        values = cms.vdouble(0.9639)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.9),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(6.0, 999.0),
                        values = cms.vdouble(0.983)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('electronVetoSF'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('1'),
            PhotonMethodName = cms.string('FlashggPhotonWeight')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0015550248, 0.0015550248),
                        upBounds = cms.vdouble(0.54, 1.5, 37.0),
                        values = cms.vdouble(0.9204369513)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 37),
                        uncertainties = cms.vdouble(0.0012001964, 0.0012001964),
                        upBounds = cms.vdouble(0.54, 1.5, 40.0),
                        values = cms.vdouble(0.9268543618)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 40.0),
                        uncertainties = cms.vdouble(0.0010500218, 0.0010500218),
                        upBounds = cms.vdouble(0.54, 1.5, 45.0),
                        values = cms.vdouble(0.9296864506)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 45.0),
                        uncertainties = cms.vdouble(0.0016928371, 0.0016928371),
                        upBounds = cms.vdouble(0.54, 1.5, 50.0),
                        values = cms.vdouble(0.9312181087)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0024479457, 0.0024479457),
                        upBounds = cms.vdouble(0.54, 1.5, 60.0),
                        values = cms.vdouble(0.9349061049)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 60.0),
                        uncertainties = cms.vdouble(0.0052975139, 0.0052975139),
                        upBounds = cms.vdouble(0.54, 1.5, 70.0),
                        values = cms.vdouble(0.9425532022)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 70.0),
                        uncertainties = cms.vdouble(0.0089854906, 0.0089854906),
                        upBounds = cms.vdouble(0.54, 1.5, 90.0),
                        values = cms.vdouble(0.9347621741)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 90.0),
                        uncertainties = cms.vdouble(0.017714307, 0.017714307),
                        upBounds = cms.vdouble(0.54, 1.5, 99999999),
                        values = cms.vdouble(0.9489236873)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 37.0),
                        values = cms.vdouble(0.9505374744)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 37.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 40.0),
                        values = cms.vdouble(0.9559316002)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 45.0),
                        values = cms.vdouble(0.960322746)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 45.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 50.0),
                        values = cms.vdouble(0.9628461917)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 60.0),
                        values = cms.vdouble(0.9662884361)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 60.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 70.0),
                        values = cms.vdouble(0.9715136996)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 70.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 90.0),
                        values = cms.vdouble(0.9753661262)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 90.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 99999999),
                        values = cms.vdouble(0.9818196687)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 37.0),
                        values = cms.vdouble(0.9630117411)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 37.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 40.0),
                        values = cms.vdouble(0.9680310533)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 45.0),
                        values = cms.vdouble(0.9721152461)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 45.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 50.0),
                        values = cms.vdouble(0.9748189645)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 60.0),
                        values = cms.vdouble(0.9747597366)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 60.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 70.0),
                        values = cms.vdouble(0.9753162174)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 70.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 90.0),
                        values = cms.vdouble(0.9803243059)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 90.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 99999999),
                        values = cms.vdouble(0.9865482764)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 0.0),
                        uncertainties = cms.vdouble(0.0017122892, 0.0017122892),
                        upBounds = cms.vdouble(0.84, 3.0, 37.0),
                        values = cms.vdouble(0.9093169942)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 37.0),
                        uncertainties = cms.vdouble(0.0012578761, 0.0012578761),
                        upBounds = cms.vdouble(0.84, 3.0, 40.0),
                        values = cms.vdouble(0.9214136806)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.84, 3.0, 45.0),
                        values = cms.vdouble(0.9396498081)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 45.0),
                        uncertainties = cms.vdouble(0.0013009169, 0.0013009169),
                        upBounds = cms.vdouble(0.84, 3.0, 50.0),
                        values = cms.vdouble(0.9455103913)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 50.0),
                        uncertainties = cms.vdouble(0.00165793, 0.00165793),
                        upBounds = cms.vdouble(0.84, 3.0, 60.0),
                        values = cms.vdouble(0.9519493209)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 60.0),
                        uncertainties = cms.vdouble(0.0031358462, 0.0031358462),
                        upBounds = cms.vdouble(0.84, 3.0, 70.0),
                        values = cms.vdouble(0.9560088523)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 70.0),
                        uncertainties = cms.vdouble(0.0036329374, 0.0036329374),
                        upBounds = cms.vdouble(0.84, 3.0, 90.0),
                        values = cms.vdouble(0.9638480843)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 90.0),
                        uncertainties = cms.vdouble(0.0051321702, 0.0051321702),
                        upBounds = cms.vdouble(0.84, 3.0, 99999999),
                        values = cms.vdouble(0.9714734218)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 0.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 37.0),
                        values = cms.vdouble(0.961495108)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 37.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 40.0),
                        values = cms.vdouble(0.9750837371)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 45.0),
                        values = cms.vdouble(0.9814701227)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 45.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 50.0),
                        values = cms.vdouble(0.9835352074)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 50.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 60.0),
                        values = cms.vdouble(0.9851237595)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 60.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 70.0),
                        values = cms.vdouble(0.9869551174)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 70.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 90.0),
                        values = cms.vdouble(0.9916069861)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 90.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 99999999),
                        values = cms.vdouble(0.9958525312)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 0.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 37.0),
                        values = cms.vdouble(0.9470889409)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 37.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 40.0),
                        values = cms.vdouble(0.9646677794)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 45.0),
                        values = cms.vdouble(0.9738993606)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 45.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 50.0),
                        values = cms.vdouble(0.9784039943)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 50.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 60.0),
                        values = cms.vdouble(0.980234517)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 60.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 70.0),
                        values = cms.vdouble(0.9828741312)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 70.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 90.0),
                        values = cms.vdouble(0.9870534958)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 90.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 99999999),
                        values = cms.vdouble(0.9891255039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 3.0, 0),
                        uncertainties = cms.vdouble(1.0, 1.0),
                        upBounds = cms.vdouble(999, 999, 999999),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'full5x5_r9', 
                    'abs(superCluster.eta)', 
                    'pt'
                )
            ),
            BinList2 = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.001420359, 0.001420359),
                        upBounds = cms.vdouble(0.54, 1.5, 28.0),
                        values = cms.vdouble(0.9503915847)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 28.0),
                        uncertainties = cms.vdouble(0.0011666773, 0.0011666773),
                        upBounds = cms.vdouble(0.54, 1.5, 31.0),
                        values = cms.vdouble(0.9563040539)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 31.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.54, 1.5, 35.0),
                        values = cms.vdouble(0.9554701294)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 35.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.54, 1.5, 40.0),
                        values = cms.vdouble(0.9573495211)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.54, 1.5, 45.0),
                        values = cms.vdouble(0.9615640328)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 45.0),
                        uncertainties = cms.vdouble(0.0012149116, 0.0012149116),
                        upBounds = cms.vdouble(0.54, 1.5, 50.0),
                        values = cms.vdouble(0.9635847522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0018398439, 0.0018398439),
                        upBounds = cms.vdouble(0.54, 1.5, 60.0),
                        values = cms.vdouble(0.9613424282)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 60.0),
                        uncertainties = cms.vdouble(0.0046295174, 0.0046295174),
                        upBounds = cms.vdouble(0.54, 1.5, 70.0),
                        values = cms.vdouble(0.953179846)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 70.0),
                        uncertainties = cms.vdouble(0.0082547803, 0.0082547803),
                        upBounds = cms.vdouble(0.54, 1.5, 90.0),
                        values = cms.vdouble(0.9427949472)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 90.0),
                        uncertainties = cms.vdouble(0.0210727517, 0.0210727517),
                        upBounds = cms.vdouble(0.54, 1.5, 99999999),
                        values = cms.vdouble(0.9180892383)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 28.0),
                        values = cms.vdouble(0.9821722615)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 28.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 31.0),
                        values = cms.vdouble(0.9846684256)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 31.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 35.0),
                        values = cms.vdouble(0.9853409044)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 35.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 40.0),
                        values = cms.vdouble(0.9851741151)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 45.0),
                        values = cms.vdouble(0.9847237955)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 45.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 50.0),
                        values = cms.vdouble(0.9836985511)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 60.0),
                        values = cms.vdouble(0.9818687985)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 60.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 70.0),
                        values = cms.vdouble(0.9793978257)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 70.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 90.0),
                        values = cms.vdouble(0.9766027088)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 90.0),
                        uncertainties = cms.vdouble(0.0011171683, 0.0011171683),
                        upBounds = cms.vdouble(0.85, 1.5, 99999999),
                        values = cms.vdouble(0.972331437)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 28.0),
                        values = cms.vdouble(0.9997101832)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 28.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 31.0),
                        values = cms.vdouble(0.9998675478)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 31.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 35.0),
                        values = cms.vdouble(0.9999351175)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 35.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 40.0),
                        values = cms.vdouble(0.999954156)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 45.0),
                        values = cms.vdouble(0.9999645283)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 45.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 50.0),
                        values = cms.vdouble(0.9999677894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 60.0),
                        values = cms.vdouble(0.9999665309)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 60.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 70.0),
                        values = cms.vdouble(0.9999602573)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 70.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 90.0),
                        values = cms.vdouble(0.9999369329)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 90.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 99999999),
                        values = cms.vdouble(0.9999456063)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 0.0),
                        uncertainties = cms.vdouble(0.0027302573, 0.0027302573),
                        upBounds = cms.vdouble(0.84, 3.0, 28.0),
                        values = cms.vdouble(0.8799714219)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 28.0),
                        uncertainties = cms.vdouble(0.0021032366, 0.0021032366),
                        upBounds = cms.vdouble(0.84, 3.0, 31.0),
                        values = cms.vdouble(0.8962741603)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 31.0),
                        uncertainties = cms.vdouble(0.0014198635, 0.0014198635),
                        upBounds = cms.vdouble(0.84, 3.0, 35.0),
                        values = cms.vdouble(0.9042685088)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 35.0),
                        uncertainties = cms.vdouble(0.0010478241, 0.0010478241),
                        upBounds = cms.vdouble(0.84, 3.0, 40.0),
                        values = cms.vdouble(0.9130894467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 40.0),
                        uncertainties = cms.vdouble(0.0010511874, 0.0010511874),
                        upBounds = cms.vdouble(0.84, 3.0, 45.0),
                        values = cms.vdouble(0.9236887059)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 45.0),
                        uncertainties = cms.vdouble(0.0015068743, 0.0015068743),
                        upBounds = cms.vdouble(0.84, 3.0, 50.0),
                        values = cms.vdouble(0.926909296)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 50.0),
                        uncertainties = cms.vdouble(0.001993287, 0.001993287),
                        upBounds = cms.vdouble(0.84, 3.0, 60.0),
                        values = cms.vdouble(0.9300621013)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 60.0),
                        uncertainties = cms.vdouble(0.0038708618, 0.0038708618),
                        upBounds = cms.vdouble(0.84, 3.0, 70.0),
                        values = cms.vdouble(0.9313708557)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 70.0),
                        uncertainties = cms.vdouble(0.0046452036, 0.0046452036),
                        upBounds = cms.vdouble(0.84, 3.0, 90.0),
                        values = cms.vdouble(0.9387860583)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 90.0),
                        uncertainties = cms.vdouble(0.007718235, 0.007718235),
                        upBounds = cms.vdouble(0.84, 3.0, 99999999),
                        values = cms.vdouble(0.9316696569)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 0.0),
                        uncertainties = cms.vdouble(0.0011380402, 0.0011380402),
                        upBounds = cms.vdouble(0.9, 3.0, 28.0),
                        values = cms.vdouble(0.9482346612)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 28.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 31.0),
                        values = cms.vdouble(0.9753440965)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 31.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 35.0),
                        values = cms.vdouble(0.9760310914)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 35.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 40.0),
                        values = cms.vdouble(0.9752981073)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 45.0),
                        values = cms.vdouble(0.973705016)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 45.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 50.0),
                        values = cms.vdouble(0.9719236369)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 50.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 60.0),
                        values = cms.vdouble(0.9704295117)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 60.0),
                        uncertainties = cms.vdouble(0.0014503236, 0.0014503236),
                        upBounds = cms.vdouble(0.9, 3.0, 70.0),
                        values = cms.vdouble(0.9692422639)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 70.0),
                        uncertainties = cms.vdouble(0.0018171502, 0.0018171502),
                        upBounds = cms.vdouble(0.9, 3.0, 90.0),
                        values = cms.vdouble(0.9692330221)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 90.0),
                        uncertainties = cms.vdouble(0.0024173224, 0.0024173224),
                        upBounds = cms.vdouble(0.9, 3.0, 99999999),
                        values = cms.vdouble(0.972663036)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 0.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 28.0),
                        values = cms.vdouble(0.9706915047)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 28.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 31.0),
                        values = cms.vdouble(0.9975115605)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 31.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 35.0),
                        values = cms.vdouble(0.9992706525)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 35.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 40.0),
                        values = cms.vdouble(0.9995305126)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 45.0),
                        values = cms.vdouble(0.9995836941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 45.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 50.0),
                        values = cms.vdouble(0.9996279004)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 50.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 60.0),
                        values = cms.vdouble(0.9995678968)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 60.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 70.0),
                        values = cms.vdouble(0.9996782105)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 70.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 90.0),
                        values = cms.vdouble(0.9997202663)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 90.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 99999999),
                        values = cms.vdouble(0.9993842985)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 3.0, 0),
                        uncertainties = cms.vdouble(1.0, 1.0),
                        upBounds = cms.vdouble(999, 999, 999999),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'full5x5_r9', 
                    'abs(superCluster.eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('TriggerWeight'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt<99999'),
            PhotonMethodName = cms.string('FlashggPhotonWeight')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.0001),
                        upBounds = cms.vdouble(1.5, 0.85),
                        values = cms.vdouble(0.9999)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.85),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(1.0003)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(6.0, 0.9),
                        values = cms.vdouble(1.0003)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.9),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(6.0, 999.0),
                        values = cms.vdouble(1.0004)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('LooseMvaSF'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('1'),
            PhotonMethodName = cms.string('FlashggPhotonWeight')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0),
                        uncertainties = cms.vdouble(0.00167952, 0.00167952, 0.00243437, 0.00243437),
                        upBounds = cms.vdouble(5),
                        values = cms.vdouble(1.00046, 0.999332)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(5),
                        uncertainties = cms.vdouble(0.00132967, 0.00132967, 0.00199484, 0.00199484),
                        upBounds = cms.vdouble(10),
                        values = cms.vdouble(1.01403, 0.978954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(10),
                        uncertainties = cms.vdouble(0.00127284, 0.00127284, 0.00222552, 0.00222552),
                        upBounds = cms.vdouble(15),
                        values = cms.vdouble(1.0031, 0.99458)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(15),
                        uncertainties = cms.vdouble(0.00122729, 0.00122729, 0.00270787, 0.00270787),
                        upBounds = cms.vdouble(20),
                        values = cms.vdouble(0.992237, 1.01713)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(20),
                        uncertainties = cms.vdouble(0.000854325, 0.000854325, 0.00266531, 0.00266531),
                        upBounds = cms.vdouble(30),
                        values = cms.vdouble(0.990433, 1.02985)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(30),
                        uncertainties = cms.vdouble(0.000847473, 0.000847473, 0.00415923, 0.00415923),
                        upBounds = cms.vdouble(40),
                        values = cms.vdouble(0.988515, 1.05637)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(40),
                        uncertainties = cms.vdouble(0.000864982, 0.000864982, 0.00601261, 0.00601261),
                        upBounds = cms.vdouble(50),
                        values = cms.vdouble(0.988526, 1.07976)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(50),
                        uncertainties = cms.vdouble(0.000909363, 0.000909363, 0.00921419, 0.00921419),
                        upBounds = cms.vdouble(60),
                        values = cms.vdouble(0.988509, 1.11643)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(60),
                        uncertainties = cms.vdouble(0.000690743, 0.000690743, 0.00982573, 0.00982573),
                        upBounds = cms.vdouble(80),
                        values = cms.vdouble(0.989606, 1.14786)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(80),
                        uncertainties = cms.vdouble(0.000759541, 0.000759541, 0.0150743, 0.0150743),
                        upBounds = cms.vdouble(100),
                        values = cms.vdouble(0.991492, 1.16885)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(100),
                        uncertainties = cms.vdouble(0.00066297, 0.00066297, 0.0173001, 0.0173001),
                        upBounds = cms.vdouble(140),
                        values = cms.vdouble(0.997022, 1.07771)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(140),
                        uncertainties = cms.vdouble(0.000738493, 0.000738493, 0.0291629, 0.0291629),
                        upBounds = cms.vdouble(200),
                        values = cms.vdouble(0.999255, 1.02942)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(200),
                        uncertainties = cms.vdouble(0.000985164, 0.000985164, 0.0710487, 0.0710487),
                        upBounds = cms.vdouble(400),
                        values = cms.vdouble(1.00079, 0.943138)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(400),
                        uncertainties = cms.vdouble(0.0, 0.0, 0.0, 0.0),
                        upBounds = cms.vdouble(999999999),
                        values = cms.vdouble(1, 1)
                    )
                ),
                variables = cms.vstring('pt')
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('FracRVWeight'),
            MethodName = cms.string('FlashggDiPhotonWeightFromFracRV'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt<99999')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(),
                variables = cms.vstring('1')
            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('SigmaEOverESmearing'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(),
            OverallRange = cms.string('1'),
            PhotonMethodName = cms.string('FlashggPhotonSigEoverESmearingEGMTool')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(cms.PSet(
                    lowBounds = cms.vdouble(0.0),
                    uncertainties = cms.vdouble(0.05),
                    upBounds = cms.vdouble(999.0),
                    values = cms.vdouble(0.0)
                )),
                variables = cms.vstring('abs(superCluster.eta)')
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('SigmaEOverEShift'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('1'),
            PhotonMethodName = cms.string('FlashggPhotonSigEOverEShift')
        )
    ),
    SystMethods2D = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(),
                variables = cms.vstring('1')
            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            FirstParameterName = cms.string('Rho'),
            Label = cms.string('MCSmearHighR9EE'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
            NSigmas = cms.PSet(
                firstVar = cms.vint32(1, -1, 0, 0),
                secondVar = cms.vint32(0, 0, 1, -1)
            ),
            OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5'),
            PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
            RandomLabel = cms.string('rnd_g_E'),
            SecondParameterName = cms.string('Phi')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(),
                variables = cms.vstring('1')
            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            FirstParameterName = cms.string('Rho'),
            Label = cms.string('MCSmearLowR9EE'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
            NSigmas = cms.PSet(
                firstVar = cms.vint32(1, -1, 0, 0),
                secondVar = cms.vint32(0, 0, 1, -1)
            ),
            OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)>=1.5'),
            PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
            RandomLabel = cms.string('rnd_g_E'),
            SecondParameterName = cms.string('Phi')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(),
                variables = cms.vstring('1')
            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            FirstParameterName = cms.string('Rho'),
            Label = cms.string('MCSmearHighR9EB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
            NSigmas = cms.PSet(
                firstVar = cms.vint32(1, -1, 0, 0),
                secondVar = cms.vint32(0, 0, 1, -1)
            ),
            OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5'),
            PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
            RandomLabel = cms.string('rnd_g_E'),
            SecondParameterName = cms.string('Phi')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(),
                variables = cms.vstring('1')
            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            FirstParameterName = cms.string('Rho'),
            Label = cms.string('MCSmearLowR9EB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
            NSigmas = cms.PSet(
                firstVar = cms.vint32(1, -1, 0, 0),
                secondVar = cms.vint32(0, 0, 1, -1)
            ),
            OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)<1.5'),
            PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
            RandomLabel = cms.string('rnd_g_E'),
            SecondParameterName = cms.string('Phi')
        )
    ),
    src = cms.InputTag("flashggDifferentialPhoIdInputsCorrection")
)


process.flashggDiPhotons = cms.EDProducer("FlashggDiPhotonProducer",
    ConversionTag = cms.InputTag("reducedEgamma","reducedConversions"),
    ConversionTagSingleLeg = cms.InputTag("reducedEgamma","reducedSingleLegConversions"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MaxJetCollections = cms.uint32(12),
    PhotonTag = cms.InputTag("flashggRandomizedPhotons"),
    VertexCandidateMapTag = cms.InputTag("flashggVertexMapUnique"),
    VertexSelectorName = cms.string('FlashggLegacyVertexSelector'),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    beamSpotTag = cms.InputTag("offlineBeamSpot"),
    dRexclude = cms.double(0.05),
    nVtxSaveInfo = cms.untracked.uint32(3),
    pureGeomConvMatching = cms.bool(True),
    sigma1Pix = cms.double(0.0125255),
    sigma1PixFwd = cms.double(0.0581667),
    sigma1Tec = cms.double(1.67937),
    sigma1Tib = cms.double(0.716301),
    sigma1Tid = cms.double(0.38521),
    sigma1Tob = cms.double(3.17615),
    sigma2Pix = cms.double(0.0298574),
    sigma2PixFwd = cms.double(0.180419),
    sigma2Tec = cms.double(1.21941),
    sigma2Tib = cms.double(0.414393),
    sigma2Tid = cms.double(0.494722),
    sigma2Tob = cms.double(1.06805),
    singlelegsigma1Pix = cms.double(0.0178107),
    singlelegsigma1PixFwd = cms.double(0.152157),
    singlelegsigma1Tec = cms.double(2.46599),
    singlelegsigma1Tib = cms.double(1.3188),
    singlelegsigma1Tid = cms.double(0.702755),
    singlelegsigma1Tob = cms.double(2.23662),
    singlelegsigma2Pix = cms.double(0.0935307),
    singlelegsigma2PixFwd = cms.double(0.577081),
    singlelegsigma2Tec = cms.double(1.56638),
    singlelegsigma2Tib = cms.double(0.756568),
    singlelegsigma2Tid = cms.double(0.892751),
    singlelegsigma2Tob = cms.double(0.62143),
    trackHighPurity = cms.bool(False),
    useSingleLeg = cms.bool(True),
    useZerothVertexFromMicro = cms.bool(True),
    vertexIdMVAweightfile = cms.FileInPath('flashgg/MicroAOD/data/TMVAClassification_BDTVtxId_SL_2016.xml'),
    vertexProbMVAweightfile = cms.FileInPath('flashgg/MicroAOD/data/TMVAClassification_BDTVtxProb_SL_2016.xml'),
    whichVertex = cms.uint32(0)
)


process.flashggDifferentialPhoIdInputsCorrection = cms.EDProducer("FlashggDifferentialPhoIdInputsCorrector",
    chIso_corrector_config_EB = cms.PSet(
        chIsoWorst_morphing = cms.PSet(
            classifier = cms.string('BDTG_chIsoWorst_EB'),
            regr_output_scaling = cms.string('x[0]*(0.093413)+(0.099455)'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfChIso03")'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfChIsoWorst03")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EB_chIsoWorst.xml')
        ),
        chIsoWorst_peak2tail = cms.PSet(
            classifier = cms.string('BDTG_chIsoWorst_EB_p2t'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtChosenVtx03'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("peak2tail_chIsoWorst_rnd")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalTailRegressor_EB_chIsoWorst.xml')
        ),
        chIso_morphing = cms.PSet(
            classifier = cms.string('BDTG_chIso_EB'),
            regr_output_scaling = cms.string('x[0]*(0.077955)+(0.040562)'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfChIso03")'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfChIsoWorst03")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EB_chIso.xml')
        ),
        chIso_peak2tail = cms.PSet(
            classifier = cms.string('BDTG_chIso_EB_p2t'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtWorstVtx03'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("peak2tail_chIso_rnd")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalTailRegressor_EB_chIso.xml')
        ),
        clf_data = cms.PSet(
            classifier = cms.string('BDTG_chIso_EB_3Cat_data'),
            multiclass = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/data_clf_3Cat_EB_chIso_chIsoWorst.xml')
        ),
        clf_mc = cms.PSet(
            classifier = cms.string('BDTG_chIso_EB_3Cat_mc'),
            multiclass = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/mc_clf_3Cat_EB_chIso_chIsoWorst.xml')
        )
    ),
    chIso_corrector_config_EE = cms.PSet(
        chIsoWorst_morphing = cms.PSet(
            classifier = cms.string('BDTG_chIsoWorst_EE'),
            regr_output_scaling = cms.string('x[0]*(0.082616)+(-0.000267)'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfChIso03")'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfChIsoWorst03")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EE_chIsoWorst.xml')
        ),
        chIsoWorst_peak2tail = cms.PSet(
            classifier = cms.string('BDTG_chIsoWorst_EE_p2t'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtChosenVtx03'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("peak2tail_chIsoWorst_rnd")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalTailRegressor_EE_chIsoWorst.xml')
        ),
        chIso_morphing = cms.PSet(
            classifier = cms.string('BDTG_chIso_EE'),
            regr_output_scaling = cms.string('x[0]*(0.081217)+(0.012778)'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfChIso03")'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfChIsoWorst03")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EE_chIso.xml')
        ),
        chIso_peak2tail = cms.PSet(
            classifier = cms.string('BDTG_chIso_EE_p2t'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtWorstVtx03'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("peak2tail_chIso_rnd")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalTailRegressor_EE_chIso.xml')
        ),
        clf_data = cms.PSet(
            classifier = cms.string('BDTG_chIso_EE_3Cat_data'),
            multiclass = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/data_clf_3Cat_EE_chIso_chIsoWorst.xml')
        ),
        clf_mc = cms.PSet(
            classifier = cms.string('BDTG_chIso_EE_3Cat_mc'),
            multiclass = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/mc_clf_3Cat_EE_chIso_chIsoWorst.xml')
        )
    ),
    correctIsolations = cms.bool(True),
    correctShowerShapes = cms.bool(True),
    diphotonSrc = cms.InputTag("flashggDiPhotons"),
    effAreasConfigFile = cms.FileInPath('RecoEgamma/PhotonIdentification/data/Fall17/effAreaPhotons_cone03_pfPhotons_90percentBased_TrueVtx.txt'),
    etaWidth_corrector_config_EB = cms.PSet(
        classifier = cms.string('BDTG_etaWidth_EB'),
        regr_output_scaling = cms.string('x[0]*(0.000349)+(-0.000166)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EB_etaWidth.xml')
    ),
    etaWidth_corrector_config_EE = cms.PSet(
        classifier = cms.string('BDTG_etaWidth_EE'),
        regr_output_scaling = cms.string('x[0]*(0.000548)+(0.000223)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EE_etaWidth.xml')
    ),
    globalVariables = cms.PSet(
        dataPu = cms.vdouble(
            6.245e-06, 2.63e-05, 4.92e-05, 9.084e-05, 9.854e-05, 
            0.0001426, 0.0001557, 0.0001656, 0.0002269, 0.0005395, 
            0.001076, 0.002034, 0.003219, 0.004616, 0.006528, 
            0.009201, 0.01283, 0.01707, 0.02125, 0.0251, 
            0.02847, 0.03118, 0.03325, 0.03486, 0.03626, 
            0.03758, 0.0387, 0.03937, 0.03946, 0.03892, 
            0.03782, 0.03627, 0.03435, 0.03211, 0.02967, 
            0.02719, 0.02482, 0.02264, 0.0207, 0.01907, 
            0.01784, 0.01709, 0.01685, 0.0171, 0.01771, 
            0.01849, 0.01916, 0.01945, 0.01911, 0.01804, 
            0.01627, 0.01399, 0.01147, 0.008976, 0.006728, 
            0.004848, 0.003375, 0.002281, 0.001504, 0.0009715, 
            0.0006178, 0.0003882, 0.0002419, 0.0001501, 9.294e-05, 
            5.768e-05, 3.598e-05, 2.263e-05, 1.437e-05, 9.233e-06, 
            5.996e-06, 3.933e-06, 2.601e-06, 1.731e-06, 1.157e-06, 
            7.743e-07, 5.184e-07, 3.466e-07, 2.311e-07, 1.535e-07, 
            1.015e-07, 6.676e-08, 4.365e-08, 2.836e-08, 1.829e-08, 
            1.171e-08, 7.437e-09, 4.685e-09, 2.926e-09, 1.812e-09, 
            1.111e-09, 6.754e-10, 4.066e-10, 2.424e-10, 1.431e-10, 
            8.363e-11, 4.839e-11, 2.771e-11, 1.571e-11, 8.814e-12
        ),
        extraFloats = cms.PSet(

        ),
        mcPu = cms.vdouble(
            0.0238775, 0.000874622, 0.00124831, 0.00153105, 0.00147725, 
            0.00141303, 0.00126538, 0.00115647, 0.00218504, 0.00171699, 
            0.00229043, 0.00333221, 0.0048993, 0.00663561, 0.00897475, 
            0.011538, 0.0141801, 0.0169121, 0.0192551, 0.0214591, 
            0.0231318, 0.0243014, 0.0251415, 0.0257144, 0.0264036, 
            0.0272533, 0.0279565, 0.028333, 0.0282152, 0.0281867, 
            0.0280371, 0.0282786, 0.0282462, 0.0279432, 0.0276964, 
            0.0270571, 0.0259487, 0.0247456, 0.0239501, 0.0231562, 
            0.0214979, 0.0197288, 0.0179504, 0.0162761, 0.0148308, 
            0.0136544, 0.0125744, 0.0122772, 0.0120571, 0.0118004, 
            0.0120413, 0.0120674, 0.0120442, 0.0120637, 0.0119306, 
            0.0121372, 0.0119726, 0.0117524, 0.0113325, 0.0105063, 
            0.00941031, 0.00811139, 0.00662999, 0.00554745, 0.00434088, 
            0.00362642, 0.00318208, 0.00228125, 0.00171769, 0.00117662, 
            0.000909775, 0.000725548, 0.000478647, 0.000399337, 0.000367371, 
            0.000333013, 0.000231815, 0.000234494, 0.000226693, 0.000381801, 
            0.000485566, 0.000441125, 0.000234348, 0.000323903, 0.000166324, 
            0.000254228, 0.000143739, 0.000292395, 0.000254309, 0.000174261, 
            8.52316e-05, 5.89512e-05, 1.01815e-05, 3.82778e-05, 2.63483e-05, 
            0.000187418, 1.01005e-05, 2.22584e-05, 3.01709e-05, 3.36291e-05
        ),
        puBins = cms.vdouble(
            0.0, 1.0, 2.0, 3.0, 4.0, 
            5.0, 6.0, 7.0, 8.0, 9.0, 
            10.0, 11.0, 12.0, 13.0, 14.0, 
            15.0, 16.0, 17.0, 18.0, 19.0, 
            20.0, 21.0, 22.0, 23.0, 24.0, 
            25.0, 26.0, 27.0, 28.0, 29.0, 
            30.0, 31.0, 32.0, 33.0, 34.0, 
            35.0, 36.0, 37.0, 38.0, 39.0, 
            40.0, 41.0, 42.0, 43.0, 44.0, 
            45.0, 46.0, 47.0, 48.0, 49.0, 
            50.0, 51.0, 52.0, 53.0, 54.0, 
            55.0, 56.0, 57.0, 58.0, 59.0, 
            60.0, 61.0, 62.0, 63.0, 64.0, 
            65.0, 66.0, 67.0, 68.0, 69.0, 
            70.0, 71.0, 72.0, 73.0, 74.0, 
            75.0, 76.0, 77.0, 78.0, 79.0, 
            80.0, 81.0, 82.0, 83.0, 84.0, 
            85.0, 86.0, 87.0, 88.0, 89.0, 
            90.0, 91.0, 92.0, 93.0, 94.0, 
            95.0, 96.0, 97.0, 98.0, 99.0
        ),
        puInfo = cms.InputTag("slimmedAddPileupInfo"),
        puReWeight = cms.bool(True),
        rho = cms.InputTag("fixedGridRhoAll"),
        useTruePu = cms.bool(True),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    is2017 = cms.bool(True),
    phiWidth_corrector_config_EB = cms.PSet(
        classifier = cms.string('BDTG_phiWidth_EB'),
        regr_output_scaling = cms.string('x[0]*(0.002105)+(0.000738)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EB_phiWidth.xml')
    ),
    phiWidth_corrector_config_EE = cms.PSet(
        classifier = cms.string('BDTG_phiWidth_EE'),
        regr_output_scaling = cms.string('x[0]*(0.001946)+(0.000961)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EE_phiWidth.xml')
    ),
    phoIsoCutoff = cms.double(2.5),
    phoIsoPtScalingCoeff = cms.vdouble(0.0053, 0.0034),
    phoIso_corrector_config_EB = cms.PSet(
        clf_data = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EB_p0t_data'),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/data_clf_p2t_EB_phoIso.xml')
        ),
        clf_mc = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EB_p0t_mc'),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/mc_clf_p2t_EB_phoIso.xml')
        ),
        morphing = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EB'),
            regr_output_scaling = cms.string('x[0]*(0.125619)+(0.068956)'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfPhoIso03")'),
                    name = cms.untracked.string('f4')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EB_phoIso.xml')
        ),
        peak2tail = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EB_p2t'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("peak2tail_rnd")'),
                    name = cms.untracked.string('f4')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalTailRegressor_EB_phoIso.xml')
        )
    ),
    phoIso_corrector_config_EE = cms.PSet(
        clf_data = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EE_p0t_data'),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/data_clf_p2t_EE_phoIso.xml')
        ),
        clf_mc = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EE_p0t_mc'),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/mc_clf_p2t_EE_phoIso.xml')
        ),
        morphing = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EE'),
            regr_output_scaling = cms.string('x[0]*(0.088698)+(0.025296)'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfPhoIso03")'),
                    name = cms.untracked.string('f4')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EE_phoIso.xml')
        ),
        peak2tail = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EE_p2t'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("peak2tail_rnd")'),
                    name = cms.untracked.string('f4')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalTailRegressor_EE_phoIso.xml')
        )
    ),
    photonIdMVAweightfile_EB = cms.FileInPath('flashgg/MicroAOD/data/HggPhoId_94X_barrel_BDT_v2.weights.xml'),
    photonIdMVAweightfile_EE = cms.FileInPath('flashgg/MicroAOD/data/HggPhoId_94X_endcap_BDT_v2.weights.xml'),
    r9_corrector_config_EB = cms.PSet(
        classifier = cms.string('BDTG_r9_EB'),
        regr_output_scaling = cms.string('x[0]*(0.009489)+(-0.002028)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EB_r9.xml')
    ),
    r9_corrector_config_EE = cms.PSet(
        classifier = cms.string('BDTG_r9_EE'),
        regr_output_scaling = cms.string('x[0]*(0.014833)+(-0.007373)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EE_r9.xml')
    ),
    reRunRegression = cms.bool(False),
    regressionConfig = cms.PSet(
        autoDetectBunchSpacing = cms.bool(False),
        eOverP_ECALTRKThr = cms.double(0.025),
        electron_config = cms.PSet(
            regressionKey = cms.vstring(
                'electron_eb_ECALonly_lowpt', 
                'electron_eb_ECALonly', 
                'electron_ee_ECALonly_lowpt', 
                'electron_ee_ECALonly', 
                'electron_eb_ECALTRK_lowpt', 
                'electron_eb_ECALTRK', 
                'electron_ee_ECALTRK_lowpt', 
                'electron_ee_ECALTRK'
            ),
            uncertaintyKey = cms.vstring(
                'electron_eb_ECALonly_lowpt_var', 
                'electron_eb_ECALonly_var', 
                'electron_ee_ECALonly_lowpt_var', 
                'electron_ee_ECALonly_var', 
                'electron_eb_ECALTRK_lowpt_var', 
                'electron_eb_ECALTRK_var', 
                'electron_ee_ECALTRK_lowpt_var', 
                'electron_ee_ECALTRK_var'
            )
        ),
        epDiffSig_ECALTRKThr = cms.double(15.0),
        epSig_ECALTRKThr = cms.double(10.0),
        forceHighEnergyEcalTrainingIfSaturated = cms.bool(True),
        highEnergy_ECALTRKThr = cms.double(200.0),
        lowEnergy_ECALTRKThr = cms.double(50.0),
        lowEnergy_ECALonlyThr = cms.double(99999.0),
        manualBunchSpacing = cms.int32(25),
        modifierName = cms.string('EGRegressionModifierV2'),
        photon_config = cms.PSet(
            regressionKey = cms.vstring(
                'photon_eb_ECALonly_lowpt', 
                'photon_eb_ECALonly', 
                'photon_ee_ECALonly_lowpt', 
                'photon_ee_ECALonly'
            ),
            uncertaintyKey = cms.vstring(
                'photon_eb_ECALonly_lowpt_var', 
                'photon_eb_ECALonly_var', 
                'photon_ee_ECALonly_lowpt_var', 
                'photon_ee_ECALonly_var'
            )
        ),
        rhoCollection = cms.InputTag("fixedGridRhoFastjetAll"),
        vertexCollection = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    rhoFixedGridCollection = cms.InputTag("fixedGridRhoAll"),
    s4_corrector_config_EB = cms.PSet(
        classifier = cms.string('BDTG_s4_EB'),
        regr_output_scaling = cms.string('x[0]*(0.006531)+(-0.001477)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EB_s4.xml')
    ),
    s4_corrector_config_EE = cms.PSet(
        classifier = cms.string('BDTG_s4_EE'),
        regr_output_scaling = cms.string('x[0]*(0.014044)+(-0.008719)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EE_s4.xml')
    ),
    sieie_corrector_config_EB = cms.PSet(
        classifier = cms.string('BDTG_sieie_EB'),
        regr_output_scaling = cms.string('x[0]*(0.000096)+(-0.000052)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EB_sieie.xml')
    ),
    sieie_corrector_config_EE = cms.PSet(
        classifier = cms.string('BDTG_sieie_EE'),
        regr_output_scaling = cms.string('x[0]*(0.000495)+(0.000233)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EE_sieie.xml')
    ),
    sieip_corrector_config_EB = cms.PSet(
        classifier = cms.string('BDTG_sieip_EB'),
        regr_output_scaling = cms.string('x[0]*(0.000001)+(-0.000000)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EB_sieip.xml')
    ),
    sieip_corrector_config_EE = cms.PSet(
        classifier = cms.string('BDTG_sieip_EE'),
        regr_output_scaling = cms.string('x[0]*(0.000020)+(-0.000011)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EE_sieip.xml')
    )
)


process.flashggElectronSystematics = cms.EDProducer("FlashggElectronEffSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 10.0),
                        uncertainties = cms.vdouble(0.0112858730628),
                        upBounds = cms.vdouble(-2.0, 20.0),
                        values = cms.vdouble(0.949999988079)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 10.0),
                        uncertainties = cms.vdouble(0.0251865457492),
                        upBounds = cms.vdouble(-1.566, 20.0),
                        values = cms.vdouble(0.965909063816)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 10.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(-1.444, 20.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 10.0),
                        uncertainties = cms.vdouble(0.0532923660981),
                        upBounds = cms.vdouble(-0.8, 20.0),
                        values = cms.vdouble(1.00240385532)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.8, 10.0),
                        uncertainties = cms.vdouble(0.0185313741386),
                        upBounds = cms.vdouble(0.0, 20.0),
                        values = cms.vdouble(0.981412649155)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 10.0),
                        uncertainties = cms.vdouble(0.0184153504817),
                        upBounds = cms.vdouble(0.8, 20.0),
                        values = cms.vdouble(0.965559661388)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.8, 10.0),
                        uncertainties = cms.vdouble(0.0532537232346),
                        upBounds = cms.vdouble(1.444, 20.0),
                        values = cms.vdouble(0.995127916336)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 10.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(1.566, 20.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 10.0),
                        uncertainties = cms.vdouble(0.0251865457492),
                        upBounds = cms.vdouble(2.0, 20.0),
                        values = cms.vdouble(0.9784091115)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 10.0),
                        uncertainties = cms.vdouble(0.0114607321663),
                        upBounds = cms.vdouble(2.5, 20.0),
                        values = cms.vdouble(0.940533995628)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 20.0),
                        uncertainties = cms.vdouble(0.0189241795783),
                        upBounds = cms.vdouble(-2.0, 35.0),
                        values = cms.vdouble(0.93119263649)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 20.0),
                        uncertainties = cms.vdouble(0.0224861645312),
                        upBounds = cms.vdouble(-1.566, 35.0),
                        values = cms.vdouble(0.941436469555)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 20.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(-1.444, 35.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 20.0),
                        uncertainties = cms.vdouble(0.0305900962347),
                        upBounds = cms.vdouble(-0.8, 35.0),
                        values = cms.vdouble(0.954861104488)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.8, 20.0),
                        uncertainties = cms.vdouble(0.020587589271),
                        upBounds = cms.vdouble(0.0, 35.0),
                        values = cms.vdouble(0.988304078579)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.020587589271),
                        upBounds = cms.vdouble(0.8, 35.0),
                        values = cms.vdouble(0.987253785133)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.8, 20.0),
                        uncertainties = cms.vdouble(0.0305900962347),
                        upBounds = cms.vdouble(1.444, 35.0),
                        values = cms.vdouble(0.976717114449)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 20.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(1.566, 35.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 20.0),
                        uncertainties = cms.vdouble(0.0224861645312),
                        upBounds = cms.vdouble(2.0, 35.0),
                        values = cms.vdouble(0.952328145504)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 20.0),
                        uncertainties = cms.vdouble(0.0189241795783),
                        upBounds = cms.vdouble(2.5, 35.0),
                        values = cms.vdouble(0.931113660336)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 35.0),
                        uncertainties = cms.vdouble(0.0109725941888),
                        upBounds = cms.vdouble(-2.0, 50.0),
                        values = cms.vdouble(0.941885948181)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 35.0),
                        uncertainties = cms.vdouble(0.00693532170766),
                        upBounds = cms.vdouble(-1.566, 50.0),
                        values = cms.vdouble(0.958510637283)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 35.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(-1.444, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 35.0),
                        uncertainties = cms.vdouble(0.00783498919711),
                        upBounds = cms.vdouble(-0.8, 50.0),
                        values = cms.vdouble(0.966996729374)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.8, 35.0),
                        uncertainties = cms.vdouble(0.00477148982801),
                        upBounds = cms.vdouble(0.0, 50.0),
                        values = cms.vdouble(0.976769924164)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 35.0),
                        uncertainties = cms.vdouble(0.00477148982801),
                        upBounds = cms.vdouble(0.8, 50.0),
                        values = cms.vdouble(0.975850701332)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.8, 35.0),
                        uncertainties = cms.vdouble(0.00783498919711),
                        upBounds = cms.vdouble(1.444, 50.0),
                        values = cms.vdouble(0.967955827713)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 35.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(1.566, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 35.0),
                        uncertainties = cms.vdouble(0.00693532170766),
                        upBounds = cms.vdouble(2.0, 50.0),
                        values = cms.vdouble(0.959574460983)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 35.0),
                        uncertainties = cms.vdouble(0.0109725941888),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.93428260088)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 50.0),
                        uncertainties = cms.vdouble(0.0145086704563),
                        upBounds = cms.vdouble(-2.0, 100.0),
                        values = cms.vdouble(0.943783760071)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 50.0),
                        uncertainties = cms.vdouble(0.00537350216127),
                        upBounds = cms.vdouble(-1.566, 100.0),
                        values = cms.vdouble(0.965553224087)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 50.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(-1.444, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 50.0),
                        uncertainties = cms.vdouble(0.00269832703724),
                        upBounds = cms.vdouble(-0.8, 100.0),
                        values = cms.vdouble(0.967672407627)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.8, 50.0),
                        uncertainties = cms.vdouble(0.00788041010763),
                        upBounds = cms.vdouble(0.0, 100.0),
                        values = cms.vdouble(0.976164698601)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.00788041010763),
                        upBounds = cms.vdouble(0.8, 100.0),
                        values = cms.vdouble(0.975242197514)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.8, 50.0),
                        uncertainties = cms.vdouble(0.00269832703724),
                        upBounds = cms.vdouble(1.444, 100.0),
                        values = cms.vdouble(0.970810830593)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 50.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(1.566, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 50.0),
                        uncertainties = cms.vdouble(0.00537350216127),
                        upBounds = cms.vdouble(2.0, 100.0),
                        values = cms.vdouble(0.972860097885)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 50.0),
                        uncertainties = cms.vdouble(0.0145086704563),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.933117568493)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 100.0),
                        uncertainties = cms.vdouble(0.0159402275827),
                        upBounds = cms.vdouble(-2.0, 200.0),
                        values = cms.vdouble(0.973655343056)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 100.0),
                        uncertainties = cms.vdouble(0.0600400414131),
                        upBounds = cms.vdouble(-1.566, 200.0),
                        values = cms.vdouble(0.972860097885)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 100.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(-1.444, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 100.0),
                        uncertainties = cms.vdouble(0.0351614272789),
                        upBounds = cms.vdouble(-0.8, 200.0),
                        values = cms.vdouble(0.969924807549)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.8, 100.0),
                        uncertainties = cms.vdouble(0.022243336851),
                        upBounds = cms.vdouble(0.0, 200.0),
                        values = cms.vdouble(0.982683956623)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.022243336851),
                        upBounds = cms.vdouble(0.8, 200.0),
                        values = cms.vdouble(0.988146543503)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.8, 100.0),
                        uncertainties = cms.vdouble(0.0351614272789),
                        upBounds = cms.vdouble(1.444, 200.0),
                        values = cms.vdouble(0.977346301079)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 100.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(1.566, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 100.0),
                        uncertainties = cms.vdouble(0.0600690788596),
                        upBounds = cms.vdouble(2.0, 200.0),
                        values = cms.vdouble(0.995807111263)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 100.0),
                        uncertainties = cms.vdouble(0.0160763037584),
                        upBounds = cms.vdouble(2.5, 200.0),
                        values = cms.vdouble(0.952637255192)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 200.0),
                        uncertainties = cms.vdouble(0.0595751766054),
                        upBounds = cms.vdouble(-2.0, 500.0),
                        values = cms.vdouble(0.867357492447)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 500.0),
                        uncertainties = cms.vdouble(0.0595751766054),
                        upBounds = cms.vdouble(-2.0, 9999),
                        values = cms.vdouble(0.867357492447)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 200.0),
                        uncertainties = cms.vdouble(0.0637457498102),
                        upBounds = cms.vdouble(-1.566, 500.0),
                        values = cms.vdouble(0.994511544704)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 500.0),
                        uncertainties = cms.vdouble(0.0637457498102),
                        upBounds = cms.vdouble(-1.566, 9999),
                        values = cms.vdouble(0.994511544704)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 200.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(-1.444, 500.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 500.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(-1.444, 9999),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 200.0),
                        uncertainties = cms.vdouble(0.0593773467838),
                        upBounds = cms.vdouble(-0.8, 500.0),
                        values = cms.vdouble(0.978284478188)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 500.0),
                        uncertainties = cms.vdouble(0.0593773467838),
                        upBounds = cms.vdouble(-0.8, 9999),
                        values = cms.vdouble(0.978284478188)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.8, 200.0),
                        uncertainties = cms.vdouble(0.0433251322231),
                        upBounds = cms.vdouble(0.0, 500.0),
                        values = cms.vdouble(0.989189207554)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.8, 500.0),
                        uncertainties = cms.vdouble(0.0433251322231),
                        upBounds = cms.vdouble(0.0, 9999),
                        values = cms.vdouble(0.989189207554)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 200.0),
                        uncertainties = cms.vdouble(0.0429830183443),
                        upBounds = cms.vdouble(0.8, 500.0),
                        values = cms.vdouble(0.95387840271)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 500.0),
                        uncertainties = cms.vdouble(0.0429830183443),
                        upBounds = cms.vdouble(0.8, 9999),
                        values = cms.vdouble(0.95387840271)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.8, 200.0),
                        uncertainties = cms.vdouble(0.0593773467838),
                        upBounds = cms.vdouble(1.444, 500.0),
                        values = cms.vdouble(0.960427820683)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.8, 500.0),
                        uncertainties = cms.vdouble(0.0593773467838),
                        upBounds = cms.vdouble(1.444, 9999),
                        values = cms.vdouble(0.960427820683)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 200.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(1.566, 500.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 500.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(1.566, 9999),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 200.0),
                        uncertainties = cms.vdouble(0.0633253690692),
                        upBounds = cms.vdouble(2.0, 500.0),
                        values = cms.vdouble(0.961256563663)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 500.0),
                        uncertainties = cms.vdouble(0.0633253690692),
                        upBounds = cms.vdouble(2.0, 9999),
                        values = cms.vdouble(0.961256563663)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 200.0),
                        uncertainties = cms.vdouble(0.0695692658699),
                        upBounds = cms.vdouble(2.5, 500.0),
                        values = cms.vdouble(1.06021249294)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 500.0),
                        uncertainties = cms.vdouble(0.0695692658699),
                        upBounds = cms.vdouble(2.5, 9999),
                        values = cms.vdouble(1.06021249294)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-10.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(-2.5, 99999.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 0.0),
                        uncertainties = cms.vdouble(0.001),
                        upBounds = cms.vdouble(10.0, 999999999.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-10, 0.0),
                        uncertainties = cms.vdouble(0.001),
                        upBounds = cms.vdouble(10.0, 10.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'eta', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('ElectronIDWeight'),
            MethodName = cms.string('FlashggElectronWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.5')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 10.0),
                        uncertainties = cms.vdouble(0.0595607790053),
                        upBounds = cms.vdouble(-2.0, 20.0),
                        values = cms.vdouble(0.982328474522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 10.0),
                        uncertainties = cms.vdouble(0.0201089477996),
                        upBounds = cms.vdouble(-1.566, 20.0),
                        values = cms.vdouble(0.988577365875)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 10.0),
                        uncertainties = cms.vdouble(0.0307086960564),
                        upBounds = cms.vdouble(-1.444, 20.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 10.0),
                        uncertainties = cms.vdouble(0.0826095038174),
                        upBounds = cms.vdouble(-1.0, 20.0),
                        values = cms.vdouble(0.976470589638)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.0, 10.0),
                        uncertainties = cms.vdouble(0.054484510738),
                        upBounds = cms.vdouble(0.0, 20.0),
                        values = cms.vdouble(0.96931219101)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 10.0),
                        uncertainties = cms.vdouble(0.054484510738),
                        upBounds = cms.vdouble(1.0, 20.0),
                        values = cms.vdouble(0.96931219101)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 10.0),
                        uncertainties = cms.vdouble(0.0826095038174),
                        upBounds = cms.vdouble(1.444, 20.0),
                        values = cms.vdouble(0.976470589638)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 10.0),
                        uncertainties = cms.vdouble(0.0307086960564),
                        upBounds = cms.vdouble(1.566, 20.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 10.0),
                        uncertainties = cms.vdouble(0.0201089477996),
                        upBounds = cms.vdouble(2.0, 20.0),
                        values = cms.vdouble(0.988577365875)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 10.0),
                        uncertainties = cms.vdouble(0.0595607790053),
                        upBounds = cms.vdouble(2.5, 20.0),
                        values = cms.vdouble(0.982328474522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 20.0),
                        uncertainties = cms.vdouble(0.00757915021676),
                        upBounds = cms.vdouble(-2.0, 45.0),
                        values = cms.vdouble(0.97748208046)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 20.0),
                        uncertainties = cms.vdouble(0.00260286856232),
                        upBounds = cms.vdouble(-1.566, 45.0),
                        values = cms.vdouble(0.981613874435)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 20.0),
                        uncertainties = cms.vdouble(0.0139351980813),
                        upBounds = cms.vdouble(-1.444, 45.0),
                        values = cms.vdouble(0.948351621628)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 20.0),
                        uncertainties = cms.vdouble(0.00502412079629),
                        upBounds = cms.vdouble(-1.0, 45.0),
                        values = cms.vdouble(0.969262301922)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.0, 20.0),
                        uncertainties = cms.vdouble(0.00478613853043),
                        upBounds = cms.vdouble(-0.5, 45.0),
                        values = cms.vdouble(0.976554512978)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 20.0),
                        uncertainties = cms.vdouble(0.0068174062668),
                        upBounds = cms.vdouble(0.0, 45.0),
                        values = cms.vdouble(0.970377922058)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.0068174062668),
                        upBounds = cms.vdouble(0.5, 45.0),
                        values = cms.vdouble(0.970347642899)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.5, 20.0),
                        uncertainties = cms.vdouble(0.00478613853043),
                        upBounds = cms.vdouble(1.0, 45.0),
                        values = cms.vdouble(0.972420811653)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 20.0),
                        uncertainties = cms.vdouble(0.00502412079629),
                        upBounds = cms.vdouble(1.444, 45.0),
                        values = cms.vdouble(0.96991699934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 20.0),
                        uncertainties = cms.vdouble(0.0139351980813),
                        upBounds = cms.vdouble(1.566, 45.0),
                        values = cms.vdouble(0.957964599133)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 20.0),
                        uncertainties = cms.vdouble(0.00260286856232),
                        upBounds = cms.vdouble(2.0, 45.0),
                        values = cms.vdouble(0.979591846466)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 20.0),
                        uncertainties = cms.vdouble(0.00757915021676),
                        upBounds = cms.vdouble(2.5, 45.0),
                        values = cms.vdouble(0.979591846466)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 45.0),
                        uncertainties = cms.vdouble(0.00370677692937),
                        upBounds = cms.vdouble(-2.0, 75.0),
                        values = cms.vdouble(0.983673453331)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 45.0),
                        uncertainties = cms.vdouble(0.00386783804259),
                        upBounds = cms.vdouble(-1.566, 75.0),
                        values = cms.vdouble(0.981707334518)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 45.0),
                        uncertainties = cms.vdouble(0.0139269471799),
                        upBounds = cms.vdouble(-1.444, 75.0),
                        values = cms.vdouble(0.970619082451)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 45.0),
                        uncertainties = cms.vdouble(0.00437480990544),
                        upBounds = cms.vdouble(-1.0, 75.0),
                        values = cms.vdouble(0.975535154343)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.0, 45.0),
                        uncertainties = cms.vdouble(0.00263764082371),
                        upBounds = cms.vdouble(-0.5, 75.0),
                        values = cms.vdouble(0.979695439339)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 45.0),
                        uncertainties = cms.vdouble(0.00264300733607),
                        upBounds = cms.vdouble(0.0, 75.0),
                        values = cms.vdouble(0.97965413332)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 45.0),
                        uncertainties = cms.vdouble(0.00264300733607),
                        upBounds = cms.vdouble(0.5, 75.0),
                        values = cms.vdouble(0.97761952877)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.5, 45.0),
                        uncertainties = cms.vdouble(0.00263764082371),
                        upBounds = cms.vdouble(1.0, 75.0),
                        values = cms.vdouble(0.978680193424)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 45.0),
                        uncertainties = cms.vdouble(0.00437480990544),
                        upBounds = cms.vdouble(1.444, 75.0),
                        values = cms.vdouble(0.977366268635)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 45.0),
                        uncertainties = cms.vdouble(0.013954384552),
                        upBounds = cms.vdouble(1.566, 75.0),
                        values = cms.vdouble(0.963944852352)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 45.0),
                        uncertainties = cms.vdouble(0.00386783804259),
                        upBounds = cms.vdouble(2.0, 75.0),
                        values = cms.vdouble(0.982741117477)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 45.0),
                        uncertainties = cms.vdouble(0.00370677692937),
                        upBounds = cms.vdouble(2.5, 75.0),
                        values = cms.vdouble(0.983739852905)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 75.0),
                        uncertainties = cms.vdouble(0.0150392770193),
                        upBounds = cms.vdouble(-2.0, 100.0),
                        values = cms.vdouble(0.99695122242)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 75.0),
                        uncertainties = cms.vdouble(0.00779811751053),
                        upBounds = cms.vdouble(-1.566, 100.0),
                        values = cms.vdouble(0.996954321861)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 75.0),
                        uncertainties = cms.vdouble(0.040819128581),
                        upBounds = cms.vdouble(-1.444, 100.0),
                        values = cms.vdouble(1.00322926044)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 75.0),
                        uncertainties = cms.vdouble(0.00787002638101),
                        upBounds = cms.vdouble(-1.0, 100.0),
                        values = cms.vdouble(0.99590164423)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.0, 75.0),
                        uncertainties = cms.vdouble(0.00248175252562),
                        upBounds = cms.vdouble(-0.5, 100.0),
                        values = cms.vdouble(0.991894602776)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 75.0),
                        uncertainties = cms.vdouble(0.00392002362976),
                        upBounds = cms.vdouble(0.0, 100.0),
                        values = cms.vdouble(0.991902828217)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 75.0),
                        uncertainties = cms.vdouble(0.00392002362976),
                        upBounds = cms.vdouble(0.5, 100.0),
                        values = cms.vdouble(0.991902828217)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.5, 75.0),
                        uncertainties = cms.vdouble(0.00248175252562),
                        upBounds = cms.vdouble(1.0, 100.0),
                        values = cms.vdouble(0.991894602776)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 75.0),
                        uncertainties = cms.vdouble(0.00787002638101),
                        upBounds = cms.vdouble(1.444, 100.0),
                        values = cms.vdouble(0.99590164423)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 75.0),
                        uncertainties = cms.vdouble(0.040819128581),
                        upBounds = cms.vdouble(1.566, 100.0),
                        values = cms.vdouble(1.00322926044)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 75.0),
                        uncertainties = cms.vdouble(0.00779811751053),
                        upBounds = cms.vdouble(2.0, 100.0),
                        values = cms.vdouble(0.996954321861)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 75.0),
                        uncertainties = cms.vdouble(0.0150392770193),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.99695122242)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 100.0),
                        uncertainties = cms.vdouble(0.00962602625042),
                        upBounds = cms.vdouble(-2.0, 500.0),
                        values = cms.vdouble(0.989909172058)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 500.0),
                        uncertainties = cms.vdouble(0.00962602625042),
                        upBounds = cms.vdouble(-2.0, 9999),
                        values = cms.vdouble(0.989909172058)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 100.0),
                        uncertainties = cms.vdouble(0.00484917241993),
                        upBounds = cms.vdouble(-1.566, 500.0),
                        values = cms.vdouble(0.98988878727)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 500.0),
                        uncertainties = cms.vdouble(0.00484917241993),
                        upBounds = cms.vdouble(-1.566, 9999),
                        values = cms.vdouble(0.98988878727)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 100.0),
                        uncertainties = cms.vdouble(0.0491215609105),
                        upBounds = cms.vdouble(-1.444, 500.0),
                        values = cms.vdouble(1.0095949173)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 500.0),
                        uncertainties = cms.vdouble(0.0491215609105),
                        upBounds = cms.vdouble(-1.444, 9999),
                        values = cms.vdouble(1.0095949173)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 100.0),
                        uncertainties = cms.vdouble(0.006277407335),
                        upBounds = cms.vdouble(-1.0, 500.0),
                        values = cms.vdouble(0.984725058079)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 500.0),
                        uncertainties = cms.vdouble(0.006277407335),
                        upBounds = cms.vdouble(-1.0, 9999),
                        values = cms.vdouble(0.984725058079)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.0, 100.0),
                        uncertainties = cms.vdouble(0.00494347072206),
                        upBounds = cms.vdouble(-0.5, 500.0),
                        values = cms.vdouble(0.987891018391)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.0, 500.0),
                        uncertainties = cms.vdouble(0.00494347072206),
                        upBounds = cms.vdouble(-0.5, 9999),
                        values = cms.vdouble(0.987891018391)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 100.0),
                        uncertainties = cms.vdouble(0.0017513152756),
                        upBounds = cms.vdouble(0.0, 500.0),
                        values = cms.vdouble(0.993933260441)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 500.0),
                        uncertainties = cms.vdouble(0.0017513152756),
                        upBounds = cms.vdouble(0.0, 9999),
                        values = cms.vdouble(0.993933260441)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0017513152756),
                        upBounds = cms.vdouble(0.5, 500.0),
                        values = cms.vdouble(0.993933260441)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 500.0),
                        uncertainties = cms.vdouble(0.0017513152756),
                        upBounds = cms.vdouble(0.5, 9999),
                        values = cms.vdouble(0.993933260441)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.5, 100.0),
                        uncertainties = cms.vdouble(0.00494347072206),
                        upBounds = cms.vdouble(1.0, 500.0),
                        values = cms.vdouble(0.987891018391)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.5, 500.0),
                        uncertainties = cms.vdouble(0.00494347072206),
                        upBounds = cms.vdouble(1.0, 9999),
                        values = cms.vdouble(0.987891018391)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 100.0),
                        uncertainties = cms.vdouble(0.006277407335),
                        upBounds = cms.vdouble(1.444, 500.0),
                        values = cms.vdouble(0.984725058079)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 500.0),
                        uncertainties = cms.vdouble(0.006277407335),
                        upBounds = cms.vdouble(1.444, 9999),
                        values = cms.vdouble(0.984725058079)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 100.0),
                        uncertainties = cms.vdouble(0.0491215609105),
                        upBounds = cms.vdouble(1.566, 500.0),
                        values = cms.vdouble(1.0095949173)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 500.0),
                        uncertainties = cms.vdouble(0.0491215609105),
                        upBounds = cms.vdouble(1.566, 9999),
                        values = cms.vdouble(1.0095949173)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 100.0),
                        uncertainties = cms.vdouble(0.00484917241993),
                        upBounds = cms.vdouble(2.0, 500.0),
                        values = cms.vdouble(0.98988878727)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 500.0),
                        uncertainties = cms.vdouble(0.00484917241993),
                        upBounds = cms.vdouble(2.0, 9999),
                        values = cms.vdouble(0.98988878727)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 100.0),
                        uncertainties = cms.vdouble(0.00962602625042),
                        upBounds = cms.vdouble(2.5, 500.0),
                        values = cms.vdouble(0.989909172058)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 500.0),
                        uncertainties = cms.vdouble(0.00962602625042),
                        upBounds = cms.vdouble(2.5, 9999),
                        values = cms.vdouble(0.989909172058)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-10.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(-2.5, 99999.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 0.0),
                        uncertainties = cms.vdouble(0.001),
                        upBounds = cms.vdouble(10.0, 999999999.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-10, 0.0),
                        uncertainties = cms.vdouble(0.001),
                        upBounds = cms.vdouble(10.0, 10.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'eta', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('ElectronRecoWeight'),
            MethodName = cms.string('FlashggElectronWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.5')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggSelectedElectrons")
)


process.flashggHHWWggTag = cms.EDProducer("FlashggHHWWggTagProducer",
    DeltaRTrkElec = cms.double(0.4),
    DiLepMassThre = cms.double(0.0),
    DiLepPtThre = cms.double(0.0),
    DiPhotonName = cms.string('flashggPreselectedDiPhotons'),
    DiPhotonSuffixes = cms.vstring(''),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    EB_MVA_Threshold = cms.double(0.07),
    EE_MVA_Threshold = cms.double(-0.03),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    FLASHfilters = cms.InputTag("TriggerResults","","FLASHggMicroAOD"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HHWWggAnalysisChannel = cms.string('FL'),
    JetTags = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    JetsCollSize = cms.uint32(12),
    JetsName = cms.string('bRegProducer'),
    JetsSuffixes = cms.vstring(''),
    LongitudinalImpactParam = cms.double(0.2),
    METTag = cms.InputTag("flashggMets"),
    METThreshold = cms.double(0.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.0),
    MassTThre = cms.double(0.0),
    MassT_l2Thre = cms.double(0.0),
    MetPtThreshold = cms.double(0.0),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PATfilters = cms.InputTag("TriggerResults","","PAT"),
    PhoMVAThreshold = cms.double(-0.9),
    PhotonTag = cms.InputTag("flashggRandomizedPhotons"),
    PuIDCutoffThreshold = cms.double(0.8),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SaveOthers = cms.bool(False),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.double(0.02),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    btagThresh = cms.double(0.45),
    deltaMassElectronZThreshold = cms.double(10.0),
    deltaMassElectronZ_FL_Threshold = cms.double(5.0),
    deltaRJetMuonThreshold = cms.double(0.4),
    deltaRLeps = cms.double(0.0),
    deltaRMuonPhoThreshold = cms.double(0.4),
    deltaRPhoElectronThreshold = cms.double(0.4),
    deltaRPhoLeadJet = cms.double(0.4),
    deltaRPhoSubLeadJet = cms.double(0.4),
    doHHWWggDebug = cms.bool(True),
    doHHWWggFHptOrdered = cms.bool(False),
    doHHWWggNonResAnalysis = cms.bool(True),
    doHHWWggTagCutFlowAnalysis = cms.bool(True),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    electronIsoThreshold = cms.double(0.15),
    electronNumOfHitsThreshold = cms.double(1),
    globalVariables = cms.PSet(
        dataPu = cms.vdouble(
            6.245e-06, 2.63e-05, 4.92e-05, 9.084e-05, 9.854e-05, 
            0.0001426, 0.0001557, 0.0001656, 0.0002269, 0.0005395, 
            0.001076, 0.002034, 0.003219, 0.004616, 0.006528, 
            0.009201, 0.01283, 0.01707, 0.02125, 0.0251, 
            0.02847, 0.03118, 0.03325, 0.03486, 0.03626, 
            0.03758, 0.0387, 0.03937, 0.03946, 0.03892, 
            0.03782, 0.03627, 0.03435, 0.03211, 0.02967, 
            0.02719, 0.02482, 0.02264, 0.0207, 0.01907, 
            0.01784, 0.01709, 0.01685, 0.0171, 0.01771, 
            0.01849, 0.01916, 0.01945, 0.01911, 0.01804, 
            0.01627, 0.01399, 0.01147, 0.008976, 0.006728, 
            0.004848, 0.003375, 0.002281, 0.001504, 0.0009715, 
            0.0006178, 0.0003882, 0.0002419, 0.0001501, 9.294e-05, 
            5.768e-05, 3.598e-05, 2.263e-05, 1.437e-05, 9.233e-06, 
            5.996e-06, 3.933e-06, 2.601e-06, 1.731e-06, 1.157e-06, 
            7.743e-07, 5.184e-07, 3.466e-07, 2.311e-07, 1.535e-07, 
            1.015e-07, 6.676e-08, 4.365e-08, 2.836e-08, 1.829e-08, 
            1.171e-08, 7.437e-09, 4.685e-09, 2.926e-09, 1.812e-09, 
            1.111e-09, 6.754e-10, 4.066e-10, 2.424e-10, 1.431e-10, 
            8.363e-11, 4.839e-11, 2.771e-11, 1.571e-11, 8.814e-12
        ),
        extraFloats = cms.PSet(

        ),
        mcPu = cms.vdouble(
            0.0238775, 0.000874622, 0.00124831, 0.00153105, 0.00147725, 
            0.00141303, 0.00126538, 0.00115647, 0.00218504, 0.00171699, 
            0.00229043, 0.00333221, 0.0048993, 0.00663561, 0.00897475, 
            0.011538, 0.0141801, 0.0169121, 0.0192551, 0.0214591, 
            0.0231318, 0.0243014, 0.0251415, 0.0257144, 0.0264036, 
            0.0272533, 0.0279565, 0.028333, 0.0282152, 0.0281867, 
            0.0280371, 0.0282786, 0.0282462, 0.0279432, 0.0276964, 
            0.0270571, 0.0259487, 0.0247456, 0.0239501, 0.0231562, 
            0.0214979, 0.0197288, 0.0179504, 0.0162761, 0.0148308, 
            0.0136544, 0.0125744, 0.0122772, 0.0120571, 0.0118004, 
            0.0120413, 0.0120674, 0.0120442, 0.0120637, 0.0119306, 
            0.0121372, 0.0119726, 0.0117524, 0.0113325, 0.0105063, 
            0.00941031, 0.00811139, 0.00662999, 0.00554745, 0.00434088, 
            0.00362642, 0.00318208, 0.00228125, 0.00171769, 0.00117662, 
            0.000909775, 0.000725548, 0.000478647, 0.000399337, 0.000367371, 
            0.000333013, 0.000231815, 0.000234494, 0.000226693, 0.000381801, 
            0.000485566, 0.000441125, 0.000234348, 0.000323903, 0.000166324, 
            0.000254228, 0.000143739, 0.000292395, 0.000254309, 0.000174261, 
            8.52316e-05, 5.89512e-05, 1.01815e-05, 3.82778e-05, 2.63483e-05, 
            0.000187418, 1.01005e-05, 2.22584e-05, 3.01709e-05, 3.36291e-05
        ),
        puBins = cms.vdouble(
            0.0, 1.0, 2.0, 3.0, 4.0, 
            5.0, 6.0, 7.0, 8.0, 9.0, 
            10.0, 11.0, 12.0, 13.0, 14.0, 
            15.0, 16.0, 17.0, 18.0, 19.0, 
            20.0, 21.0, 22.0, 23.0, 24.0, 
            25.0, 26.0, 27.0, 28.0, 29.0, 
            30.0, 31.0, 32.0, 33.0, 34.0, 
            35.0, 36.0, 37.0, 38.0, 39.0, 
            40.0, 41.0, 42.0, 43.0, 44.0, 
            45.0, 46.0, 47.0, 48.0, 49.0, 
            50.0, 51.0, 52.0, 53.0, 54.0, 
            55.0, 56.0, 57.0, 58.0, 59.0, 
            60.0, 61.0, 62.0, 63.0, 64.0, 
            65.0, 66.0, 67.0, 68.0, 69.0, 
            70.0, 71.0, 72.0, 73.0, 74.0, 
            75.0, 76.0, 77.0, 78.0, 79.0, 
            80.0, 81.0, 82.0, 83.0, 84.0, 
            85.0, 86.0, 87.0, 88.0, 89.0, 
            90.0, 91.0, 92.0, 93.0, 94.0, 
            95.0, 96.0, 97.0, 98.0, 99.0
        ),
        puInfo = cms.InputTag("slimmedAddPileupInfo"),
        puReWeight = cms.bool(True),
        rho = cms.InputTag("fixedGridRhoAll"),
        useTruePu = cms.bool(True),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(25.0),
    jetsNumberThreshold = cms.double(99.0),
    leadPhoOverMassThreshold = cms.double(0.35),
    lep1ptThre = cms.double(20.0),
    lep2ptThre = cms.double(10.0),
    lep3ptThre = cms.double(10.0),
    leptonPtThreshold = cms.double(10.0),
    muPFIsoSumRelThreshold = cms.double(0.15),
    muonEtaThreshold = cms.double(2.4),
    nonTrigMVAEtaCuts = cms.vdouble(0.8, 1.479, 2.5),
    nonTrigMVAThresholds = cms.vdouble(0.913286, 0.805013, 0.358969),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useElectronLooseID = cms.bool(True),
    useElectronMVARecipe = cms.bool(False),
    useVertex0only = cms.bool(False)
)


process.flashggJetSystematics0 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","0")
)


process.flashggJetSystematics1 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","1")
)


process.flashggJetSystematics10 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","10")
)


process.flashggJetSystematics11 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","11")
)


process.flashggJetSystematics2 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","2")
)


process.flashggJetSystematics3 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","3")
)


process.flashggJetSystematics4 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","4")
)


process.flashggJetSystematics5 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","5")
)


process.flashggJetSystematics6 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","6")
)


process.flashggJetSystematics7 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","7")
)


process.flashggJetSystematics8 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","8")
)


process.flashggJetSystematics9 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","9")
)


process.flashggMetSystematics = cms.EDProducer("FlashggMetSmearSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            Debug = cms.untracked.bool(False),
            Label = cms.string('metJecUncertainty'),
            MethodName = cms.string('FlashggMetJecSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.5')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            Debug = cms.untracked.bool(False),
            Label = cms.string('metJerUncertainty'),
            MethodName = cms.string('FlashggMetJerSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.5')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            Debug = cms.untracked.bool(False),
            Label = cms.string('metPhoUncertainty'),
            MethodName = cms.string('FlashggMetPhoSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.5')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            Debug = cms.untracked.bool(False),
            Label = cms.string('metUncUncertainty'),
            MethodName = cms.string('FlashggMetUncSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.5')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggMets")
)


process.flashggMuonSystematics = cms.EDProducer("FlashggMuonEffSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 20.0),
                        uncertainties = cms.vdouble(0.00717150166064, 0.00717150166064),
                        upBounds = cms.vdouble(2.1, 25.0),
                        values = cms.vdouble(0.995538375007)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 20.0),
                        uncertainties = cms.vdouble(0.00717150166064, 0.00717150166064),
                        upBounds = cms.vdouble(-1.2, 25.0),
                        values = cms.vdouble(0.995538375007)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 3.0),
                        uncertainties = cms.vdouble(0.00718016037829, 0.00718016037829),
                        upBounds = cms.vdouble(2.1, 3.25),
                        values = cms.vdouble(0.985213161284)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 3.0),
                        uncertainties = cms.vdouble(0.00718016037829, 0.00718016037829),
                        upBounds = cms.vdouble(-1.2, 3.25),
                        values = cms.vdouble(0.985213161284)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 3.5),
                        uncertainties = cms.vdouble(0.00757211850767, 0.00757211850767),
                        upBounds = cms.vdouble(2.1, 3.75),
                        values = cms.vdouble(0.99334396788)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 3.5),
                        uncertainties = cms.vdouble(0.00757211850767, 0.00757211850767),
                        upBounds = cms.vdouble(-1.2, 3.75),
                        values = cms.vdouble(0.99334396788)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 2.5),
                        uncertainties = cms.vdouble(0.0121376683643, 0.0121376683643),
                        upBounds = cms.vdouble(2.1, 2.75),
                        values = cms.vdouble(0.983186017152)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 2.5),
                        uncertainties = cms.vdouble(0.0121376683643, 0.0121376683643),
                        upBounds = cms.vdouble(-1.2, 2.75),
                        values = cms.vdouble(0.983186017152)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 8.0),
                        uncertainties = cms.vdouble(0.00995275172559, 0.00995275172559),
                        upBounds = cms.vdouble(2.1, 10.0),
                        values = cms.vdouble(0.994538587647)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 8.0),
                        uncertainties = cms.vdouble(0.00995275172559, 0.00995275172559),
                        upBounds = cms.vdouble(-1.2, 10.0),
                        values = cms.vdouble(0.994538587647)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 5.0),
                        uncertainties = cms.vdouble(0.0071508543832, 0.0071508543832),
                        upBounds = cms.vdouble(2.1, 6.0),
                        values = cms.vdouble(0.994444776905)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 5.0),
                        uncertainties = cms.vdouble(0.0071508543832, 0.0071508543832),
                        upBounds = cms.vdouble(-1.2, 6.0),
                        values = cms.vdouble(0.994444776905)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 4.5),
                        uncertainties = cms.vdouble(0.0072215430303, 0.0072215430303),
                        upBounds = cms.vdouble(2.1, 5.0),
                        values = cms.vdouble(0.996519485745)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 4.5),
                        uncertainties = cms.vdouble(0.0072215430303, 0.0072215430303),
                        upBounds = cms.vdouble(-1.2, 5.0),
                        values = cms.vdouble(0.996519485745)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 50.0),
                        uncertainties = cms.vdouble(0.00096089233599, 0.00096089233599),
                        upBounds = cms.vdouble(2.1, 60.0),
                        values = cms.vdouble(0.99464683502)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 50.0),
                        uncertainties = cms.vdouble(0.00096089233599, 0.00096089233599),
                        upBounds = cms.vdouble(-1.2, 60.0),
                        values = cms.vdouble(0.99464683502)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 25.0),
                        uncertainties = cms.vdouble(0.00173622673212, 0.00173622673212),
                        upBounds = cms.vdouble(2.1, 30.0),
                        values = cms.vdouble(0.993530379812)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 25.0),
                        uncertainties = cms.vdouble(0.00173622673212, 0.00173622673212),
                        upBounds = cms.vdouble(-1.2, 30.0),
                        values = cms.vdouble(0.993530379812)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 2.75),
                        uncertainties = cms.vdouble(0.00912606332612, 0.00912606332612),
                        upBounds = cms.vdouble(2.1, 3.0),
                        values = cms.vdouble(0.986919644367)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 2.75),
                        uncertainties = cms.vdouble(0.00912606332612, 0.00912606332612),
                        upBounds = cms.vdouble(-1.2, 3.0),
                        values = cms.vdouble(0.986919644367)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 60.0),
                        uncertainties = cms.vdouble(0.00273336428507, 0.00273336428507),
                        upBounds = cms.vdouble(2.1, float('inf')),
                        values = cms.vdouble(0.996436428655)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 60.0),
                        uncertainties = cms.vdouble(0.00273336428507, 0.00273336428507),
                        upBounds = cms.vdouble(-1.2, float('inf')),
                        values = cms.vdouble(0.996436428655)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 15.0),
                        uncertainties = cms.vdouble(0.0191694887963, 0.0191694887963),
                        upBounds = cms.vdouble(2.1, 20.0),
                        values = cms.vdouble(0.999986384631)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 15.0),
                        uncertainties = cms.vdouble(0.0191694887963, 0.0191694887963),
                        upBounds = cms.vdouble(-1.2, 20.0),
                        values = cms.vdouble(0.999986384631)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 4.0),
                        uncertainties = cms.vdouble(0.00653056546752, 0.00653056546752),
                        upBounds = cms.vdouble(2.1, 4.5),
                        values = cms.vdouble(0.992218429387)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 4.0),
                        uncertainties = cms.vdouble(0.00653056546752, 0.00653056546752),
                        upBounds = cms.vdouble(-1.2, 4.5),
                        values = cms.vdouble(0.992218429387)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 3.25),
                        uncertainties = cms.vdouble(0.00729816164028, 0.00729816164028),
                        upBounds = cms.vdouble(2.1, 3.5),
                        values = cms.vdouble(0.986602392121)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 3.25),
                        uncertainties = cms.vdouble(0.00729816164028, 0.00729816164028),
                        upBounds = cms.vdouble(-1.2, 3.5),
                        values = cms.vdouble(0.986602392121)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 2.0),
                        uncertainties = cms.vdouble(0.022506195688, 0.022506195688),
                        upBounds = cms.vdouble(2.1, 2.5),
                        values = cms.vdouble(0.980681394619)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 2.0),
                        uncertainties = cms.vdouble(0.022506195688, 0.022506195688),
                        upBounds = cms.vdouble(-1.2, 2.5),
                        values = cms.vdouble(0.980681394619)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 10.0),
                        uncertainties = cms.vdouble(0.012656417927, 0.012656417927),
                        upBounds = cms.vdouble(2.1, 15.0),
                        values = cms.vdouble(1.00188205103)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 10.0),
                        uncertainties = cms.vdouble(0.012656417927, 0.012656417927),
                        upBounds = cms.vdouble(-1.2, 15.0),
                        values = cms.vdouble(1.00188205103)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 6.0),
                        uncertainties = cms.vdouble(0.0084679535697, 0.0084679535697),
                        upBounds = cms.vdouble(2.1, 8.0),
                        values = cms.vdouble(0.995278662396)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 6.0),
                        uncertainties = cms.vdouble(0.0084679535697, 0.0084679535697),
                        upBounds = cms.vdouble(-1.2, 8.0),
                        values = cms.vdouble(0.995278662396)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 3.75),
                        uncertainties = cms.vdouble(0.00648266247749, 0.00648266247749),
                        upBounds = cms.vdouble(2.1, 4.0),
                        values = cms.vdouble(0.98727403084)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 3.75),
                        uncertainties = cms.vdouble(0.00648266247749, 0.00648266247749),
                        upBounds = cms.vdouble(-1.2, 4.0),
                        values = cms.vdouble(0.98727403084)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 30.0),
                        uncertainties = cms.vdouble(0.0116620740623, 0.0116620740623),
                        upBounds = cms.vdouble(2.1, 40.0),
                        values = cms.vdouble(0.99824216396)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 30.0),
                        uncertainties = cms.vdouble(0.0116620740623, 0.0116620740623),
                        upBounds = cms.vdouble(-1.2, 40.0),
                        values = cms.vdouble(0.99824216396)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 40.0),
                        uncertainties = cms.vdouble(0.000627874806677, 0.000627874806677),
                        upBounds = cms.vdouble(2.1, 50.0),
                        values = cms.vdouble(0.995923566095)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 40.0),
                        uncertainties = cms.vdouble(0.000627874806677, 0.000627874806677),
                        upBounds = cms.vdouble(-1.2, 50.0),
                        values = cms.vdouble(0.995923566095)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(2.1, 2.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-1.2, 2.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 20.0),
                        uncertainties = cms.vdouble(0.0198265829746, 0.0198265829746),
                        upBounds = cms.vdouble(2.4, 25.0),
                        values = cms.vdouble(0.975996588061)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 20.0),
                        uncertainties = cms.vdouble(0.0198265829746, 0.0198265829746),
                        upBounds = cms.vdouble(-2.1, 25.0),
                        values = cms.vdouble(0.975996588061)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 3.0),
                        uncertainties = cms.vdouble(0.0127859287622, 0.0127859287622),
                        upBounds = cms.vdouble(2.4, 3.25),
                        values = cms.vdouble(0.982851318095)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 3.0),
                        uncertainties = cms.vdouble(0.0127859287622, 0.0127859287622),
                        upBounds = cms.vdouble(-2.1, 3.25),
                        values = cms.vdouble(0.982851318095)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 3.5),
                        uncertainties = cms.vdouble(0.0121339640224, 0.0121339640224),
                        upBounds = cms.vdouble(2.4, 3.75),
                        values = cms.vdouble(0.975062519006)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 3.5),
                        uncertainties = cms.vdouble(0.0121339640224, 0.0121339640224),
                        upBounds = cms.vdouble(-2.1, 3.75),
                        values = cms.vdouble(0.975062519006)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 2.5),
                        uncertainties = cms.vdouble(0.0104430782557, 0.0104430782557),
                        upBounds = cms.vdouble(2.4, 2.75),
                        values = cms.vdouble(0.994797585156)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 2.5),
                        uncertainties = cms.vdouble(0.0104430782557, 0.0104430782557),
                        upBounds = cms.vdouble(-2.1, 2.75),
                        values = cms.vdouble(0.994797585156)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 8.0),
                        uncertainties = cms.vdouble(0.0287971901566, 0.0287971901566),
                        upBounds = cms.vdouble(2.4, 10.0),
                        values = cms.vdouble(0.998439579201)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 8.0),
                        uncertainties = cms.vdouble(0.0287971901566, 0.0287971901566),
                        upBounds = cms.vdouble(-2.1, 10.0),
                        values = cms.vdouble(0.998439579201)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 5.0),
                        uncertainties = cms.vdouble(0.0114309112159, 0.0114309112159),
                        upBounds = cms.vdouble(2.4, 6.0),
                        values = cms.vdouble(0.97369571971)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 5.0),
                        uncertainties = cms.vdouble(0.0114309112159, 0.0114309112159),
                        upBounds = cms.vdouble(-2.1, 6.0),
                        values = cms.vdouble(0.97369571971)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 4.5),
                        uncertainties = cms.vdouble(0.013060031494, 0.013060031494),
                        upBounds = cms.vdouble(2.4, 5.0),
                        values = cms.vdouble(0.989372207781)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 4.5),
                        uncertainties = cms.vdouble(0.013060031494, 0.013060031494),
                        upBounds = cms.vdouble(-2.1, 5.0),
                        values = cms.vdouble(0.989372207781)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 50.0),
                        uncertainties = cms.vdouble(0.0031594299819, 0.0031594299819),
                        upBounds = cms.vdouble(2.4, 60.0),
                        values = cms.vdouble(0.971127267001)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 50.0),
                        uncertainties = cms.vdouble(0.0031594299819, 0.0031594299819),
                        upBounds = cms.vdouble(-2.1, 60.0),
                        values = cms.vdouble(0.971127267001)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 25.0),
                        uncertainties = cms.vdouble(0.020931162366, 0.020931162366),
                        upBounds = cms.vdouble(2.4, 30.0),
                        values = cms.vdouble(0.97456711052)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 25.0),
                        uncertainties = cms.vdouble(0.020931162366, 0.020931162366),
                        upBounds = cms.vdouble(-2.1, 30.0),
                        values = cms.vdouble(0.97456711052)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 2.75),
                        uncertainties = cms.vdouble(0.0105757316725, 0.0105757316725),
                        upBounds = cms.vdouble(2.4, 3.0),
                        values = cms.vdouble(0.982312781194)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 2.75),
                        uncertainties = cms.vdouble(0.0105757316725, 0.0105757316725),
                        upBounds = cms.vdouble(-2.1, 3.0),
                        values = cms.vdouble(0.982312781194)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 60.0),
                        uncertainties = cms.vdouble(0.00840769988892, 0.00840769988892),
                        upBounds = cms.vdouble(2.4, float('inf')),
                        values = cms.vdouble(0.981026986469)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 60.0),
                        uncertainties = cms.vdouble(0.00840769988892, 0.00840769988892),
                        upBounds = cms.vdouble(-2.1, float('inf')),
                        values = cms.vdouble(0.981026986469)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 15.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(2.4, 20.0),
                        values = cms.vdouble(1)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 15.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-2.1, 20.0),
                        values = cms.vdouble(1)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 4.0),
                        uncertainties = cms.vdouble(0.0123135695005, 0.0123135695005),
                        upBounds = cms.vdouble(2.4, 4.5),
                        values = cms.vdouble(0.979392128378)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 4.0),
                        uncertainties = cms.vdouble(0.0123135695005, 0.0123135695005),
                        upBounds = cms.vdouble(-2.1, 4.5),
                        values = cms.vdouble(0.979392128378)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 3.25),
                        uncertainties = cms.vdouble(0.0110961263986, 0.0110961263986),
                        upBounds = cms.vdouble(2.4, 3.5),
                        values = cms.vdouble(0.973787012958)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 3.25),
                        uncertainties = cms.vdouble(0.0110961263986, 0.0110961263986),
                        upBounds = cms.vdouble(-2.1, 3.5),
                        values = cms.vdouble(0.973787012958)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 2.0),
                        uncertainties = cms.vdouble(0.0128486487863, 0.0128486487863),
                        upBounds = cms.vdouble(2.4, 2.5),
                        values = cms.vdouble(0.989983698915)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 2.0),
                        uncertainties = cms.vdouble(0.0128486487863, 0.0128486487863),
                        upBounds = cms.vdouble(-2.1, 2.5),
                        values = cms.vdouble(0.989983698915)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 10.0),
                        uncertainties = cms.vdouble(0.0681946163707, 0.0681946163707),
                        upBounds = cms.vdouble(2.4, 15.0),
                        values = cms.vdouble(0.958219283228)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 10.0),
                        uncertainties = cms.vdouble(0.0681946163707, 0.0681946163707),
                        upBounds = cms.vdouble(-2.1, 15.0),
                        values = cms.vdouble(0.958219283228)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 6.0),
                        uncertainties = cms.vdouble(0.0144472473076, 0.0144472473076),
                        upBounds = cms.vdouble(2.4, 8.0),
                        values = cms.vdouble(0.982296382437)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 6.0),
                        uncertainties = cms.vdouble(0.0144472473076, 0.0144472473076),
                        upBounds = cms.vdouble(-2.1, 8.0),
                        values = cms.vdouble(0.982296382437)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 3.75),
                        uncertainties = cms.vdouble(0.010931477944, 0.010931477944),
                        upBounds = cms.vdouble(2.4, 4.0),
                        values = cms.vdouble(0.989547727624)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 3.75),
                        uncertainties = cms.vdouble(0.010931477944, 0.010931477944),
                        upBounds = cms.vdouble(-2.1, 4.0),
                        values = cms.vdouble(0.989547727624)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 30.0),
                        uncertainties = cms.vdouble(0.0265683528042, 0.0265683528042),
                        upBounds = cms.vdouble(2.4, 40.0),
                        values = cms.vdouble(0.979122449183)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 30.0),
                        uncertainties = cms.vdouble(0.0265683528042, 0.0265683528042),
                        upBounds = cms.vdouble(-2.1, 40.0),
                        values = cms.vdouble(0.979122449183)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 40.0),
                        uncertainties = cms.vdouble(0.000995955133576, 0.000995955133576),
                        upBounds = cms.vdouble(2.4, 50.0),
                        values = cms.vdouble(0.976366805953)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 40.0),
                        uncertainties = cms.vdouble(0.000995955133576, 0.000995955133576),
                        upBounds = cms.vdouble(-2.1, 50.0),
                        values = cms.vdouble(0.976366805953)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(2.4, 2.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-2.1, 2.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 20.0),
                        uncertainties = cms.vdouble(0.00468476023906, 0.00468476023906),
                        upBounds = cms.vdouble(1.2, 25.0),
                        values = cms.vdouble(1.00460587803)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 20.0),
                        uncertainties = cms.vdouble(0.00468476023906, 0.00468476023906),
                        upBounds = cms.vdouble(-0.9, 25.0),
                        values = cms.vdouble(1.00460587803)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 3.0),
                        uncertainties = cms.vdouble(0.296887585958, 0.296887585958),
                        upBounds = cms.vdouble(1.2, 3.25),
                        values = cms.vdouble(1.11706863713)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 3.0),
                        uncertainties = cms.vdouble(0.296887585958, 0.296887585958),
                        upBounds = cms.vdouble(-0.9, 3.25),
                        values = cms.vdouble(1.11706863713)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 3.5),
                        uncertainties = cms.vdouble(0.0245327565848, 0.0245327565848),
                        upBounds = cms.vdouble(1.2, 3.75),
                        values = cms.vdouble(1.00671914661)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 3.5),
                        uncertainties = cms.vdouble(0.0245327565848, 0.0245327565848),
                        upBounds = cms.vdouble(-0.9, 3.75),
                        values = cms.vdouble(1.00671914661)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 2.5),
                        uncertainties = cms.vdouble(9.74130183204, 9.74130183204),
                        upBounds = cms.vdouble(1.2, 2.75),
                        values = cms.vdouble(0.392514388413)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 2.5),
                        uncertainties = cms.vdouble(9.74130183204, 9.74130183204),
                        upBounds = cms.vdouble(-0.9, 2.75),
                        values = cms.vdouble(0.392514388413)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 8.0),
                        uncertainties = cms.vdouble(0.00977003583855, 0.00977003583855),
                        upBounds = cms.vdouble(1.2, 10.0),
                        values = cms.vdouble(0.993092222523)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 8.0),
                        uncertainties = cms.vdouble(0.00977003583855, 0.00977003583855),
                        upBounds = cms.vdouble(-0.9, 10.0),
                        values = cms.vdouble(0.993092222523)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 5.0),
                        uncertainties = cms.vdouble(0.00806563696427, 0.00806563696427),
                        upBounds = cms.vdouble(1.2, 6.0),
                        values = cms.vdouble(0.995174524966)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 5.0),
                        uncertainties = cms.vdouble(0.00806563696427, 0.00806563696427),
                        upBounds = cms.vdouble(-0.9, 6.0),
                        values = cms.vdouble(0.995174524966)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 4.5),
                        uncertainties = cms.vdouble(0.0100275932498, 0.0100275932498),
                        upBounds = cms.vdouble(1.2, 5.0),
                        values = cms.vdouble(0.994052917641)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 4.5),
                        uncertainties = cms.vdouble(0.0100275932498, 0.0100275932498),
                        upBounds = cms.vdouble(-0.9, 5.0),
                        values = cms.vdouble(0.994052917641)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 50.0),
                        uncertainties = cms.vdouble(0.00140847732849, 0.00140847732849),
                        upBounds = cms.vdouble(1.2, 60.0),
                        values = cms.vdouble(0.996740307518)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 50.0),
                        uncertainties = cms.vdouble(0.00140847732849, 0.00140847732849),
                        upBounds = cms.vdouble(-0.9, 60.0),
                        values = cms.vdouble(0.996740307518)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 25.0),
                        uncertainties = cms.vdouble(0.0076611932683, 0.0076611932683),
                        upBounds = cms.vdouble(1.2, 30.0),
                        values = cms.vdouble(0.996304500853)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 25.0),
                        uncertainties = cms.vdouble(0.0076611932683, 0.0076611932683),
                        upBounds = cms.vdouble(-0.9, 30.0),
                        values = cms.vdouble(0.996304500853)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 2.75),
                        uncertainties = cms.vdouble(3.13949110829, 3.13949110829),
                        upBounds = cms.vdouble(1.2, 3.0),
                        values = cms.vdouble(1.02551382269)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 2.75),
                        uncertainties = cms.vdouble(3.13949110829, 3.13949110829),
                        upBounds = cms.vdouble(-0.9, 3.0),
                        values = cms.vdouble(1.02551382269)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 60.0),
                        uncertainties = cms.vdouble(0.00509423672107, 0.00509423672107),
                        upBounds = cms.vdouble(1.2, float('inf')),
                        values = cms.vdouble(0.99567430311)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 60.0),
                        uncertainties = cms.vdouble(0.00509423672107, 0.00509423672107),
                        upBounds = cms.vdouble(-0.9, float('inf')),
                        values = cms.vdouble(0.99567430311)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 15.0),
                        uncertainties = cms.vdouble(0.0183853610848, 0.0183853610848),
                        upBounds = cms.vdouble(1.2, 20.0),
                        values = cms.vdouble(0.99999464277)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 15.0),
                        uncertainties = cms.vdouble(0.0183853610848, 0.0183853610848),
                        upBounds = cms.vdouble(-0.9, 20.0),
                        values = cms.vdouble(0.99999464277)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 4.0),
                        uncertainties = cms.vdouble(0.0103227916212, 0.0103227916212),
                        upBounds = cms.vdouble(1.2, 4.5),
                        values = cms.vdouble(0.996421849121)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 4.0),
                        uncertainties = cms.vdouble(0.0103227916212, 0.0103227916212),
                        upBounds = cms.vdouble(-0.9, 4.5),
                        values = cms.vdouble(0.996421849121)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 3.25),
                        uncertainties = cms.vdouble(0.0533754930135, 0.0533754930135),
                        upBounds = cms.vdouble(1.2, 3.5),
                        values = cms.vdouble(1.04051878063)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 3.25),
                        uncertainties = cms.vdouble(0.0533754930135, 0.0533754930135),
                        upBounds = cms.vdouble(-0.9, 3.5),
                        values = cms.vdouble(1.04051878063)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 2.0),
                        uncertainties = cms.vdouble(5.4486102689, 5.4486102689),
                        upBounds = cms.vdouble(1.2, 2.5),
                        values = cms.vdouble(0.287230284869)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 2.0),
                        uncertainties = cms.vdouble(5.4486102689, 5.4486102689),
                        upBounds = cms.vdouble(-0.9, 2.5),
                        values = cms.vdouble(0.287230284869)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 10.0),
                        uncertainties = cms.vdouble(0.0131433116066, 0.0131433116066),
                        upBounds = cms.vdouble(1.2, 15.0),
                        values = cms.vdouble(1.00136073769)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 10.0),
                        uncertainties = cms.vdouble(0.0131433116066, 0.0131433116066),
                        upBounds = cms.vdouble(-0.9, 15.0),
                        values = cms.vdouble(1.00136073769)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 6.0),
                        uncertainties = cms.vdouble(0.00832230192794, 0.00832230192794),
                        upBounds = cms.vdouble(1.2, 8.0),
                        values = cms.vdouble(0.992275142352)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 6.0),
                        uncertainties = cms.vdouble(0.00832230192794, 0.00832230192794),
                        upBounds = cms.vdouble(-0.9, 8.0),
                        values = cms.vdouble(0.992275142352)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 3.75),
                        uncertainties = cms.vdouble(0.017244093964, 0.017244093964),
                        upBounds = cms.vdouble(1.2, 4.0),
                        values = cms.vdouble(1.01217517033)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 3.75),
                        uncertainties = cms.vdouble(0.017244093964, 0.017244093964),
                        upBounds = cms.vdouble(-0.9, 4.0),
                        values = cms.vdouble(1.01217517033)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 30.0),
                        uncertainties = cms.vdouble(0.00239937467763, 0.00239937467763),
                        upBounds = cms.vdouble(1.2, 40.0),
                        values = cms.vdouble(0.999489017253)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 30.0),
                        uncertainties = cms.vdouble(0.00239937467763, 0.00239937467763),
                        upBounds = cms.vdouble(-0.9, 40.0),
                        values = cms.vdouble(0.999489017253)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 40.0),
                        uncertainties = cms.vdouble(0.000529028569286, 0.000529028569286),
                        upBounds = cms.vdouble(1.2, 50.0),
                        values = cms.vdouble(0.9975113899)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 40.0),
                        uncertainties = cms.vdouble(0.000529028569286, 0.000529028569286),
                        upBounds = cms.vdouble(-0.9, 50.0),
                        values = cms.vdouble(0.9975113899)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(1.2, 2.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-0.9, 2.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.0042584153216, 0.0042584153216),
                        upBounds = cms.vdouble(0.9, 25.0),
                        values = cms.vdouble(0.994630070584)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 20.0),
                        uncertainties = cms.vdouble(0.0042584153216, 0.0042584153216),
                        upBounds = cms.vdouble(-0.0, 25.0),
                        values = cms.vdouble(0.994630070584)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 3.0),
                        uncertainties = cms.vdouble(0.288563828351, 0.288563828351),
                        upBounds = cms.vdouble(0.9, 3.25),
                        values = cms.vdouble(1.06254655623)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 3.0),
                        uncertainties = cms.vdouble(0.288563828351, 0.288563828351),
                        upBounds = cms.vdouble(-0.0, 3.25),
                        values = cms.vdouble(1.06254655623)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 3.5),
                        uncertainties = cms.vdouble(0.0119829149142, 0.0119829149142),
                        upBounds = cms.vdouble(0.9, 3.75),
                        values = cms.vdouble(0.987593707404)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 3.5),
                        uncertainties = cms.vdouble(0.0119829149142, 0.0119829149142),
                        upBounds = cms.vdouble(-0.0, 3.75),
                        values = cms.vdouble(0.987593707404)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 2.5),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(0.9, 2.75),
                        values = cms.vdouble(1)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 2.5),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-0.0, 2.75),
                        values = cms.vdouble(1)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 8.0),
                        uncertainties = cms.vdouble(0.00579502099243, 0.00579502099243),
                        upBounds = cms.vdouble(0.9, 10.0),
                        values = cms.vdouble(0.995333082799)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 8.0),
                        uncertainties = cms.vdouble(0.00579502099243, 0.00579502099243),
                        upBounds = cms.vdouble(-0.0, 10.0),
                        values = cms.vdouble(0.995333082799)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 5.0),
                        uncertainties = cms.vdouble(0.00489401366652, 0.00489401366652),
                        upBounds = cms.vdouble(0.9, 6.0),
                        values = cms.vdouble(0.996237115913)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 5.0),
                        uncertainties = cms.vdouble(0.00489401366652, 0.00489401366652),
                        upBounds = cms.vdouble(-0.0, 6.0),
                        values = cms.vdouble(0.996237115913)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 4.5),
                        uncertainties = cms.vdouble(0.00544655327423, 0.00544655327423),
                        upBounds = cms.vdouble(0.9, 5.0),
                        values = cms.vdouble(0.994989399151)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 4.5),
                        uncertainties = cms.vdouble(0.00544655327423, 0.00544655327423),
                        upBounds = cms.vdouble(-0.0, 5.0),
                        values = cms.vdouble(0.994989399151)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.000769664095383, 0.000769664095383),
                        upBounds = cms.vdouble(0.9, 60.0),
                        values = cms.vdouble(0.993757790384)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 50.0),
                        uncertainties = cms.vdouble(0.000769664095383, 0.000769664095383),
                        upBounds = cms.vdouble(-0.0, 60.0),
                        values = cms.vdouble(0.993757790384)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 25.0),
                        uncertainties = cms.vdouble(0.00162720030192, 0.00162720030192),
                        upBounds = cms.vdouble(0.9, 30.0),
                        values = cms.vdouble(0.994270401894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 25.0),
                        uncertainties = cms.vdouble(0.00162720030192, 0.00162720030192),
                        upBounds = cms.vdouble(-0.0, 30.0),
                        values = cms.vdouble(0.994270401894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 2.75),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(0.9, 3.0),
                        values = cms.vdouble(1)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 2.75),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-0.0, 3.0),
                        values = cms.vdouble(1)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 60.0),
                        uncertainties = cms.vdouble(0.00300287148272, 0.00300287148272),
                        upBounds = cms.vdouble(0.9, float('inf')),
                        values = cms.vdouble(0.997312258632)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 60.0),
                        uncertainties = cms.vdouble(0.00300287148272, 0.00300287148272),
                        upBounds = cms.vdouble(-0.0, float('inf')),
                        values = cms.vdouble(0.997312258632)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 15.0),
                        uncertainties = cms.vdouble(0.0076883687727, 0.0076883687727),
                        upBounds = cms.vdouble(0.9, 20.0),
                        values = cms.vdouble(0.994972383613)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 15.0),
                        uncertainties = cms.vdouble(0.0076883687727, 0.0076883687727),
                        upBounds = cms.vdouble(-0.0, 20.0),
                        values = cms.vdouble(0.994972383613)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 4.0),
                        uncertainties = cms.vdouble(0.00566742840082, 0.00566742840082),
                        upBounds = cms.vdouble(0.9, 4.5),
                        values = cms.vdouble(0.995624981547)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 4.0),
                        uncertainties = cms.vdouble(0.00566742840082, 0.00566742840082),
                        upBounds = cms.vdouble(-0.0, 4.5),
                        values = cms.vdouble(0.995624981547)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 3.25),
                        uncertainties = cms.vdouble(0.0292255510167, 0.0292255510167),
                        upBounds = cms.vdouble(0.9, 3.5),
                        values = cms.vdouble(1.00067406873)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 3.25),
                        uncertainties = cms.vdouble(0.0292255510167, 0.0292255510167),
                        upBounds = cms.vdouble(-0.0, 3.5),
                        values = cms.vdouble(1.00067406873)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 2.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(0.9, 2.5),
                        values = cms.vdouble(1)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 2.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-0.0, 2.5),
                        values = cms.vdouble(1)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 10.0),
                        uncertainties = cms.vdouble(0.0068073849175, 0.0068073849175),
                        upBounds = cms.vdouble(0.9, 15.0),
                        values = cms.vdouble(0.995411694989)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 10.0),
                        uncertainties = cms.vdouble(0.0068073849175, 0.0068073849175),
                        upBounds = cms.vdouble(-0.0, 15.0),
                        values = cms.vdouble(0.995411694989)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 6.0),
                        uncertainties = cms.vdouble(0.00490421169823, 0.00490421169823),
                        upBounds = cms.vdouble(0.9, 8.0),
                        values = cms.vdouble(0.994088331695)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 6.0),
                        uncertainties = cms.vdouble(0.00490421169823, 0.00490421169823),
                        upBounds = cms.vdouble(-0.0, 8.0),
                        values = cms.vdouble(0.994088331695)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 3.75),
                        uncertainties = cms.vdouble(0.0081997787709, 0.0081997787709),
                        upBounds = cms.vdouble(0.9, 4.0),
                        values = cms.vdouble(0.99739659542)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 3.75),
                        uncertainties = cms.vdouble(0.0081997787709, 0.0081997787709),
                        upBounds = cms.vdouble(-0.0, 4.0),
                        values = cms.vdouble(0.99739659542)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.0026058520667, 0.0026058520667),
                        upBounds = cms.vdouble(0.9, 40.0),
                        values = cms.vdouble(0.998511261944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 30.0),
                        uncertainties = cms.vdouble(0.0026058520667, 0.0026058520667),
                        upBounds = cms.vdouble(-0.0, 40.0),
                        values = cms.vdouble(0.998511261944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 40.0),
                        uncertainties = cms.vdouble(0.000359094425458, 0.000359094425458),
                        upBounds = cms.vdouble(0.9, 50.0),
                        values = cms.vdouble(0.996668218039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 40.0),
                        uncertainties = cms.vdouble(0.000359094425458, 0.000359094425458),
                        upBounds = cms.vdouble(-0.0, 50.0),
                        values = cms.vdouble(0.996668218039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(0.9, 2.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-0.0, 2.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'eta', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('MuonMediumIDWeight'),
            MethodName = cms.string('FlashggMuonWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.4')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 20.0),
                        uncertainties = cms.vdouble(0.00195976775559, 0.00195976775559),
                        upBounds = cms.vdouble(2.1, 25.0),
                        values = cms.vdouble(0.996690354512)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 20.0),
                        uncertainties = cms.vdouble(0.00195976775559, 0.00195976775559),
                        upBounds = cms.vdouble(-1.2, 25.0),
                        values = cms.vdouble(0.996690354512)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 50.0),
                        uncertainties = cms.vdouble(0.000248116114645, 0.000248116114645),
                        upBounds = cms.vdouble(2.1, 60.0),
                        values = cms.vdouble(0.99969852486)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 50.0),
                        uncertainties = cms.vdouble(0.000248116114645, 0.000248116114645),
                        upBounds = cms.vdouble(-1.2, 60.0),
                        values = cms.vdouble(0.99969852486)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 25.0),
                        uncertainties = cms.vdouble(0.00102940216472, 0.00102940216472),
                        upBounds = cms.vdouble(2.1, 30.0),
                        values = cms.vdouble(0.998951934051)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 25.0),
                        uncertainties = cms.vdouble(0.00102940216472, 0.00102940216472),
                        upBounds = cms.vdouble(-1.2, 30.0),
                        values = cms.vdouble(0.998951934051)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 60.0),
                        uncertainties = cms.vdouble(0.00054048095508, 0.00054048095508),
                        upBounds = cms.vdouble(2.1, float('inf')),
                        values = cms.vdouble(1.00035447289)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 60.0),
                        uncertainties = cms.vdouble(0.00054048095508, 0.00054048095508),
                        upBounds = cms.vdouble(-1.2, float('inf')),
                        values = cms.vdouble(1.00035447289)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 30.0),
                        uncertainties = cms.vdouble(0.000356942539717, 0.000356942539717),
                        upBounds = cms.vdouble(2.1, 40.0),
                        values = cms.vdouble(0.998898672807)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 30.0),
                        uncertainties = cms.vdouble(0.000356942539717, 0.000356942539717),
                        upBounds = cms.vdouble(-1.2, 40.0),
                        values = cms.vdouble(0.998898672807)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 40.0),
                        uncertainties = cms.vdouble(0.000119050115919, 0.000119050115919),
                        upBounds = cms.vdouble(2.1, 50.0),
                        values = cms.vdouble(0.999386758588)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 40.0),
                        uncertainties = cms.vdouble(0.000119050115919, 0.000119050115919),
                        upBounds = cms.vdouble(-1.2, 50.0),
                        values = cms.vdouble(0.999386758588)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(2.1, 5),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-1.2, 5),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 5),
                        uncertainties = cms.vdouble(0.00391953551119, 0.00391953551119),
                        upBounds = cms.vdouble(2.1, 20.0),
                        values = cms.vdouble(0.996690354512)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 5),
                        uncertainties = cms.vdouble(0.00391953551119, 0.00391953551119),
                        upBounds = cms.vdouble(-1.2, 20.0),
                        values = cms.vdouble(0.996690354512)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 20.0),
                        uncertainties = cms.vdouble(0.00237277391402, 0.00237277391402),
                        upBounds = cms.vdouble(2.4, 25.0),
                        values = cms.vdouble(0.997504245941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 20.0),
                        uncertainties = cms.vdouble(0.00237277391402, 0.00237277391402),
                        upBounds = cms.vdouble(-2.1, 25.0),
                        values = cms.vdouble(0.997504245941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 50.0),
                        uncertainties = cms.vdouble(0.000522685299927, 0.000522685299927),
                        upBounds = cms.vdouble(2.4, 60.0),
                        values = cms.vdouble(1.00011124693)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 50.0),
                        uncertainties = cms.vdouble(0.000522685299927, 0.000522685299927),
                        upBounds = cms.vdouble(-2.1, 60.0),
                        values = cms.vdouble(1.00011124693)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 25.0),
                        uncertainties = cms.vdouble(0.00130829186635, 0.00130829186635),
                        upBounds = cms.vdouble(2.4, 30.0),
                        values = cms.vdouble(0.999028750143)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 25.0),
                        uncertainties = cms.vdouble(0.00130829186635, 0.00130829186635),
                        upBounds = cms.vdouble(-2.1, 30.0),
                        values = cms.vdouble(0.999028750143)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 60.0),
                        uncertainties = cms.vdouble(0.000908910123556, 0.000908910123556),
                        upBounds = cms.vdouble(2.4, float('inf')),
                        values = cms.vdouble(0.99937695355)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 60.0),
                        uncertainties = cms.vdouble(0.000908910123556, 0.000908910123556),
                        upBounds = cms.vdouble(-2.1, float('inf')),
                        values = cms.vdouble(0.99937695355)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 30.0),
                        uncertainties = cms.vdouble(0.000513599294717, 0.000513599294717),
                        upBounds = cms.vdouble(2.4, 40.0),
                        values = cms.vdouble(0.998896811778)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 30.0),
                        uncertainties = cms.vdouble(0.000513599294717, 0.000513599294717),
                        upBounds = cms.vdouble(-2.1, 40.0),
                        values = cms.vdouble(0.998896811778)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 40.0),
                        uncertainties = cms.vdouble(0.000588106305763, 0.000588106305763),
                        upBounds = cms.vdouble(2.4, 50.0),
                        values = cms.vdouble(0.999605390435)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 40.0),
                        uncertainties = cms.vdouble(0.000588106305763, 0.000588106305763),
                        upBounds = cms.vdouble(-2.1, 50.0),
                        values = cms.vdouble(0.999605390435)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(2.4, 5),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-2.1, 5),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 5),
                        uncertainties = cms.vdouble(0.00474554782804, 0.00474554782804),
                        upBounds = cms.vdouble(2.4, 20.0),
                        values = cms.vdouble(0.997504245941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 5),
                        uncertainties = cms.vdouble(0.00474554782804, 0.00474554782804),
                        upBounds = cms.vdouble(-2.1, 20.0),
                        values = cms.vdouble(0.997504245941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 20.0),
                        uncertainties = cms.vdouble(0.00436024925765, 0.00436024925765),
                        upBounds = cms.vdouble(1.2, 25.0),
                        values = cms.vdouble(0.994414232258)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 20.0),
                        uncertainties = cms.vdouble(0.00436024925765, 0.00436024925765),
                        upBounds = cms.vdouble(-0.9, 25.0),
                        values = cms.vdouble(0.994414232258)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 50.0),
                        uncertainties = cms.vdouble(0.000618031671457, 0.000618031671457),
                        upBounds = cms.vdouble(1.2, 60.0),
                        values = cms.vdouble(0.999299532103)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 50.0),
                        uncertainties = cms.vdouble(0.000618031671457, 0.000618031671457),
                        upBounds = cms.vdouble(-0.9, 60.0),
                        values = cms.vdouble(0.999299532103)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 25.0),
                        uncertainties = cms.vdouble(0.00218414248432, 0.00218414248432),
                        upBounds = cms.vdouble(1.2, 30.0),
                        values = cms.vdouble(0.993100424785)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 25.0),
                        uncertainties = cms.vdouble(0.00218414248432, 0.00218414248432),
                        upBounds = cms.vdouble(-0.9, 30.0),
                        values = cms.vdouble(0.993100424785)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 60.0),
                        uncertainties = cms.vdouble(0.00101961792784, 0.00101961792784),
                        upBounds = cms.vdouble(1.2, float('inf')),
                        values = cms.vdouble(1.00011893067)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 60.0),
                        uncertainties = cms.vdouble(0.00101961792784, 0.00101961792784),
                        upBounds = cms.vdouble(-0.9, float('inf')),
                        values = cms.vdouble(1.00011893067)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 30.0),
                        uncertainties = cms.vdouble(0.000530612904543, 0.000530612904543),
                        upBounds = cms.vdouble(1.2, 40.0),
                        values = cms.vdouble(0.997462630361)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 30.0),
                        uncertainties = cms.vdouble(0.000530612904543, 0.000530612904543),
                        upBounds = cms.vdouble(-0.9, 40.0),
                        values = cms.vdouble(0.997462630361)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 40.0),
                        uncertainties = cms.vdouble(0.000227245277765, 0.000227245277765),
                        upBounds = cms.vdouble(1.2, 50.0),
                        values = cms.vdouble(0.998862324847)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 40.0),
                        uncertainties = cms.vdouble(0.000227245277765, 0.000227245277765),
                        upBounds = cms.vdouble(-0.9, 50.0),
                        values = cms.vdouble(0.998862324847)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(1.2, 5),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-0.9, 5),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 5),
                        uncertainties = cms.vdouble(0.0087204985153, 0.0087204985153),
                        upBounds = cms.vdouble(1.2, 20.0),
                        values = cms.vdouble(0.994414232258)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 5),
                        uncertainties = cms.vdouble(0.0087204985153, 0.0087204985153),
                        upBounds = cms.vdouble(-0.9, 20.0),
                        values = cms.vdouble(0.994414232258)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.00255836254879, 0.00255836254879),
                        upBounds = cms.vdouble(0.9, 25.0),
                        values = cms.vdouble(0.992514242393)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 20.0),
                        uncertainties = cms.vdouble(0.00255836254879, 0.00255836254879),
                        upBounds = cms.vdouble(-0.0, 25.0),
                        values = cms.vdouble(0.992514242393)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.000299982567634, 0.000299982567634),
                        upBounds = cms.vdouble(0.9, 60.0),
                        values = cms.vdouble(0.999720244659)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 50.0),
                        uncertainties = cms.vdouble(0.000299982567634, 0.000299982567634),
                        upBounds = cms.vdouble(-0.0, 60.0),
                        values = cms.vdouble(0.999720244659)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 25.0),
                        uncertainties = cms.vdouble(0.00126427851203, 0.00126427851203),
                        upBounds = cms.vdouble(0.9, 30.0),
                        values = cms.vdouble(0.996396474716)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 25.0),
                        uncertainties = cms.vdouble(0.00126427851203, 0.00126427851203),
                        upBounds = cms.vdouble(-0.0, 30.0),
                        values = cms.vdouble(0.996396474716)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 60.0),
                        uncertainties = cms.vdouble(0.000351458119665, 0.000351458119665),
                        upBounds = cms.vdouble(0.9, float('inf')),
                        values = cms.vdouble(1.00003708794)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 60.0),
                        uncertainties = cms.vdouble(0.000351458119665, 0.000351458119665),
                        upBounds = cms.vdouble(-0.0, float('inf')),
                        values = cms.vdouble(1.00003708794)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.000405487475336, 0.000405487475336),
                        upBounds = cms.vdouble(0.9, 40.0),
                        values = cms.vdouble(0.998285156643)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 30.0),
                        uncertainties = cms.vdouble(0.000405487475336, 0.000405487475336),
                        upBounds = cms.vdouble(-0.0, 40.0),
                        values = cms.vdouble(0.998285156643)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 40.0),
                        uncertainties = cms.vdouble(0.000134135966903, 0.000134135966903),
                        upBounds = cms.vdouble(0.9, 50.0),
                        values = cms.vdouble(0.999386282629)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 40.0),
                        uncertainties = cms.vdouble(0.000134135966903, 0.000134135966903),
                        upBounds = cms.vdouble(-0.0, 50.0),
                        values = cms.vdouble(0.999386282629)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(0.9, 5),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-0.0, 5),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 5),
                        uncertainties = cms.vdouble(0.00511672509758, 0.00511672509758),
                        upBounds = cms.vdouble(0.9, 20.0),
                        values = cms.vdouble(0.992514242393)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 5),
                        uncertainties = cms.vdouble(0.00511672509758, 0.00511672509758),
                        upBounds = cms.vdouble(-0.0, 20.0),
                        values = cms.vdouble(0.992514242393)
                    )
                ),
                variables = cms.vstring(
                    'eta', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('MuonLooseRelISOWeight'),
            MethodName = cms.string('FlashggMuonWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.4')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggSelectedMuons")
)


process.flashggSigmaMoMpToMTag = cms.EDProducer("FlashggSigmaMpTTagProducer",
    BoundariesSigmaMoM = cms.vdouble(0.0, 0.00764, 0.0109, 0.0288),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    RequireScaledPtCuts = cms.bool(True),
    SystLabel = cms.string('')
)


process.flashggSystTagMerger = cms.EDProducer("TagMerger",
    src = cms.VInputTag("flashggTagSorter")
)


process.flashggTHQLeptonicTag = cms.EDProducer("FlashggTHQLeptonicTagProducer",
    Boundaries = cms.vdouble(
        -0.5, -0.45, -0.4, -0.35, -0.3, 
        -0.25, -0.2, -0.15, -0.1, -0.05, 
        0, 0.05, 0.1, 0.15, 0.2, 
        0.25, 0.3, 0.35, 0.4, 0.45
    ),
    DeltaRTrkElec = cms.double(0.35),
    DeltaRbjetfwdjet = cms.double(0.4),
    DeltaRtHchainfwdjet = cms.double(0.4),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    GenJetTag = cms.InputTag("slimmedGenJets"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    METTag = cms.InputTag("flashggMetSystematics"),
    MVAMethod = cms.string('BDT'),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.3),
    MVAThreshold_thq = cms.double(0.01),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PhoMVAThreshold = cms.double(-0.3),
    SystLabel = cms.string(''),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    bDiscriminator = cms.vdouble(0.1522, 0.4941, 0.8001),
    bTag = cms.string('pfDeepCSV'),
    bjetsNumberThreshold = cms.double(1.0),
    deltaRJetLeadPhoThreshold = cms.double(0.4),
    deltaRJetLepThreshold = cms.double(0.4),
    deltaRJetSubLeadPhoThreshold = cms.double(0.4),
    deltaRLepPhoThreshold = cms.double(0.4),
    deltaRPhoElectronThreshold = cms.double(0.4),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.4),
    electronPtThreshold = cms.double(10.0),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(5),
    jetPtThreshold = cms.double(25.0),
    jetsNumberThreshold = cms.double(1.0),
    leadPhoOverMassThreshold = cms.double(0.33),
    likelihoodThreshold_thq = cms.double(0.5),
    likelihood_input = cms.FileInPath('flashgg/Taggers/data/LikelihoodInput_file.root'),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    muonPtThreshold = cms.double(5.0),
    processId = cms.string('ggF_node8_WWgg_lnulnugg'),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25),
    thqleptonicMVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVAClassification_BDT_thq_24April19.weights.xml')
)


process.flashggTTHDiLeptonTag = cms.EDProducer("FlashggTTHDiLeptonTagProducer",
    CutBasedDiphoId = cms.vdouble(
        0.4, 0.3, 0.0, -0.5, 2.0, 
        2.5
    ),
    DeltaRTrkEle = cms.double(0.35),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    EleEtaCuts = cms.vdouble(1.4442, 1.566, 2.5),
    ElePhotonDrCut = cms.double(0.2),
    ElePhotonZMassCut = cms.double(5),
    ElePtCut = cms.double(10),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HTXSTags = cms.PSet(
        ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
        njets = cms.InputTag("rivetProducerHTXS","njets"),
        pTH = cms.InputTag("rivetProducerHTXS","pTH"),
        pTV = cms.InputTag("rivetProducerHTXS","pTV"),
        stage0cat = cms.InputTag("rivetProducerHTXS","stage0cat"),
        stage1cat = cms.InputTag("rivetProducerHTXS","stage1cat")
    ),
    LeptonsZMassCut = cms.double(5),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.5),
    MVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVAClassification_BDT_training_v2.json.weights.xml'),
    MetTag = cms.InputTag("flashggMetSystematics"),
    MuonEtaCut = cms.double(2.4),
    MuonIsoCut = cms.double(0.25),
    MuonPhotonDrCut = cms.double(0.2),
    MuonPtCut = cms.double(5),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PhoMVAThreshold = cms.double(-0.2),
    SystLabel = cms.string(''),
    UseCutBasedDiphoId = cms.bool(False),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    bDiscriminator = cms.vdouble(0.1522, 0.4941, 0.8001),
    bTag = cms.string('pfDeepCSV'),
    bjetsNumberThreshold = cms.double(1.0),
    debug = cms.bool(False),
    deltaRJetLeadPhoThreshold = cms.double(0.4),
    deltaRJetLepton = cms.double(0.4),
    deltaRJetSubLeadPhoThreshold = cms.double(0.4),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(25.0),
    jetsNumberThreshold = cms.double(1.0),
    leadPhoOverMassThreshold = cms.double(0.33),
    leadingJetPtThreshold = cms.double(0),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25)
)


process.flashggTTHHadronicTag = cms.EDProducer("FlashggTTHHadronicTagProducer",
    Boundaries = cms.vdouble(0.9675, 0.9937, 0.9971, 0.9991),
    DeltaRTrkEle = cms.double(0.0),
    DiPhotonName = cms.string('flashggPreselectedDiPhotons'),
    DiPhotonSuffixes = cms.vstring(''),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    EleEtaCuts = cms.vdouble(1.4442, 1.566, 2.5),
    ElePhotonDrCut = cms.double(0.0),
    ElePhotonZMassCut = cms.double(5),
    ElePtCut = cms.double(10),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HTXSTags = cms.PSet(
        ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
        njets = cms.InputTag("rivetProducerHTXS","njets"),
        pTH = cms.InputTag("rivetProducerHTXS","pTH"),
        pTV = cms.InputTag("rivetProducerHTXS","pTV"),
        stage0cat = cms.InputTag("rivetProducerHTXS","stage0cat"),
        stage1cat = cms.InputTag("rivetProducerHTXS","stage1cat")
    ),
    JetsCollSize = cms.uint32(12),
    JetsName = cms.string('flashggUnpackedJets'),
    JetsSuffixes = cms.vstring(''),
    METTag = cms.InputTag("flashggMetSystematics"),
    MVAMethod = cms.string('BDT'),
    MVAResultName = cms.string('flashggDiPhotonMVA'),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVATTHHMVAThreshold = cms.double(-1.0),
    MVAThreshold = cms.double(-1.0),
    MetName = cms.string('flashggMets'),
    MetSuffixes = cms.vstring(''),
    ModifySystematicsWorkflow = cms.bool(False),
    MuonEtaCut = cms.double(2.4),
    MuonIsoCut = cms.double(0.25),
    MuonPhotonDrCut = cms.double(0.0),
    MuonPtCut = cms.double(5),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PhoMVAThreshold = cms.double(-0.9),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SystLabel = cms.string(''),
    SystematicsJetsName = cms.string('flashggJetSystematics'),
    SystematicsMetName = cms.string('flashggMetSystematics'),
    UseLargeMVAs = cms.bool(True),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    applyMETfilters = cms.bool(False),
    bDiscriminator = cms.vdouble(0.1522, 0.4941, 0.8001),
    bTag = cms.string('pfDeepCSV'),
    bjetsLooseNumberTTHHMVAThreshold = cms.int32(1),
    bjetsLooseNumberThreshold = cms.int32(0),
    bjetsNumberTTHHMVAThreshold = cms.int32(0),
    bjetsNumberThreshold = cms.int32(1),
    dRJetPhoLeadCut = cms.double(0.4),
    dRJetPhoSubleadCut = cms.double(0.4),
    debug = cms.bool(False),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(25.0),
    jetsNumberTTHHMVAThreshold = cms.int32(3),
    jetsNumberThreshold = cms.int32(5),
    leadPhoOverMassTTHHMVAThreshold = cms.double(0.0),
    leadPhoOverMassThreshold = cms.double(0.0),
    leadPhoPtThreshold = cms.double(20),
    leadPhoUseVariableThreshold = cms.bool(True),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    secondMaxBTagTTHHMVAThreshold = cms.double(0.0),
    subleadPhoOverMassThreshold = cms.double(0.0),
    subleadPhoPtThreshold = cms.double(20),
    subleadPhoUseVariableThreshold = cms.bool(True),
    topTaggerXMLfile = cms.FileInPath('flashgg/Taggers/data/resTop_xgb_csv_order_deepCTag.xml'),
    tthMVA_RunII_weightfile = cms.FileInPath('flashgg/Taggers/data/ttHHadronic_RunII_MVA_28May2019.xml'),
    tthMVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVAClassification_tth_hadronic_2017Data_30vars_v0.weights.xml'),
    tthVsDiphoDNNfile = cms.FileInPath('flashgg/Taggers/data/ttHHadronic_ttH_vs_dipho_v1.6_28May2019_weights.pb'),
    tthVsttGGDNNfile = cms.FileInPath('flashgg/Taggers/data/ttHHadronic_ttH_vs_ttGG_v1.6_28May2019_weights.pb'),
    useTTHHadronicMVA = cms.bool(True)
)


process.flashggTTHLeptonicTag = cms.EDProducer("FlashggTTHLeptonicTagProducer",
    CutBasedDiphoId = cms.vdouble(
        0.4, 0.3, 0.0, -0.5, 2.0, 
        2.5
    ),
    DeltaRTrkEle = cms.double(0.35),
    DiLeptonJetThreshold = cms.double(0),
    DiLeptonMVAThreshold = cms.double(-999),
    DiLeptonbJetThreshold = cms.double(1),
    DiPhotonName = cms.string('flashggPreselectedDiPhotons'),
    DiPhotonSuffixes = cms.vstring(''),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    EleEtaCuts = cms.vdouble(1.4442, 1.566, 2.5),
    ElePhotonDrCut = cms.double(0.2),
    ElePhotonZMassCut = cms.double(5),
    ElePtCut = cms.double(10),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HTXSTags = cms.PSet(
        ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
        njets = cms.InputTag("rivetProducerHTXS","njets"),
        pTH = cms.InputTag("rivetProducerHTXS","pTH"),
        pTV = cms.InputTag("rivetProducerHTXS","pTV"),
        stage0cat = cms.InputTag("rivetProducerHTXS","stage0cat"),
        stage1cat = cms.InputTag("rivetProducerHTXS","stage1cat")
    ),
    JetsCollSize = cms.uint32(12),
    JetsName = cms.string('flashggUnpackedJets'),
    JetsSuffixes = cms.vstring(''),
    LeptonsZMassCut = cms.double(5),
    MVAResultName = cms.string('flashggDiPhotonMVA'),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.vdouble(0.8435, 0.9346, 0.9625, 0.989),
    MVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVAClassification_BDT_training_v2.json.weights.xml'),
    MaxNLep = cms.int32(10),
    MetName = cms.string('flashggMets'),
    MetSuffixes = cms.vstring(''),
    MetTag = cms.InputTag("flashggMetSystematics"),
    MinNLep = cms.int32(1),
    ModifySystematicsWorkflow = cms.bool(False),
    MuonEtaCut = cms.double(2.4),
    MuonIsoCut = cms.double(0.25),
    MuonPhotonDrCut = cms.double(0.2),
    MuonPtCut = cms.double(5),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PhoMVAThreshold = cms.double(-0.9),
    SplitDiLeptEv = cms.bool(True),
    SystLabel = cms.string(''),
    SystematicsJetsName = cms.string('flashggJetSystematics'),
    SystematicsMetName = cms.string('flashggMetSystematics'),
    UseCutBasedDiphoId = cms.bool(False),
    UseLargeMVAs = cms.bool(True),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    bDiscriminator = cms.vdouble(0.1522, 0.4941, 0.8001),
    bTag = cms.string('pfDeepCSV'),
    bjetsNumberThreshold = cms.double(0.0),
    debug = cms.bool(False),
    deltaRJetLeadPhoThreshold = cms.double(0.4),
    deltaRJetLepton = cms.double(0.4),
    deltaRJetSubLeadPhoThreshold = cms.double(0.4),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(25.0),
    jetsNumberThreshold = cms.double(1.0),
    leadPhoOverMassThreshold = cms.double(0.0),
    leadingJetPtThreshold = cms.double(0),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.0),
    topTaggerXMLfile = cms.FileInPath('flashgg/Taggers/data/resTop_xgb_csv_order_deepCTag.xml'),
    tthMVA_RunII_weightfile = cms.FileInPath('flashgg/Taggers/data/ttHLeptonic_RunII_MVA_12Jun2019.xml'),
    tthVsttGGDNNfile = cms.FileInPath('flashgg/Taggers/data/ttHLeptonic_ttH_vs_ttGG_v1.6_28May2019_weights.pb')
)


process.flashggTagSorter = cms.EDProducer("FlashggTagSorter",
    BlindedSelectionPrintout = cms.bool(False),
    CreateNoTag = cms.bool(True),
    Debug = cms.untracked.bool(False),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    HTXSTags = cms.PSet(
        ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
        njets = cms.InputTag("rivetProducerHTXS","njets"),
        pTH = cms.InputTag("rivetProducerHTXS","pTH"),
        pTV = cms.InputTag("rivetProducerHTXS","pTV"),
        stage0cat = cms.InputTag("rivetProducerHTXS","stage0cat"),
        stage1cat = cms.InputTag("rivetProducerHTXS","stage1cat")
    ),
    MassCutLower = cms.double(100),
    MassCutUpper = cms.double(180.0),
    MaxObjectWeightException = cms.double(10.0),
    MaxObjectWeightWarning = cms.double(2.5),
    MinObjectWeightException = cms.double(0.0),
    MinObjectWeightWarning = cms.double(0.4),
    StoreOtherTagInfo = cms.bool(True),
    TagPriorityRanges = cms.VPSet(cms.PSet(
        TagName = cms.InputTag("flashggHHWWggTag")
    ))
)


process.flashggUnpackedJets = cms.EDProducer("FlashggVectorVectorJetUnpacker",
    JetsTag = cms.InputTag("flashggFinalJets"),
    NCollections = cms.uint32(12)
)


process.flashggUntagged = cms.EDProducer("FlashggUntaggedTagProducer",
    Boundaries = cms.vdouble(-0.405, 0.204, 0.564, 0.864),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HTXSTags = cms.PSet(
        ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
        njets = cms.InputTag("rivetProducerHTXS","njets"),
        pTH = cms.InputTag("rivetProducerHTXS","pTH"),
        pTV = cms.InputTag("rivetProducerHTXS","pTV"),
        stage0cat = cms.InputTag("rivetProducerHTXS","stage0cat"),
        stage1cat = cms.InputTag("rivetProducerHTXS","stage1cat")
    ),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    RequireScaledPtCuts = cms.bool(True),
    SystLabel = cms.string('')
)


process.flashggVBFDiPhoDiJetMVA = cms.EDProducer("FlashggVBFDiPhoDiJetMVAProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    UseLegacyMVA = cms.bool(False),
    VBFMVAResultTag = cms.InputTag("flashggVBFMVA"),
    vbfDiPhoDiJetMVAweightfile = cms.FileInPath('flashgg/Taggers/data/sklearn_combined_moriond17_v4.xml')
)


process.flashggVBFMVA = cms.EDProducer("FlashggVBFMVAProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    DrJetPhoton = cms.double(0.4),
    JetIDLevel = cms.string('Tight2017'),
    MVAMethod = cms.string('BDTG'),
    MinDijetMinv = cms.double(0.0),
    UseJetID = cms.bool(True),
    UsePuJetID = cms.bool(False),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    merge3rdJet = cms.bool(False),
    pujidWpPtBin1 = cms.vdouble(0.69, -0.35, -0.26, -0.21),
    pujidWpPtBin2 = cms.vdouble(0.86, -0.1, -0.05, -0.01),
    pujidWpPtBin3 = cms.vdouble(0.95, 0.28, 0.31, 0.28),
    rmsforwardCut = cms.double(3.0),
    thirdJetDRCut = cms.double(1.8),
    vbfMVAweightfile = cms.FileInPath('flashgg/Taggers/data/dijet-2017-10Jul.xml')
)


process.flashggVBFTag = cms.EDProducer("FlashggVBFTagProducer",
    Boundaries = cms.vdouble(0.553, 0.902, 0.957),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    DropNonGoldData = cms.bool(False),
    GenJetTag = cms.InputTag("slimmedGenJets"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    GetQCDWeights = cms.bool(False),
    HTXSTags = cms.PSet(
        ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
        njets = cms.InputTag("rivetProducerHTXS","njets"),
        pTH = cms.InputTag("rivetProducerHTXS","pTH"),
        pTV = cms.InputTag("rivetProducerHTXS","pTV"),
        stage0cat = cms.InputTag("rivetProducerHTXS","stage0cat"),
        stage1cat = cms.InputTag("rivetProducerHTXS","stage1cat")
    ),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    RequireVBFPreselection = cms.bool(True),
    SetArbitraryNonGoldMC = cms.bool(False),
    SystLabel = cms.string(''),
    VBFDiPhoDiJetMVAResultTag = cms.InputTag("flashggVBFDiPhoDiJetMVA"),
    VBFMVAResultTag = cms.InputTag("flashggVBFMVA"),
    VBFPreselLeadPtMin = cms.double(40.0),
    VBFPreselPhoIDMVAMin = cms.double(-0.2),
    VBFPreselSubleadPtMin = cms.double(30.0)
)


process.flashggVHEtTag = cms.EDProducer("FlashggVHEtTagProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    FLASHfilters = cms.InputTag("TriggerResults","","FLASHggMicroAOD"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HTXSTags = cms.PSet(
        ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
        njets = cms.InputTag("rivetProducerHTXS","njets"),
        pTH = cms.InputTag("rivetProducerHTXS","pTH"),
        pTV = cms.InputTag("rivetProducerHTXS","pTV"),
        stage0cat = cms.InputTag("rivetProducerHTXS","stage0cat"),
        stage1cat = cms.InputTag("rivetProducerHTXS","stage1cat")
    ),
    METTag = cms.InputTag("flashggMets"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    PATfilters = cms.InputTag("TriggerResults","","PAT"),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SystLabel = cms.string(''),
    dPhiDiphotonMetThreshold = cms.double(2.1),
    diphoMVAThreshold = cms.double(-1.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    metPtThreshold = cms.double(70),
    phoIdMVAThreshold = cms.double(-0.9),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useVertex0only = cms.bool(True)
)


process.flashggVHHadronicTag = cms.EDProducer("FlashggVHHadronicTagProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HTXSTags = cms.PSet(
        ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
        njets = cms.InputTag("rivetProducerHTXS","njets"),
        pTH = cms.InputTag("rivetProducerHTXS","pTH"),
        pTV = cms.InputTag("rivetProducerHTXS","pTV"),
        stage0cat = cms.InputTag("rivetProducerHTXS","stage0cat"),
        stage1cat = cms.InputTag("rivetProducerHTXS","stage1cat")
    ),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    SystLabel = cms.string(''),
    cosThetaStarThreshold = cms.double(0.5),
    dRJetToPhoLThreshold = cms.double(0.4),
    dRJetToPhoSThreshold = cms.double(0.4),
    dijetMassHighThreshold = cms.double(120.0),
    dijetMassLowThreshold = cms.double(60.0),
    diphoMVAThreshold = cms.double(0.6),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(40.0),
    jetsNumberThreshold = cms.double(2.0),
    leadPhoOverMassThreshold = cms.double(0.5),
    phoIdMVAThreshold = cms.double(-0.9),
    subleadPhoOverMassThreshold = cms.double(0.25)
)


process.flashggVHLeptonicLooseTag = cms.EDProducer("FlashggVHLeptonicLooseTagProducer",
    DeltaRTrkElec = cms.double(0.4),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    FLASHfilters = cms.InputTag("TriggerResults","","FLASHggMicroAOD"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HTXSTags = cms.PSet(
        ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
        njets = cms.InputTag("rivetProducerHTXS","njets"),
        pTH = cms.InputTag("rivetProducerHTXS","pTH"),
        pTV = cms.InputTag("rivetProducerHTXS","pTV"),
        stage0cat = cms.InputTag("rivetProducerHTXS","stage0cat"),
        stage1cat = cms.InputTag("rivetProducerHTXS","stage1cat")
    ),
    LongitudinalImpactParam = cms.double(0.2),
    METTag = cms.InputTag("flashggMetSystematics"),
    METThreshold = cms.double(45.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.0),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PATfilters = cms.InputTag("TriggerResults","","PAT"),
    PhoMVAThreshold = cms.double(-0.9),
    PuIDCutoffThreshold = cms.double(0.8),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.double(0.02),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    deltaMassElectronZThreshold = cms.double(10.0),
    deltaRJetElectronThreshold = cms.double(0.4),
    deltaRJetMuonThreshold = cms.double(0.4),
    deltaRMuonPhoThreshold = cms.double(1),
    deltaRPhoElectronThreshold = cms.double(1.0),
    deltaRPhoLeadJet = cms.double(0.4),
    deltaRPhoSubLeadJet = cms.double(0.4),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    electronIsoThreshold = cms.double(0.15),
    electronNumOfHitsThreshold = cms.double(1),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    invMassLepHighThreshold = cms.double(110.0),
    invMassLepLowThreshold = cms.double(70.0),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(20.0),
    jetsNumberThreshold = cms.double(3.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    leptonPtThreshold = cms.double(20),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    nonTrigMVAEtaCuts = cms.vdouble(0.8, 1.479, 2.5),
    nonTrigMVAThresholds = cms.vdouble(0.913286, 0.805013, 0.358969),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useElectronLooseID = cms.bool(True),
    useElectronMVARecipe = cms.bool(False),
    useVertex0only = cms.bool(False)
)


process.flashggVHLooseTag = cms.EDProducer("FlashggVHLooseTagProducer",
    DeltaRTrkElec = cms.double(0.4),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronPtThreshold = cms.double(20.0),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    FLASHfilters = cms.InputTag("TriggerResults","","FLASHggMicroAOD"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HTXSTags = cms.PSet(
        ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
        njets = cms.InputTag("rivetProducerHTXS","njets"),
        pTH = cms.InputTag("rivetProducerHTXS","pTH"),
        pTV = cms.InputTag("rivetProducerHTXS","pTV"),
        stage0cat = cms.InputTag("rivetProducerHTXS","stage0cat"),
        stage1cat = cms.InputTag("rivetProducerHTXS","stage1cat")
    ),
    LongitudinalImpactParam = cms.double(0.2),
    METTag = cms.InputTag("flashggMets"),
    METThreshold = cms.double(45.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.187),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PATfilters = cms.InputTag("TriggerResults","","PAT"),
    PhoMVAThreshold = cms.double(-0.9),
    PuIDCutoffThreshold = cms.double(0.8),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.double(0.02),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    deltaMassElectronZThreshold = cms.double(10.0),
    deltaRJetMuonThreshold = cms.double(0.5),
    deltaRMuonPhoThreshold = cms.double(0.5),
    deltaRPhoElectronThreshold = cms.double(1.0),
    deltaRPhoLeadJet = cms.double(0.5),
    deltaRPhoSubLeadJet = cms.double(0.5),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    electronIsoThreshold = cms.double(0.15),
    electronNumOfHitsThreshold = cms.double(1),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(20.0),
    jetsNumberThreshold = cms.double(3.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    leptonPtThreshold = cms.double(20),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    nonTrigMVAEtaCuts = cms.vdouble(0.8, 1.479, 2.5),
    nonTrigMVAThresholds = cms.vdouble(0.913286, 0.805013, 0.358969),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useElectronLooseID = cms.bool(True),
    useElectronMVARecipe = cms.bool(False),
    useVertex0only = cms.bool(True)
)


process.flashggVHMetTag = cms.EDProducer("FlashggVHMetTagProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    FLASHfilters = cms.InputTag("TriggerResults","","FLASHggMicroAOD"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HTXSTags = cms.PSet(
        ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
        njets = cms.InputTag("rivetProducerHTXS","njets"),
        pTH = cms.InputTag("rivetProducerHTXS","pTH"),
        pTV = cms.InputTag("rivetProducerHTXS","pTV"),
        stage0cat = cms.InputTag("rivetProducerHTXS","stage0cat"),
        stage1cat = cms.InputTag("rivetProducerHTXS","stage1cat")
    ),
    METTag = cms.InputTag("flashggMetSystematics"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    PATfilters = cms.InputTag("TriggerResults","","PAT"),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SystLabel = cms.string(''),
    dPhiDiphotonMetThreshold = cms.double(2.4),
    dPhiJetMetThreshold = cms.double(999.0),
    deltaRPhoLeadJet = cms.double(0.5),
    deltaRPhoSubLeadJet = cms.double(0.5),
    diphoMVAThreshold = cms.double(0.6),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(50.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    metPtThreshold = cms.double(85),
    phoIdMVAThreshold = cms.double(-0.9),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useVertex0only = cms.bool(False)
)


process.flashggVHTightTag = cms.EDProducer("FlashggVHTightTagProducer",
    DeltaRTrkElec = cms.double(0.4),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronPtThreshold = cms.double(20.0),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    FLASHfilters = cms.InputTag("TriggerResults","","FLASHggMicroAOD"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HTXSTags = cms.PSet(
        ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
        njets = cms.InputTag("rivetProducerHTXS","njets"),
        pTH = cms.InputTag("rivetProducerHTXS","pTH"),
        pTV = cms.InputTag("rivetProducerHTXS","pTV"),
        stage0cat = cms.InputTag("rivetProducerHTXS","stage0cat"),
        stage1cat = cms.InputTag("rivetProducerHTXS","stage1cat")
    ),
    LongitudinalImpactParam = cms.double(0.2),
    METTag = cms.InputTag("flashggMets"),
    METThreshold = cms.double(45.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.187),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PATfilters = cms.InputTag("TriggerResults","","PAT"),
    PhoMVAThreshold = cms.double(-0.9),
    PuIDCutoffThreshold = cms.double(0.8),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.double(0.02),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    deltaMassElectronZThreshold = cms.double(10.0),
    deltaRJetElectronThreshold = cms.double(0.5),
    deltaRJetMuonThreshold = cms.double(0.5),
    deltaRLowPtMuonPhoThreshold = cms.double(0.5),
    deltaRMuonPhoThreshold = cms.double(1),
    deltaRPhoElectronThreshold = cms.double(1.0),
    deltaRPhoLeadJet = cms.double(0.5),
    deltaRPhoSubLeadJet = cms.double(0.5),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    electronIsoThreshold = cms.double(0.15),
    electronNumOfHitsThreshold = cms.double(1),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    invMassLepHighThreshold = cms.double(110.0),
    invMassLepLowThreshold = cms.double(70.0),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(20.0),
    jetsNumberThreshold = cms.double(3.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    leptonLowPtThreshold = cms.double(10.0),
    leptonPtThreshold = cms.double(20),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    nonTrigMVAEtaCuts = cms.vdouble(0.8, 1.479, 2.5),
    nonTrigMVAThresholds = cms.vdouble(0.913286, 0.805013, 0.358969),
    numberOfHighPtMuonsThreshold = cms.double(1.0),
    numberOfLowPtMuonsThreshold = cms.double(2.0),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useElectronLooseID = cms.bool(True),
    useElectronMVARecipe = cms.bool(False),
    useVertex0only = cms.bool(True)
)


process.flashggWHLeptonicTag = cms.EDProducer("FlashggWHLeptonicTagProducer",
    DeltaRTrkElec = cms.double(0.4),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    FLASHfilters = cms.InputTag("TriggerResults","","FLASHggMicroAOD"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HTXSTags = cms.PSet(
        ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
        njets = cms.InputTag("rivetProducerHTXS","njets"),
        pTH = cms.InputTag("rivetProducerHTXS","pTH"),
        pTV = cms.InputTag("rivetProducerHTXS","pTV"),
        stage0cat = cms.InputTag("rivetProducerHTXS","stage0cat"),
        stage1cat = cms.InputTag("rivetProducerHTXS","stage1cat")
    ),
    LongitudinalImpactParam = cms.double(0.2),
    METTag = cms.InputTag("flashggMetSystematics"),
    METThreshold = cms.double(45.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.0),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PATfilters = cms.InputTag("TriggerResults","","PAT"),
    PhoMVAThreshold = cms.double(-0.9),
    PuIDCutoffThreshold = cms.double(0.8),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.double(0.02),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    deltaMassElectronZThreshold = cms.double(10.0),
    deltaRJetMuonThreshold = cms.double(0.4),
    deltaRMuonPhoThreshold = cms.double(0.5),
    deltaRPhoElectronThreshold = cms.double(1.0),
    deltaRPhoLeadJet = cms.double(0.4),
    deltaRPhoSubLeadJet = cms.double(0.4),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    electronIsoThreshold = cms.double(0.15),
    electronNumOfHitsThreshold = cms.double(1),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(20.0),
    jetsNumberThreshold = cms.double(3.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    leptonPtThreshold = cms.double(20),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    nonTrigMVAEtaCuts = cms.vdouble(0.8, 1.479, 2.5),
    nonTrigMVAThresholds = cms.vdouble(0.913286, 0.805013, 0.358969),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useElectronLooseID = cms.bool(True),
    useElectronMVARecipe = cms.bool(False),
    useVertex0only = cms.bool(False)
)


process.flashggZHLeptonicTag = cms.EDProducer("FlashggZHLeptonicTagProducer",
    DeltaRTrkElec = cms.double(0.4),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronPtThreshold = cms.double(20.0),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HTXSTags = cms.PSet(
        ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
        njets = cms.InputTag("rivetProducerHTXS","njets"),
        pTH = cms.InputTag("rivetProducerHTXS","pTH"),
        pTV = cms.InputTag("rivetProducerHTXS","pTV"),
        stage0cat = cms.InputTag("rivetProducerHTXS","stage0cat"),
        stage1cat = cms.InputTag("rivetProducerHTXS","stage1cat")
    ),
    LongitudinalImpactParam = cms.double(0.2),
    METTag = cms.InputTag("flashggMetSystematics"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(-0.405),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PhoMVAThreshold = cms.double(-0.9),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.double(0.02),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    deltaMassElectronZThreshold = cms.double(10.0),
    deltaRLowPtMuonPhoThreshold = cms.double(0.5),
    deltaRMuonPhoThreshold = cms.double(1),
    deltaRPhoElectronThreshold = cms.double(1.0),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    electronIsoThreshold = cms.double(0.15),
    electronNumOfHitsThreshold = cms.double(1),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    invMassLepHighThreshold = cms.double(110.0),
    invMassLepLowThreshold = cms.double(70.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    leptonPtThreshold = cms.double(20),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    nonTrigMVAEtaCuts = cms.vdouble(0.8, 1.479, 2.5),
    nonTrigMVAThresholds = cms.vdouble(0.913286, 0.805013, 0.358969),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useElectronLooseID = cms.bool(True),
    useElectronMVARecipe = cms.bool(False),
    useVertex0only = cms.bool(False)
)


process.flashggZPlusJetTag = cms.EDProducer("FlashggZPlusJetTagProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    GenJetTag = cms.InputTag("slimmedGenJets"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    SystLabel = cms.string(''),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    )
)


process.flashggMetFilters = cms.EDFilter("flashggMetFilters",
    filtersInputTag = cms.InputTag("TriggerResults","","RECO"),
    requiredFilterNames = cms.untracked.vstring(
        'Flag_goodVertices', 
        'Flag_globalSuperTightHalo2016Filter', 
        'Flag_HBHENoiseFilter', 
        'Flag_HBHENoiseIsoFilter', 
        'Flag_EcalDeadCellTriggerPrimitiveFilter', 
        'Flag_BadPFMuonFilter'
    )
)


process.flashggPreselectedDiPhotons = cms.EDFilter("GenericDiPhotonCandidateSelector",
    categories = cms.VPSet(
        cms.PSet(
            cut = cms.string('isEB && full5x5_r9>0.85'),
            selection = cms.VPSet(
                cms.PSet(
                    max = cms.string('100000.0'),
                    rhocorr = cms.PSet(
                        bins = cms.vdouble(
                            0.0, 0.9, 1.5, 2, 2.2, 
                            3
                        ),
                        vals = cms.vdouble(0.16544, 0.16544, 0.13212, 0.13212, 0.13212),
                        var = cms.string('abs(superCluster.eta)')
                    )
                ), 
                cms.PSet(
                    max = cms.string('100000.0')
                ), 
                cms.PSet(
                    max = cms.string('100000.0')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                )
            )
        ), 
        cms.PSet(
            cut = cms.string('isEE && full5x5_r9>0.90'),
            selection = cms.VPSet(
                cms.PSet(
                    max = cms.string('100000.0'),
                    rhocorr = cms.PSet(
                        bins = cms.vdouble(
                            0.0, 0.9, 1.5, 2, 2.2, 
                            3
                        ),
                        vals = cms.vdouble(0.16544, 0.16544, 0.13212, 0.13212, 0.13212),
                        var = cms.string('abs(superCluster.eta)')
                    )
                ), 
                cms.PSet(
                    max = cms.string('100000.0')
                ), 
                cms.PSet(
                    max = cms.string('100000.0')
                ), 
                cms.PSet(
                    min = cms.string('0.8')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                )
            )
        ), 
        cms.PSet(
            cut = cms.string('isEB && full5x5_r9<=0.85'),
            selection = cms.VPSet(
                cms.PSet(
                    max = cms.string('4.0'),
                    rhocorr = cms.PSet(
                        bins = cms.vdouble(
                            0.0, 0.9, 1.5, 2, 2.2, 
                            3
                        ),
                        vals = cms.vdouble(0.16544, 0.16544, 0.13212, 0.13212, 0.13212),
                        var = cms.string('abs(superCluster.eta)')
                    )
                ), 
                cms.PSet(
                    max = cms.string('6.0')
                ), 
                cms.PSet(
                    max = cms.string('0.015')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                )
            )
        ), 
        cms.PSet(
            cut = cms.string('isEE && full5x5_r9<=0.90'),
            selection = cms.VPSet(
                cms.PSet(
                    max = cms.string('4.0'),
                    rhocorr = cms.PSet(
                        bins = cms.vdouble(
                            0.0, 0.9, 1.5, 2, 2.2, 
                            3
                        ),
                        vals = cms.vdouble(0.16544, 0.16544, 0.13212, 0.13212, 0.13212),
                        var = cms.string('abs(superCluster.eta)')
                    )
                ), 
                cms.PSet(
                    max = cms.string('6.0')
                ), 
                cms.PSet(
                    max = cms.string('0.035')
                ), 
                cms.PSet(
                    min = cms.string('0.8')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                )
            )
        )
    ),
    cut = cms.string('    (leadingPhoton.full5x5_r9>0.8||leadingPhoton.egChargedHadronIso<20||leadingPhoton.egChargedHadronIso/leadingPhoton.pt<0.3) && (subLeadingPhoton.full5x5_r9>0.8||subLeadingPhoton.egChargedHadronIso<20||subLeadingPhoton.egChargedHadronIso/subLeadingPhoton.pt<0.3) && (leadingPhoton.hadronicOverEm < 0.08 && subLeadingPhoton.hadronicOverEm < 0.08) && (leadingPhoton.pt >35.0 && subLeadingPhoton.pt > 25.0) && (abs(leadingPhoton.superCluster.eta) < 2.5 && abs(subLeadingPhoton.superCluster.eta) < 2.5) && (abs(leadingPhoton.superCluster.eta) < 1.4442 || abs(leadingPhoton.superCluster.eta) > 1.566) && (abs(subLeadingPhoton.superCluster.eta) < 1.4442 || abs(subLeadingPhoton.superCluster.eta) > 1.566) && (leadPhotonId > -0.9 && subLeadPhotonId > -0.9)'),
    rho = cms.InputTag("fixedGridRhoAll"),
    src = cms.InputTag("flashggDiPhotonSystematics"),
    variables = cms.vstring(
        'pfPhoIso03', 
        'trkSumPtHollowConeDR03', 
        'full5x5_sigmaIetaIeta', 
        'full5x5_r9', 
        'passElectronVeto'
    )
)


process.hltHighLevel = cms.EDFilter("HLTHighLevel",
    HLTPaths = cms.vstring(),
    TriggerResultsTag = cms.InputTag("TriggerResults","","HLT"),
    andOr = cms.bool(True),
    eventSetupPathsKey = cms.string(''),
    throw = cms.bool(True)
)


process.content = cms.EDAnalyzer("EventContentAnalyzer")


process.tagsDumper = cms.EDAnalyzer("DiPhotonTagDumper",
    NNLOPSWeightFile = cms.FileInPath('flashgg/Taggers/data/NNLOPS_reweight.root'),
    categories = cms.VPSet(cms.PSet(
        className = cms.string('HHWWggTag'),
        histograms = cms.VPSet(),
        label = cms.string(''),
        nAlphaSWeights = cms.int32(-1),
        nPdfWeights = cms.int32(-1),
        nScaleWeights = cms.int32(-1),
        splitPdfByStage0Cat = cms.bool(False),
        subcats = cms.int32(4),
        variables = cms.VPSet( (
            cms.PSet(
                expr = cms.string('diPhoton().mass'),
                name = cms.untracked.string('CMS_hgg_mass'),
                nbins = cms.untracked.int32(160),
                vmax = cms.untracked.double(180.0),
                vmin = cms.untracked.double(100.0)
            ), 
            cms.PSet(
                expr = cms.string('(tagTruth().genPV().z-diPhoton().vtx().z)'),
                name = cms.untracked.string('dZ'),
                nbins = cms.untracked.int32(40),
                vmax = cms.untracked.double(20.0),
                vmin = cms.untracked.double(-20.0)
            ), 
            cms.PSet(
                expr = cms.string('centralWeight'),
                name = cms.untracked.string('centralObjectWeight'),
                nbins = cms.untracked.int32(1),
                vmax = cms.untracked.double(999999.0),
                vmin = cms.untracked.double(-999999.0)
            ), 
            cms.PSet(
                expr = cms.string('dijet.E()'),
                name = cms.untracked.string('W1Candidate_E')
            ), 
            cms.PSet(
                expr = cms.string('dijet.M()'),
                name = cms.untracked.string('W1Candidate_M')
            ), 
            cms.PSet(
                expr = cms.string('dijet.pt()'),
                name = cms.untracked.string('W1Candidate_pt')
            ), 
            cms.PSet(
                expr = cms.string('dijet.px()'),
                name = cms.untracked.string('W1Candidate_px')
            ), 
            cms.PSet(
                expr = cms.string('dijet.py()'),
                name = cms.untracked.string('W1Candidate_py')
            ), 
            cms.PSet(
                expr = cms.string('dijet.pz()'),
                name = cms.untracked.string('W1Candidate_pz')
            ), 
            cms.PSet(
                expr = cms.string('dijet.eta()'),
                name = cms.untracked.string('W1Candidate_eta')
            ), 
            cms.PSet(
                expr = cms.string('dijet.phi()'),
                name = cms.untracked.string('W1Candidate_phi')
            ), 
            cms.PSet(
                expr = cms.string('dijet2.E()'),
                name = cms.untracked.string('W2Candidate_E')
            ), 
            cms.PSet(
                expr = cms.string('dijet2.M()'),
                name = cms.untracked.string('W2Candidate_M')
            ), 
            cms.PSet(
                expr = cms.string('dijet2.pt()'),
                name = cms.untracked.string('W2Candidate_pt')
            ), 
            cms.PSet(
                expr = cms.string('dijet2.px()'),
                name = cms.untracked.string('W2Candidate_px')
            ), 
            cms.PSet(
                expr = cms.string('dijet2.py()'),
                name = cms.untracked.string('W2Candidate_py')
            ), 
            cms.PSet(
                expr = cms.string('dijet2.pz()'),
                name = cms.untracked.string('W2Candidate_pz')
            ), 
            cms.PSet(
                expr = cms.string('dijet2.eta()'),
                name = cms.untracked.string('W2Candidate_eta')
            ), 
            cms.PSet(
                expr = cms.string('dijet2.phi()'),
                name = cms.untracked.string('W2Candidate_phi')
            ), 
            cms.PSet(
                expr = cms.string('HWW.E()'),
                name = cms.untracked.string('HWWCandidate_E')
            ), 
            cms.PSet(
                expr = cms.string('HWW.M()'),
                name = cms.untracked.string('HWWCandidate_M')
            ), 
            cms.PSet(
                expr = cms.string('HWW.pt()'),
                name = cms.untracked.string('HWWCandidate_pt')
            ), 
            cms.PSet(
                expr = cms.string('HWW.px()'),
                name = cms.untracked.string('HWWCandidate_px')
            ), 
            cms.PSet(
                expr = cms.string('HWW.py()'),
                name = cms.untracked.string('HWWCandidate_py')
            ), 
            cms.PSet(
                expr = cms.string('HWW.pz()'),
                name = cms.untracked.string('HWWCandidate_pz')
            ), 
            cms.PSet(
                expr = cms.string('HWW.eta()'),
                name = cms.untracked.string('HWWCandidate_eta')
            ), 
            cms.PSet(
                expr = cms.string('HWW.phi()'),
                name = cms.untracked.string('HWWCandidate_phi')
            ), 
            cms.PSet(
                expr = cms.string('HGG.E()'),
                name = cms.untracked.string('HGGCandidate_E')
            ), 
            cms.PSet(
                expr = cms.string('HGG.M()'),
                name = cms.untracked.string('HGGCandidate_M')
            ), 
            cms.PSet(
                expr = cms.string('HGG.pt()'),
                name = cms.untracked.string('HGGCandidate_pt')
            ), 
            cms.PSet(
                expr = cms.string('HGG.px()'),
                name = cms.untracked.string('HGGCandidate_px')
            ), 
            cms.PSet(
                expr = cms.string('HGG.py()'),
                name = cms.untracked.string('HGGCandidate_py')
            ), 
            cms.PSet(
                expr = cms.string('HGG.pz()'),
                name = cms.untracked.string('HGGCandidate_pz')
            ), 
            cms.PSet(
                expr = cms.string('HGG.eta()'),
                name = cms.untracked.string('HGGCandidate_eta')
            ), 
            cms.PSet(
                expr = cms.string('HGG.phi()'),
                name = cms.untracked.string('HGGCandidate_phi')
            ), 
            cms.PSet(
                expr = cms.string('HH.E()'),
                name = cms.untracked.string('HHCandidate_E')
            ), 
            cms.PSet(
                expr = cms.string('HH.M()'),
                name = cms.untracked.string('HHCandidate_M')
            ), 
            cms.PSet(
                expr = cms.string('HH.pt()'),
                name = cms.untracked.string('HHCandidate_pt')
            ), 
            cms.PSet(
                expr = cms.string('HH.px()'),
                name = cms.untracked.string('HHCandidate_px')
            ), 
            cms.PSet(
                expr = cms.string('HH.py()'),
                name = cms.untracked.string('HHCandidate_py')
            ), 
            cms.PSet(
                expr = cms.string('HH.pz()'),
                name = cms.untracked.string('HHCandidate_pz')
            ), 
            cms.PSet(
                expr = cms.string('HH.eta()'),
                name = cms.untracked.string('HHCandidate_eta')
            ), 
            cms.PSet(
                expr = cms.string('HH.phi()'),
                name = cms.untracked.string('HHCandidate_phi')
            ), 
            cms.PSet(
                expr = cms.string('lp_Hgg_MVA'),
                name = cms.untracked.string('Leading_Photon_MVA')
            ), 
            cms.PSet(
                expr = cms.string('slp_Hgg_MVA'),
                name = cms.untracked.string('Subleading_Photon_MVA')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Photon.p4().E()'),
                name = cms.untracked.string('Leading_Photon_E')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Photon.p4().pt()'),
                name = cms.untracked.string('Leading_Photon_pt')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Photon.p4().px()'),
                name = cms.untracked.string('Leading_Photon_px')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Photon.p4().py()'),
                name = cms.untracked.string('Leading_Photon_py')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Photon.p4().pz()'),
                name = cms.untracked.string('Leading_Photon_pz')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Photon.p4().eta()'),
                name = cms.untracked.string('Leading_Photon_eta')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Photon.p4().phi()'),
                name = cms.untracked.string('Leading_Photon_phi')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Photon.p4().E()'),
                name = cms.untracked.string('Subleading_Photon_E')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Photon.p4().pt()'),
                name = cms.untracked.string('Subleading_Photon_pt')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Photon.p4().px()'),
                name = cms.untracked.string('Subleading_Photon_px')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Photon.p4().py()'),
                name = cms.untracked.string('Subleading_Photon_py')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Photon.p4().pz()'),
                name = cms.untracked.string('Subleading_Photon_pz')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Photon.p4().eta()'),
                name = cms.untracked.string('Subleading_Photon_eta')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Photon.p4().phi()'),
                name = cms.untracked.string('Subleading_Photon_phi')
            ), 
            cms.PSet(
                expr = cms.string('Electron.p4().E()'),
                name = cms.untracked.string('Electron_E')
            ), 
            cms.PSet(
                expr = cms.string('Electron.p4().pt()'),
                name = cms.untracked.string('Electron_pt')
            ), 
            cms.PSet(
                expr = cms.string('Electron.p4().px()'),
                name = cms.untracked.string('Electron_px')
            ), 
            cms.PSet(
                expr = cms.string('Electron.p4().py()'),
                name = cms.untracked.string('Electron_py')
            ), 
            cms.PSet(
                expr = cms.string('Electron.p4().pz()'),
                name = cms.untracked.string('Electron_pz')
            ), 
            cms.PSet(
                expr = cms.string('Electron.p4().eta()'),
                name = cms.untracked.string('Electron_eta')
            ), 
            cms.PSet(
                expr = cms.string('Electron.p4().phi()'),
                name = cms.untracked.string('Electron_phi')
            ), 
            cms.PSet(
                expr = cms.string('Muon.p4().E()'),
                name = cms.untracked.string('Muon_E')
            ), 
            cms.PSet(
                expr = cms.string('Muon.p4().pt()'),
                name = cms.untracked.string('Muon_pt')
            ), 
            cms.PSet(
                expr = cms.string('Muon.p4().px()'),
                name = cms.untracked.string('Muon_px')
            ), 
            cms.PSet(
                expr = cms.string('Muon.p4().py()'),
                name = cms.untracked.string('Muon_py')
            ), 
            cms.PSet(
                expr = cms.string('Muon.p4().pz()'),
                name = cms.untracked.string('Muon_pz')
            ), 
            cms.PSet(
                expr = cms.string('Muon.p4().eta()'),
                name = cms.untracked.string('Muon_eta')
            ), 
            cms.PSet(
                expr = cms.string('Muon.p4().phi()'),
                name = cms.untracked.string('Muon_phi')
            ), 
            cms.PSet(
                expr = cms.string('MET.p4().E()'),
                name = cms.untracked.string('MET_E')
            ), 
            cms.PSet(
                expr = cms.string('MET.p4().pt()'),
                name = cms.untracked.string('MET_pt')
            ), 
            cms.PSet(
                expr = cms.string('MET.p4().px()'),
                name = cms.untracked.string('MET_px')
            ), 
            cms.PSet(
                expr = cms.string('MET.p4().py()'),
                name = cms.untracked.string('MET_py')
            ), 
            cms.PSet(
                expr = cms.string('MET.p4().pz()'),
                name = cms.untracked.string('MET_pz')
            ), 
            cms.PSet(
                expr = cms.string('MET.p4().eta()'),
                name = cms.untracked.string('MET_eta')
            ), 
            cms.PSet(
                expr = cms.string('MET.p4().phi()'),
                name = cms.untracked.string('MET_phi')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Jet.p4().E()'),
                name = cms.untracked.string('Leading_Jet_E')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Jet.p4().pt()'),
                name = cms.untracked.string('Leading_Jet_pt')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Jet.p4().px()'),
                name = cms.untracked.string('Leading_Jet_px')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Jet.p4().py()'),
                name = cms.untracked.string('Leading_Jet_py')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Jet.p4().pz()'),
                name = cms.untracked.string('Leading_Jet_pz')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Jet.p4().eta()'),
                name = cms.untracked.string('Leading_Jet_eta')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Jet.p4().phi()'),
                name = cms.untracked.string('Leading_Jet_phi')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Jet.p4().E()'),
                name = cms.untracked.string('Subleading_Jet_E')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Jet.p4().pt()'),
                name = cms.untracked.string('Subleading_Jet_pt')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Jet.p4().px()'),
                name = cms.untracked.string('Subleading_Jet_px')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Jet.p4().py()'),
                name = cms.untracked.string('Subleading_Jet_py')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Jet.p4().pz()'),
                name = cms.untracked.string('Subleading_Jet_pz')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Jet.p4().eta()'),
                name = cms.untracked.string('Subleading_Jet_eta')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Jet.p4().phi()'),
                name = cms.untracked.string('Subleading_Jet_phi')
            ), 
            cms.PSet(
                expr = cms.string('Sub2leading_Jet.p4().E()'),
                name = cms.untracked.string('Sub2leading_Jet_E')
            ), 
            cms.PSet(
                expr = cms.string('Sub2leading_Jet.p4().pt()'),
                name = cms.untracked.string('Sub2leading_Jet_pt')
            ), 
            cms.PSet(
                expr = cms.string('Sub2leading_Jet.p4().px()'),
                name = cms.untracked.string('Sub2leading_Jet_px')
            ), 
            cms.PSet(
                expr = cms.string('Sub2leading_Jet.p4().py()'),
                name = cms.untracked.string('Sub2leading_Jet_py')
            ), 
            cms.PSet(
                expr = cms.string('Sub2leading_Jet.p4().pz()'),
                name = cms.untracked.string('Sub2leading_Jet_pz')
            ), 
            cms.PSet(
                expr = cms.string('Sub2leading_Jet.p4().eta()'),
                name = cms.untracked.string('Sub2leading_Jet_eta')
            ), 
            cms.PSet(
                expr = cms.string('Sub2leading_Jet.p4().phi()'),
                name = cms.untracked.string('Sub2leading_Jet_phi')
            ), 
            cms.PSet(
                expr = cms.string('Sub3leading_Jet.p4().E()'),
                name = cms.untracked.string('Sub3leading_Jet_E')
            ), 
            cms.PSet(
                expr = cms.string('Sub3leading_Jet.p4().pt()'),
                name = cms.untracked.string('Sub3leading_Jet_pt')
            ), 
            cms.PSet(
                expr = cms.string('Sub3leading_Jet.p4().px()'),
                name = cms.untracked.string('Sub3leading_Jet_px')
            ), 
            cms.PSet(
                expr = cms.string('Sub3leading_Jet.p4().py()'),
                name = cms.untracked.string('Sub3leading_Jet_py')
            ), 
            cms.PSet(
                expr = cms.string('Sub3leading_Jet.p4().pz()'),
                name = cms.untracked.string('Sub3leading_Jet_pz')
            ), 
            cms.PSet(
                expr = cms.string('Sub3leading_Jet.p4().eta()'),
                name = cms.untracked.string('Sub3leading_Jet_eta')
            ), 
            cms.PSet(
                expr = cms.string('Sub3leading_Jet.p4().phi()'),
                name = cms.untracked.string('Sub3leading_Jet_phi')
            ), 
            cms.PSet(
                expr = cms.string('allElectrons.size()'),
                name = cms.untracked.string('N_allElectrons')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 1 ? allElectrons[0].p4().E() : -999'),
                name = cms.untracked.string('allElectrons_0_E')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 2 ? allElectrons[1].p4().E() : -999'),
                name = cms.untracked.string('allElectrons_1_E')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 3 ? allElectrons[2].p4().E() : -999'),
                name = cms.untracked.string('allElectrons_2_E')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 4 ? allElectrons[3].p4().E() : -999'),
                name = cms.untracked.string('allElectrons_3_E')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 5 ? allElectrons[4].p4().E() : -999'),
                name = cms.untracked.string('allElectrons_4_E')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 1 ? allElectrons[0].p4().pt() : -999'),
                name = cms.untracked.string('allElectrons_0_pt')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 2 ? allElectrons[1].p4().pt() : -999'),
                name = cms.untracked.string('allElectrons_1_pt')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 3 ? allElectrons[2].p4().pt() : -999'),
                name = cms.untracked.string('allElectrons_2_pt')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 4 ? allElectrons[3].p4().pt() : -999'),
                name = cms.untracked.string('allElectrons_3_pt')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 5 ? allElectrons[4].p4().pt() : -999'),
                name = cms.untracked.string('allElectrons_4_pt')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 1 ? allElectrons[0].p4().px() : -999'),
                name = cms.untracked.string('allElectrons_0_px')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 2 ? allElectrons[1].p4().px() : -999'),
                name = cms.untracked.string('allElectrons_1_px')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 3 ? allElectrons[2].p4().px() : -999'),
                name = cms.untracked.string('allElectrons_2_px')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 4 ? allElectrons[3].p4().px() : -999'),
                name = cms.untracked.string('allElectrons_3_px')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 5 ? allElectrons[4].p4().px() : -999'),
                name = cms.untracked.string('allElectrons_4_px')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 1 ? allElectrons[0].p4().py() : -999'),
                name = cms.untracked.string('allElectrons_0_py')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 2 ? allElectrons[1].p4().py() : -999'),
                name = cms.untracked.string('allElectrons_1_py')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 3 ? allElectrons[2].p4().py() : -999'),
                name = cms.untracked.string('allElectrons_2_py')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 4 ? allElectrons[3].p4().py() : -999'),
                name = cms.untracked.string('allElectrons_3_py')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 5 ? allElectrons[4].p4().py() : -999'),
                name = cms.untracked.string('allElectrons_4_py')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 1 ? allElectrons[0].p4().pz() : -999'),
                name = cms.untracked.string('allElectrons_0_pz')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 2 ? allElectrons[1].p4().pz() : -999'),
                name = cms.untracked.string('allElectrons_1_pz')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 3 ? allElectrons[2].p4().pz() : -999'),
                name = cms.untracked.string('allElectrons_2_pz')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 4 ? allElectrons[3].p4().pz() : -999'),
                name = cms.untracked.string('allElectrons_3_pz')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 5 ? allElectrons[4].p4().pz() : -999'),
                name = cms.untracked.string('allElectrons_4_pz')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 1 ? allElectrons[0].p4().eta() : -999'),
                name = cms.untracked.string('allElectrons_0_eta')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 2 ? allElectrons[1].p4().eta() : -999'),
                name = cms.untracked.string('allElectrons_1_eta')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 3 ? allElectrons[2].p4().eta() : -999'),
                name = cms.untracked.string('allElectrons_2_eta')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 4 ? allElectrons[3].p4().eta() : -999'),
                name = cms.untracked.string('allElectrons_3_eta')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 5 ? allElectrons[4].p4().eta() : -999'),
                name = cms.untracked.string('allElectrons_4_eta')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 1 ? allElectrons[0].p4().phi() : -999'),
                name = cms.untracked.string('allElectrons_0_phi')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 2 ? allElectrons[1].p4().phi() : -999'),
                name = cms.untracked.string('allElectrons_1_phi')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 3 ? allElectrons[2].p4().phi() : -999'),
                name = cms.untracked.string('allElectrons_2_phi')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 4 ? allElectrons[3].p4().phi() : -999'),
                name = cms.untracked.string('allElectrons_3_phi')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 5 ? allElectrons[4].p4().phi() : -999'),
                name = cms.untracked.string('allElectrons_4_phi')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 1 ? allElectrons[0].passLooseId() : -999'),
                name = cms.untracked.string('allElectrons_0_passLooseId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 2 ? allElectrons[1].passLooseId() : -999'),
                name = cms.untracked.string('allElectrons_1_passLooseId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 3 ? allElectrons[2].passLooseId() : -999'),
                name = cms.untracked.string('allElectrons_2_passLooseId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 4 ? allElectrons[3].passLooseId() : -999'),
                name = cms.untracked.string('allElectrons_3_passLooseId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 5 ? allElectrons[4].passLooseId() : -999'),
                name = cms.untracked.string('allElectrons_4_passLooseId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 1 ? allElectrons[0].passMediumId() : -999'),
                name = cms.untracked.string('allElectrons_0_passMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 2 ? allElectrons[1].passMediumId() : -999'),
                name = cms.untracked.string('allElectrons_1_passMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 3 ? allElectrons[2].passMediumId() : -999'),
                name = cms.untracked.string('allElectrons_2_passMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 4 ? allElectrons[3].passMediumId() : -999'),
                name = cms.untracked.string('allElectrons_3_passMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 5 ? allElectrons[4].passMediumId() : -999'),
                name = cms.untracked.string('allElectrons_4_passMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 1 ? allElectrons[0].passTightId() : -999'),
                name = cms.untracked.string('allElectrons_0_passTightId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 2 ? allElectrons[1].passTightId() : -999'),
                name = cms.untracked.string('allElectrons_1_passTightId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 3 ? allElectrons[2].passTightId() : -999'),
                name = cms.untracked.string('allElectrons_2_passTightId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 4 ? allElectrons[3].passTightId() : -999'),
                name = cms.untracked.string('allElectrons_3_passTightId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 5 ? allElectrons[4].passTightId() : -999'),
                name = cms.untracked.string('allElectrons_4_passTightId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 1 ? allElectrons[0].passMVALooseId() : -999'),
                name = cms.untracked.string('allElectrons_0_passMVALooseId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 2 ? allElectrons[1].passMVALooseId() : -999'),
                name = cms.untracked.string('allElectrons_1_passMVALooseId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 3 ? allElectrons[2].passMVALooseId() : -999'),
                name = cms.untracked.string('allElectrons_2_passMVALooseId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 4 ? allElectrons[3].passMVALooseId() : -999'),
                name = cms.untracked.string('allElectrons_3_passMVALooseId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 5 ? allElectrons[4].passMVALooseId() : -999'),
                name = cms.untracked.string('allElectrons_4_passMVALooseId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 1 ? allElectrons[0].passMVAMediumId() : -999'),
                name = cms.untracked.string('allElectrons_0_passMVAMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 2 ? allElectrons[1].passMVAMediumId() : -999'),
                name = cms.untracked.string('allElectrons_1_passMVAMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 3 ? allElectrons[2].passMVAMediumId() : -999'),
                name = cms.untracked.string('allElectrons_2_passMVAMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 4 ? allElectrons[3].passMVAMediumId() : -999'),
                name = cms.untracked.string('allElectrons_3_passMVAMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 5 ? allElectrons[4].passMVAMediumId() : -999'),
                name = cms.untracked.string('allElectrons_4_passMVAMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 1 ? allElectrons[0].passMVATightId() : -999'),
                name = cms.untracked.string('allElectrons_0_passMVATightId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 2 ? allElectrons[1].passMVATightId() : -999'),
                name = cms.untracked.string('allElectrons_1_passMVATightId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 3 ? allElectrons[2].passMVATightId() : -999'),
                name = cms.untracked.string('allElectrons_2_passMVATightId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 4 ? allElectrons[3].passMVATightId() : -999'),
                name = cms.untracked.string('allElectrons_3_passMVATightId')
            ), 
            cms.PSet(
                expr = cms.string('? allElectrons.size() >= 5 ? allElectrons[4].passMVATightId() : -999'),
                name = cms.untracked.string('allElectrons_4_passMVATightId')
            ), 
            cms.PSet(
                expr = cms.string('allMuons.size()'),
                name = cms.untracked.string('N_allMuons')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 1 ? allMuons[0].p4().E() : -999'),
                name = cms.untracked.string('allMuons_0_E')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 2 ? allMuons[1].p4().E() : -999'),
                name = cms.untracked.string('allMuons_1_E')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 3 ? allMuons[2].p4().E() : -999'),
                name = cms.untracked.string('allMuons_2_E')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 4 ? allMuons[3].p4().E() : -999'),
                name = cms.untracked.string('allMuons_3_E')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 5 ? allMuons[4].p4().E() : -999'),
                name = cms.untracked.string('allMuons_4_E')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 1 ? allMuons[0].p4().pt() : -999'),
                name = cms.untracked.string('allMuons_0_pt')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 2 ? allMuons[1].p4().pt() : -999'),
                name = cms.untracked.string('allMuons_1_pt')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 3 ? allMuons[2].p4().pt() : -999'),
                name = cms.untracked.string('allMuons_2_pt')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 4 ? allMuons[3].p4().pt() : -999'),
                name = cms.untracked.string('allMuons_3_pt')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 5 ? allMuons[4].p4().pt() : -999'),
                name = cms.untracked.string('allMuons_4_pt')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 1 ? allMuons[0].p4().px() : -999'),
                name = cms.untracked.string('allMuons_0_px')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 2 ? allMuons[1].p4().px() : -999'),
                name = cms.untracked.string('allMuons_1_px')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 3 ? allMuons[2].p4().px() : -999'),
                name = cms.untracked.string('allMuons_2_px')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 4 ? allMuons[3].p4().px() : -999'),
                name = cms.untracked.string('allMuons_3_px')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 5 ? allMuons[4].p4().px() : -999'),
                name = cms.untracked.string('allMuons_4_px')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 1 ? allMuons[0].p4().py() : -999'),
                name = cms.untracked.string('allMuons_0_py')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 2 ? allMuons[1].p4().py() : -999'),
                name = cms.untracked.string('allMuons_1_py')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 3 ? allMuons[2].p4().py() : -999'),
                name = cms.untracked.string('allMuons_2_py')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 4 ? allMuons[3].p4().py() : -999'),
                name = cms.untracked.string('allMuons_3_py')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 5 ? allMuons[4].p4().py() : -999'),
                name = cms.untracked.string('allMuons_4_py')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 1 ? allMuons[0].p4().pz() : -999'),
                name = cms.untracked.string('allMuons_0_pz')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 2 ? allMuons[1].p4().pz() : -999'),
                name = cms.untracked.string('allMuons_1_pz')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 3 ? allMuons[2].p4().pz() : -999'),
                name = cms.untracked.string('allMuons_2_pz')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 4 ? allMuons[3].p4().pz() : -999'),
                name = cms.untracked.string('allMuons_3_pz')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 5 ? allMuons[4].p4().pz() : -999'),
                name = cms.untracked.string('allMuons_4_pz')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 1 ? allMuons[0].p4().eta() : -999'),
                name = cms.untracked.string('allMuons_0_eta')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 2 ? allMuons[1].p4().eta() : -999'),
                name = cms.untracked.string('allMuons_1_eta')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 3 ? allMuons[2].p4().eta() : -999'),
                name = cms.untracked.string('allMuons_2_eta')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 4 ? allMuons[3].p4().eta() : -999'),
                name = cms.untracked.string('allMuons_3_eta')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 5 ? allMuons[4].p4().eta() : -999'),
                name = cms.untracked.string('allMuons_4_eta')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 1 ? allMuons[0].p4().phi() : -999'),
                name = cms.untracked.string('allMuons_0_phi')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 2 ? allMuons[1].p4().phi() : -999'),
                name = cms.untracked.string('allMuons_1_phi')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 3 ? allMuons[2].p4().phi() : -999'),
                name = cms.untracked.string('allMuons_2_phi')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 4 ? allMuons[3].p4().phi() : -999'),
                name = cms.untracked.string('allMuons_3_phi')
            ), 
            cms.PSet(
                expr = cms.string('? allMuons.size() >= 5 ? allMuons[4].p4().phi() : -999'),
                name = cms.untracked.string('allMuons_4_phi')
            ), 
            cms.PSet(
                expr = cms.string('allJets.size()'),
                name = cms.untracked.string('N_allJets')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 1 ? allJets[0].p4().E() : -999'),
                name = cms.untracked.string('allJets_0_E')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 2 ? allJets[1].p4().E() : -999'),
                name = cms.untracked.string('allJets_1_E')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 3 ? allJets[2].p4().E() : -999'),
                name = cms.untracked.string('allJets_2_E')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 4 ? allJets[3].p4().E() : -999'),
                name = cms.untracked.string('allJets_3_E')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 5 ? allJets[4].p4().E() : -999'),
                name = cms.untracked.string('allJets_4_E')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 1 ? allJets[0].p4().pt() : -999'),
                name = cms.untracked.string('allJets_0_pt')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 2 ? allJets[1].p4().pt() : -999'),
                name = cms.untracked.string('allJets_1_pt')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 3 ? allJets[2].p4().pt() : -999'),
                name = cms.untracked.string('allJets_2_pt')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 4 ? allJets[3].p4().pt() : -999'),
                name = cms.untracked.string('allJets_3_pt')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 5 ? allJets[4].p4().pt() : -999'),
                name = cms.untracked.string('allJets_4_pt')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 1 ? allJets[0].p4().px() : -999'),
                name = cms.untracked.string('allJets_0_px')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 2 ? allJets[1].p4().px() : -999'),
                name = cms.untracked.string('allJets_1_px')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 3 ? allJets[2].p4().px() : -999'),
                name = cms.untracked.string('allJets_2_px')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 4 ? allJets[3].p4().px() : -999'),
                name = cms.untracked.string('allJets_3_px')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 5 ? allJets[4].p4().px() : -999'),
                name = cms.untracked.string('allJets_4_px')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 1 ? allJets[0].p4().py() : -999'),
                name = cms.untracked.string('allJets_0_py')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 2 ? allJets[1].p4().py() : -999'),
                name = cms.untracked.string('allJets_1_py')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 3 ? allJets[2].p4().py() : -999'),
                name = cms.untracked.string('allJets_2_py')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 4 ? allJets[3].p4().py() : -999'),
                name = cms.untracked.string('allJets_3_py')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 5 ? allJets[4].p4().py() : -999'),
                name = cms.untracked.string('allJets_4_py')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 1 ? allJets[0].p4().pz() : -999'),
                name = cms.untracked.string('allJets_0_pz')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 2 ? allJets[1].p4().pz() : -999'),
                name = cms.untracked.string('allJets_1_pz')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 3 ? allJets[2].p4().pz() : -999'),
                name = cms.untracked.string('allJets_2_pz')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 4 ? allJets[3].p4().pz() : -999'),
                name = cms.untracked.string('allJets_3_pz')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 5 ? allJets[4].p4().pz() : -999'),
                name = cms.untracked.string('allJets_4_pz')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 1 ? allJets[0].p4().eta() : -999'),
                name = cms.untracked.string('allJets_0_eta')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 2 ? allJets[1].p4().eta() : -999'),
                name = cms.untracked.string('allJets_1_eta')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 3 ? allJets[2].p4().eta() : -999'),
                name = cms.untracked.string('allJets_2_eta')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 4 ? allJets[3].p4().eta() : -999'),
                name = cms.untracked.string('allJets_3_eta')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 5 ? allJets[4].p4().eta() : -999'),
                name = cms.untracked.string('allJets_4_eta')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 1 ? allJets[0].p4().phi() : -999'),
                name = cms.untracked.string('allJets_0_phi')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 2 ? allJets[1].p4().phi() : -999'),
                name = cms.untracked.string('allJets_1_phi')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 3 ? allJets[2].p4().phi() : -999'),
                name = cms.untracked.string('allJets_2_phi')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 4 ? allJets[3].p4().phi() : -999'),
                name = cms.untracked.string('allJets_3_phi')
            ), 
            cms.PSet(
                expr = cms.string('? allJets.size() >= 5 ? allJets[4].p4().phi() : -999'),
                name = cms.untracked.string('allJets_4_phi')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 1 ? allJets[0].bDiscriminator(\'mini_pfDeepFlavourJetTags:probb\') : -999"),
                name = cms.untracked.string('allJets_0_bDiscriminator_mini_pfDeepFlavourJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 2 ? allJets[1].bDiscriminator(\'mini_pfDeepFlavourJetTags:probb\') : -999"),
                name = cms.untracked.string('allJets_1_bDiscriminator_mini_pfDeepFlavourJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 3 ? allJets[2].bDiscriminator(\'mini_pfDeepFlavourJetTags:probb\') : -999"),
                name = cms.untracked.string('allJets_2_bDiscriminator_mini_pfDeepFlavourJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 4 ? allJets[3].bDiscriminator(\'mini_pfDeepFlavourJetTags:probb\') : -999"),
                name = cms.untracked.string('allJets_3_bDiscriminator_mini_pfDeepFlavourJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 5 ? allJets[4].bDiscriminator(\'mini_pfDeepFlavourJetTags:probb\') : -999"),
                name = cms.untracked.string('allJets_4_bDiscriminator_mini_pfDeepFlavourJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 1 ? allJets[0].bDiscriminator(\'pfDeepCSVJetTags:probb\') : -999"),
                name = cms.untracked.string('allJets_0_bDiscriminator_pfDeepCSVJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 2 ? allJets[1].bDiscriminator(\'pfDeepCSVJetTags:probb\') : -999"),
                name = cms.untracked.string('allJets_1_bDiscriminator_pfDeepCSVJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 3 ? allJets[2].bDiscriminator(\'pfDeepCSVJetTags:probb\') : -999"),
                name = cms.untracked.string('allJets_2_bDiscriminator_pfDeepCSVJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 4 ? allJets[3].bDiscriminator(\'pfDeepCSVJetTags:probb\') : -999"),
                name = cms.untracked.string('allJets_3_bDiscriminator_pfDeepCSVJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 5 ? allJets[4].bDiscriminator(\'pfDeepCSVJetTags:probb\') : -999"),
                name = cms.untracked.string('allJets_4_bDiscriminator_pfDeepCSVJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 1 ? allJets[0].bDiscriminator(\'mini_pfDeepFlavourJetTags:probbb\') : -999"),
                name = cms.untracked.string('allJets_0_bDiscriminator_mini_pfDeepFlavourJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 2 ? allJets[1].bDiscriminator(\'mini_pfDeepFlavourJetTags:probbb\') : -999"),
                name = cms.untracked.string('allJets_1_bDiscriminator_mini_pfDeepFlavourJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 3 ? allJets[2].bDiscriminator(\'mini_pfDeepFlavourJetTags:probbb\') : -999"),
                name = cms.untracked.string('allJets_2_bDiscriminator_mini_pfDeepFlavourJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 4 ? allJets[3].bDiscriminator(\'mini_pfDeepFlavourJetTags:probbb\') : -999"),
                name = cms.untracked.string('allJets_3_bDiscriminator_mini_pfDeepFlavourJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 5 ? allJets[4].bDiscriminator(\'mini_pfDeepFlavourJetTags:probbb\') : -999"),
                name = cms.untracked.string('allJets_4_bDiscriminator_mini_pfDeepFlavourJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 1 ? allJets[0].bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('allJets_0_bDiscriminator_pfDeepCSVJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 2 ? allJets[1].bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('allJets_1_bDiscriminator_pfDeepCSVJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 3 ? allJets[2].bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('allJets_2_bDiscriminator_pfDeepCSVJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 4 ? allJets[3].bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('allJets_3_bDiscriminator_pfDeepCSVJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string("? allJets.size() >= 5 ? allJets[4].bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('allJets_4_bDiscriminator_pfDeepCSVJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string('goodElectrons.size()'),
                name = cms.untracked.string('N_goodElectrons')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 1 ? goodElectrons[0].p4().E() : -999'),
                name = cms.untracked.string('goodElectrons_0_E')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 2 ? goodElectrons[1].p4().E() : -999'),
                name = cms.untracked.string('goodElectrons_1_E')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 3 ? goodElectrons[2].p4().E() : -999'),
                name = cms.untracked.string('goodElectrons_2_E')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 4 ? goodElectrons[3].p4().E() : -999'),
                name = cms.untracked.string('goodElectrons_3_E')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 5 ? goodElectrons[4].p4().E() : -999'),
                name = cms.untracked.string('goodElectrons_4_E')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 1 ? goodElectrons[0].p4().pt() : -999'),
                name = cms.untracked.string('goodElectrons_0_pt')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 2 ? goodElectrons[1].p4().pt() : -999'),
                name = cms.untracked.string('goodElectrons_1_pt')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 3 ? goodElectrons[2].p4().pt() : -999'),
                name = cms.untracked.string('goodElectrons_2_pt')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 4 ? goodElectrons[3].p4().pt() : -999'),
                name = cms.untracked.string('goodElectrons_3_pt')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 5 ? goodElectrons[4].p4().pt() : -999'),
                name = cms.untracked.string('goodElectrons_4_pt')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 1 ? goodElectrons[0].p4().px() : -999'),
                name = cms.untracked.string('goodElectrons_0_px')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 2 ? goodElectrons[1].p4().px() : -999'),
                name = cms.untracked.string('goodElectrons_1_px')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 3 ? goodElectrons[2].p4().px() : -999'),
                name = cms.untracked.string('goodElectrons_2_px')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 4 ? goodElectrons[3].p4().px() : -999'),
                name = cms.untracked.string('goodElectrons_3_px')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 5 ? goodElectrons[4].p4().px() : -999'),
                name = cms.untracked.string('goodElectrons_4_px')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 1 ? goodElectrons[0].p4().py() : -999'),
                name = cms.untracked.string('goodElectrons_0_py')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 2 ? goodElectrons[1].p4().py() : -999'),
                name = cms.untracked.string('goodElectrons_1_py')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 3 ? goodElectrons[2].p4().py() : -999'),
                name = cms.untracked.string('goodElectrons_2_py')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 4 ? goodElectrons[3].p4().py() : -999'),
                name = cms.untracked.string('goodElectrons_3_py')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 5 ? goodElectrons[4].p4().py() : -999'),
                name = cms.untracked.string('goodElectrons_4_py')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 1 ? goodElectrons[0].p4().pz() : -999'),
                name = cms.untracked.string('goodElectrons_0_pz')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 2 ? goodElectrons[1].p4().pz() : -999'),
                name = cms.untracked.string('goodElectrons_1_pz')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 3 ? goodElectrons[2].p4().pz() : -999'),
                name = cms.untracked.string('goodElectrons_2_pz')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 4 ? goodElectrons[3].p4().pz() : -999'),
                name = cms.untracked.string('goodElectrons_3_pz')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 5 ? goodElectrons[4].p4().pz() : -999'),
                name = cms.untracked.string('goodElectrons_4_pz')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 1 ? goodElectrons[0].p4().eta() : -999'),
                name = cms.untracked.string('goodElectrons_0_eta')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 2 ? goodElectrons[1].p4().eta() : -999'),
                name = cms.untracked.string('goodElectrons_1_eta')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 3 ? goodElectrons[2].p4().eta() : -999'),
                name = cms.untracked.string('goodElectrons_2_eta')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 4 ? goodElectrons[3].p4().eta() : -999'),
                name = cms.untracked.string('goodElectrons_3_eta')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 5 ? goodElectrons[4].p4().eta() : -999'),
                name = cms.untracked.string('goodElectrons_4_eta')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 1 ? goodElectrons[0].p4().phi() : -999'),
                name = cms.untracked.string('goodElectrons_0_phi')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 2 ? goodElectrons[1].p4().phi() : -999'),
                name = cms.untracked.string('goodElectrons_1_phi')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 3 ? goodElectrons[2].p4().phi() : -999'),
                name = cms.untracked.string('goodElectrons_2_phi')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 4 ? goodElectrons[3].p4().phi() : -999'),
                name = cms.untracked.string('goodElectrons_3_phi')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 5 ? goodElectrons[4].p4().phi() : -999'),
                name = cms.untracked.string('goodElectrons_4_phi')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 1 ? goodElectrons[0].passLooseId() : -999'),
                name = cms.untracked.string('goodElectrons_0_passLooseId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 2 ? goodElectrons[1].passLooseId() : -999'),
                name = cms.untracked.string('goodElectrons_1_passLooseId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 3 ? goodElectrons[2].passLooseId() : -999'),
                name = cms.untracked.string('goodElectrons_2_passLooseId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 4 ? goodElectrons[3].passLooseId() : -999'),
                name = cms.untracked.string('goodElectrons_3_passLooseId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 5 ? goodElectrons[4].passLooseId() : -999'),
                name = cms.untracked.string('goodElectrons_4_passLooseId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 1 ? goodElectrons[0].passMediumId() : -999'),
                name = cms.untracked.string('goodElectrons_0_passMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 2 ? goodElectrons[1].passMediumId() : -999'),
                name = cms.untracked.string('goodElectrons_1_passMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 3 ? goodElectrons[2].passMediumId() : -999'),
                name = cms.untracked.string('goodElectrons_2_passMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 4 ? goodElectrons[3].passMediumId() : -999'),
                name = cms.untracked.string('goodElectrons_3_passMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 5 ? goodElectrons[4].passMediumId() : -999'),
                name = cms.untracked.string('goodElectrons_4_passMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 1 ? goodElectrons[0].passTightId() : -999'),
                name = cms.untracked.string('goodElectrons_0_passTightId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 2 ? goodElectrons[1].passTightId() : -999'),
                name = cms.untracked.string('goodElectrons_1_passTightId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 3 ? goodElectrons[2].passTightId() : -999'),
                name = cms.untracked.string('goodElectrons_2_passTightId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 4 ? goodElectrons[3].passTightId() : -999'),
                name = cms.untracked.string('goodElectrons_3_passTightId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 5 ? goodElectrons[4].passTightId() : -999'),
                name = cms.untracked.string('goodElectrons_4_passTightId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 1 ? goodElectrons[0].passMVALooseId() : -999'),
                name = cms.untracked.string('goodElectrons_0_passMVALooseId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 2 ? goodElectrons[1].passMVALooseId() : -999'),
                name = cms.untracked.string('goodElectrons_1_passMVALooseId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 3 ? goodElectrons[2].passMVALooseId() : -999'),
                name = cms.untracked.string('goodElectrons_2_passMVALooseId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 4 ? goodElectrons[3].passMVALooseId() : -999'),
                name = cms.untracked.string('goodElectrons_3_passMVALooseId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 5 ? goodElectrons[4].passMVALooseId() : -999'),
                name = cms.untracked.string('goodElectrons_4_passMVALooseId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 1 ? goodElectrons[0].passMVAMediumId() : -999'),
                name = cms.untracked.string('goodElectrons_0_passMVAMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 2 ? goodElectrons[1].passMVAMediumId() : -999'),
                name = cms.untracked.string('goodElectrons_1_passMVAMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 3 ? goodElectrons[2].passMVAMediumId() : -999'),
                name = cms.untracked.string('goodElectrons_2_passMVAMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 4 ? goodElectrons[3].passMVAMediumId() : -999'),
                name = cms.untracked.string('goodElectrons_3_passMVAMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 5 ? goodElectrons[4].passMVAMediumId() : -999'),
                name = cms.untracked.string('goodElectrons_4_passMVAMediumId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 1 ? goodElectrons[0].passMVATightId() : -999'),
                name = cms.untracked.string('goodElectrons_0_passMVATightId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 2 ? goodElectrons[1].passMVATightId() : -999'),
                name = cms.untracked.string('goodElectrons_1_passMVATightId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 3 ? goodElectrons[2].passMVATightId() : -999'),
                name = cms.untracked.string('goodElectrons_2_passMVATightId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 4 ? goodElectrons[3].passMVATightId() : -999'),
                name = cms.untracked.string('goodElectrons_3_passMVATightId')
            ), 
            cms.PSet(
                expr = cms.string('? goodElectrons.size() >= 5 ? goodElectrons[4].passMVATightId() : -999'),
                name = cms.untracked.string('goodElectrons_4_passMVATightId')
            ), 
            cms.PSet(
                expr = cms.string('goodMuons.size()'),
                name = cms.untracked.string('N_goodMuons')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 1 ? goodMuons[0].p4().E() : -999'),
                name = cms.untracked.string('goodMuons_0_E')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 2 ? goodMuons[1].p4().E() : -999'),
                name = cms.untracked.string('goodMuons_1_E')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 3 ? goodMuons[2].p4().E() : -999'),
                name = cms.untracked.string('goodMuons_2_E')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 4 ? goodMuons[3].p4().E() : -999'),
                name = cms.untracked.string('goodMuons_3_E')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 5 ? goodMuons[4].p4().E() : -999'),
                name = cms.untracked.string('goodMuons_4_E')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 1 ? goodMuons[0].p4().pt() : -999'),
                name = cms.untracked.string('goodMuons_0_pt')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 2 ? goodMuons[1].p4().pt() : -999'),
                name = cms.untracked.string('goodMuons_1_pt')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 3 ? goodMuons[2].p4().pt() : -999'),
                name = cms.untracked.string('goodMuons_2_pt')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 4 ? goodMuons[3].p4().pt() : -999'),
                name = cms.untracked.string('goodMuons_3_pt')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 5 ? goodMuons[4].p4().pt() : -999'),
                name = cms.untracked.string('goodMuons_4_pt')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 1 ? goodMuons[0].p4().px() : -999'),
                name = cms.untracked.string('goodMuons_0_px')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 2 ? goodMuons[1].p4().px() : -999'),
                name = cms.untracked.string('goodMuons_1_px')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 3 ? goodMuons[2].p4().px() : -999'),
                name = cms.untracked.string('goodMuons_2_px')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 4 ? goodMuons[3].p4().px() : -999'),
                name = cms.untracked.string('goodMuons_3_px')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 5 ? goodMuons[4].p4().px() : -999'),
                name = cms.untracked.string('goodMuons_4_px')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 1 ? goodMuons[0].p4().py() : -999'),
                name = cms.untracked.string('goodMuons_0_py')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 2 ? goodMuons[1].p4().py() : -999'),
                name = cms.untracked.string('goodMuons_1_py')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 3 ? goodMuons[2].p4().py() : -999'),
                name = cms.untracked.string('goodMuons_2_py')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 4 ? goodMuons[3].p4().py() : -999'),
                name = cms.untracked.string('goodMuons_3_py')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 5 ? goodMuons[4].p4().py() : -999'),
                name = cms.untracked.string('goodMuons_4_py')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 1 ? goodMuons[0].p4().pz() : -999'),
                name = cms.untracked.string('goodMuons_0_pz')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 2 ? goodMuons[1].p4().pz() : -999'),
                name = cms.untracked.string('goodMuons_1_pz')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 3 ? goodMuons[2].p4().pz() : -999'),
                name = cms.untracked.string('goodMuons_2_pz')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 4 ? goodMuons[3].p4().pz() : -999'),
                name = cms.untracked.string('goodMuons_3_pz')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 5 ? goodMuons[4].p4().pz() : -999'),
                name = cms.untracked.string('goodMuons_4_pz')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 1 ? goodMuons[0].p4().eta() : -999'),
                name = cms.untracked.string('goodMuons_0_eta')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 2 ? goodMuons[1].p4().eta() : -999'),
                name = cms.untracked.string('goodMuons_1_eta')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 3 ? goodMuons[2].p4().eta() : -999'),
                name = cms.untracked.string('goodMuons_2_eta')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 4 ? goodMuons[3].p4().eta() : -999'),
                name = cms.untracked.string('goodMuons_3_eta')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 5 ? goodMuons[4].p4().eta() : -999'),
                name = cms.untracked.string('goodMuons_4_eta')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 1 ? goodMuons[0].p4().phi() : -999'),
                name = cms.untracked.string('goodMuons_0_phi')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 2 ? goodMuons[1].p4().phi() : -999'),
                name = cms.untracked.string('goodMuons_1_phi')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 3 ? goodMuons[2].p4().phi() : -999'),
                name = cms.untracked.string('goodMuons_2_phi')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 4 ? goodMuons[3].p4().phi() : -999'),
                name = cms.untracked.string('goodMuons_3_phi')
            ), 
            cms.PSet(
                expr = cms.string('? goodMuons.size() >= 5 ? goodMuons[4].p4().phi() : -999'),
                name = cms.untracked.string('goodMuons_4_phi')
            ), 
            cms.PSet(
                expr = cms.string('goodJets.size()'),
                name = cms.untracked.string('N_goodJets')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 1 ? goodJets[0].p4().E() : -999'),
                name = cms.untracked.string('goodJets_0_E')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 2 ? goodJets[1].p4().E() : -999'),
                name = cms.untracked.string('goodJets_1_E')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 3 ? goodJets[2].p4().E() : -999'),
                name = cms.untracked.string('goodJets_2_E')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 4 ? goodJets[3].p4().E() : -999'),
                name = cms.untracked.string('goodJets_3_E')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 5 ? goodJets[4].p4().E() : -999'),
                name = cms.untracked.string('goodJets_4_E')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 1 ? goodJets[0].p4().pt() : -999'),
                name = cms.untracked.string('goodJets_0_pt')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 2 ? goodJets[1].p4().pt() : -999'),
                name = cms.untracked.string('goodJets_1_pt')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 3 ? goodJets[2].p4().pt() : -999'),
                name = cms.untracked.string('goodJets_2_pt')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 4 ? goodJets[3].p4().pt() : -999'),
                name = cms.untracked.string('goodJets_3_pt')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 5 ? goodJets[4].p4().pt() : -999'),
                name = cms.untracked.string('goodJets_4_pt')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 1 ? goodJets[0].p4().px() : -999'),
                name = cms.untracked.string('goodJets_0_px')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 2 ? goodJets[1].p4().px() : -999'),
                name = cms.untracked.string('goodJets_1_px')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 3 ? goodJets[2].p4().px() : -999'),
                name = cms.untracked.string('goodJets_2_px')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 4 ? goodJets[3].p4().px() : -999'),
                name = cms.untracked.string('goodJets_3_px')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 5 ? goodJets[4].p4().px() : -999'),
                name = cms.untracked.string('goodJets_4_px')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 1 ? goodJets[0].p4().py() : -999'),
                name = cms.untracked.string('goodJets_0_py')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 2 ? goodJets[1].p4().py() : -999'),
                name = cms.untracked.string('goodJets_1_py')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 3 ? goodJets[2].p4().py() : -999'),
                name = cms.untracked.string('goodJets_2_py')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 4 ? goodJets[3].p4().py() : -999'),
                name = cms.untracked.string('goodJets_3_py')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 5 ? goodJets[4].p4().py() : -999'),
                name = cms.untracked.string('goodJets_4_py')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 1 ? goodJets[0].p4().pz() : -999'),
                name = cms.untracked.string('goodJets_0_pz')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 2 ? goodJets[1].p4().pz() : -999'),
                name = cms.untracked.string('goodJets_1_pz')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 3 ? goodJets[2].p4().pz() : -999'),
                name = cms.untracked.string('goodJets_2_pz')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 4 ? goodJets[3].p4().pz() : -999'),
                name = cms.untracked.string('goodJets_3_pz')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 5 ? goodJets[4].p4().pz() : -999'),
                name = cms.untracked.string('goodJets_4_pz')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 1 ? goodJets[0].p4().eta() : -999'),
                name = cms.untracked.string('goodJets_0_eta')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 2 ? goodJets[1].p4().eta() : -999'),
                name = cms.untracked.string('goodJets_1_eta')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 3 ? goodJets[2].p4().eta() : -999'),
                name = cms.untracked.string('goodJets_2_eta')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 4 ? goodJets[3].p4().eta() : -999'),
                name = cms.untracked.string('goodJets_3_eta')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 5 ? goodJets[4].p4().eta() : -999'),
                name = cms.untracked.string('goodJets_4_eta')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 1 ? goodJets[0].p4().phi() : -999'),
                name = cms.untracked.string('goodJets_0_phi')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 2 ? goodJets[1].p4().phi() : -999'),
                name = cms.untracked.string('goodJets_1_phi')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 3 ? goodJets[2].p4().phi() : -999'),
                name = cms.untracked.string('goodJets_2_phi')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 4 ? goodJets[3].p4().phi() : -999'),
                name = cms.untracked.string('goodJets_3_phi')
            ), 
            cms.PSet(
                expr = cms.string('? goodJets.size() >= 5 ? goodJets[4].p4().phi() : -999'),
                name = cms.untracked.string('goodJets_4_phi')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 1 ? goodJets[0].bDiscriminator(\'mini_pfDeepFlavourJetTags:probb\') : -999"),
                name = cms.untracked.string('goodJets_0_bDiscriminator_mini_pfDeepFlavourJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 2 ? goodJets[1].bDiscriminator(\'mini_pfDeepFlavourJetTags:probb\') : -999"),
                name = cms.untracked.string('goodJets_1_bDiscriminator_mini_pfDeepFlavourJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 3 ? goodJets[2].bDiscriminator(\'mini_pfDeepFlavourJetTags:probb\') : -999"),
                name = cms.untracked.string('goodJets_2_bDiscriminator_mini_pfDeepFlavourJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 4 ? goodJets[3].bDiscriminator(\'mini_pfDeepFlavourJetTags:probb\') : -999"),
                name = cms.untracked.string('goodJets_3_bDiscriminator_mini_pfDeepFlavourJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 5 ? goodJets[4].bDiscriminator(\'mini_pfDeepFlavourJetTags:probb\') : -999"),
                name = cms.untracked.string('goodJets_4_bDiscriminator_mini_pfDeepFlavourJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 1 ? goodJets[0].bDiscriminator(\'pfDeepCSVJetTags:probb\') : -999"),
                name = cms.untracked.string('goodJets_0_bDiscriminator_pfDeepCSVJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 2 ? goodJets[1].bDiscriminator(\'pfDeepCSVJetTags:probb\') : -999"),
                name = cms.untracked.string('goodJets_1_bDiscriminator_pfDeepCSVJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 3 ? goodJets[2].bDiscriminator(\'pfDeepCSVJetTags:probb\') : -999"),
                name = cms.untracked.string('goodJets_2_bDiscriminator_pfDeepCSVJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 4 ? goodJets[3].bDiscriminator(\'pfDeepCSVJetTags:probb\') : -999"),
                name = cms.untracked.string('goodJets_3_bDiscriminator_pfDeepCSVJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 5 ? goodJets[4].bDiscriminator(\'pfDeepCSVJetTags:probb\') : -999"),
                name = cms.untracked.string('goodJets_4_bDiscriminator_pfDeepCSVJetTags_probb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 1 ? goodJets[0].bDiscriminator(\'mini_pfDeepFlavourJetTags:probbb\') : -999"),
                name = cms.untracked.string('goodJets_0_bDiscriminator_mini_pfDeepFlavourJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 2 ? goodJets[1].bDiscriminator(\'mini_pfDeepFlavourJetTags:probbb\') : -999"),
                name = cms.untracked.string('goodJets_1_bDiscriminator_mini_pfDeepFlavourJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 3 ? goodJets[2].bDiscriminator(\'mini_pfDeepFlavourJetTags:probbb\') : -999"),
                name = cms.untracked.string('goodJets_2_bDiscriminator_mini_pfDeepFlavourJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 4 ? goodJets[3].bDiscriminator(\'mini_pfDeepFlavourJetTags:probbb\') : -999"),
                name = cms.untracked.string('goodJets_3_bDiscriminator_mini_pfDeepFlavourJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 5 ? goodJets[4].bDiscriminator(\'mini_pfDeepFlavourJetTags:probbb\') : -999"),
                name = cms.untracked.string('goodJets_4_bDiscriminator_mini_pfDeepFlavourJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 1 ? goodJets[0].bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('goodJets_0_bDiscriminator_pfDeepCSVJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 2 ? goodJets[1].bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('goodJets_1_bDiscriminator_pfDeepCSVJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 3 ? goodJets[2].bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('goodJets_2_bDiscriminator_pfDeepCSVJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 4 ? goodJets[3].bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('goodJets_3_bDiscriminator_pfDeepCSVJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string("? goodJets.size() >= 5 ? goodJets[4].bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('goodJets_4_bDiscriminator_pfDeepCSVJetTags_probbb')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[0]'),
                name = cms.untracked.string('allJets_0_passLoose')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[1]'),
                name = cms.untracked.string('allJets_0_passTight')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[2]'),
                name = cms.untracked.string('allJets_0_passTight2017')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[3]'),
                name = cms.untracked.string('allJets_0_passTight2018')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[4]'),
                name = cms.untracked.string('allJets_1_passLoose')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[5]'),
                name = cms.untracked.string('allJets_1_passTight')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[6]'),
                name = cms.untracked.string('allJets_1_passTight2017')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[7]'),
                name = cms.untracked.string('allJets_1_passTight2018')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[8]'),
                name = cms.untracked.string('allJets_2_passLoose')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[9]'),
                name = cms.untracked.string('allJets_2_passTight')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[10]'),
                name = cms.untracked.string('allJets_2_passTight2017')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[11]'),
                name = cms.untracked.string('allJets_2_passTight2018')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[12]'),
                name = cms.untracked.string('allJets_3_passLoose')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[13]'),
                name = cms.untracked.string('allJets_3_passTight')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[14]'),
                name = cms.untracked.string('allJets_3_passTight2017')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[15]'),
                name = cms.untracked.string('allJets_3_passTight2018')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[16]'),
                name = cms.untracked.string('allJets_4_passLoose')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[17]'),
                name = cms.untracked.string('allJets_4_passTight')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[18]'),
                name = cms.untracked.string('allJets_4_passTight2017')
            ), 
            cms.PSet(
                expr = cms.string('JetVars[19]'),
                name = cms.untracked.string('allJets_4_passTight2018')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Photon.genMatchType()'),
                name = cms.untracked.string('Leading_Photon_genMatchType')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Photon.genMatchType()'),
                name = cms.untracked.string('Subleading_Photon_genMatchType')
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[0]'),
                name = cms.untracked.string('passPS'),
                nbins = cms.untracked.int32(2),
                vmax = cms.untracked.double(2.0),
                vmin = cms.untracked.double(0.0)
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[1]'),
                name = cms.untracked.string('passPhotonSels'),
                nbins = cms.untracked.int32(2),
                vmax = cms.untracked.double(2.0),
                vmin = cms.untracked.double(0.0)
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[2]'),
                name = cms.untracked.string('passbVeto'),
                nbins = cms.untracked.int32(2),
                vmax = cms.untracked.double(2.0),
                vmin = cms.untracked.double(0.0)
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[3]'),
                name = cms.untracked.string('ExOneLep'),
                nbins = cms.untracked.int32(2),
                vmax = cms.untracked.double(2.0),
                vmin = cms.untracked.double(0.0)
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[4]'),
                name = cms.untracked.string('AtLeast2GoodJets'),
                nbins = cms.untracked.int32(2),
                vmax = cms.untracked.double(2.0),
                vmin = cms.untracked.double(0.0)
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[5]'),
                name = cms.untracked.string('AtLeast4GoodJets'),
                nbins = cms.untracked.int32(2),
                vmax = cms.untracked.double(2.0),
                vmin = cms.untracked.double(0.0)
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[6]'),
                name = cms.untracked.string('AtLeast4GoodJets0Lep'),
                nbins = cms.untracked.int32(2),
                vmax = cms.untracked.double(2.0),
                vmin = cms.untracked.double(0.0)
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[7]'),
                name = cms.untracked.string('mW1_40To160'),
                nbins = cms.untracked.int32(2),
                vmax = cms.untracked.double(2.0),
                vmin = cms.untracked.double(0.0)
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[8]'),
                name = cms.untracked.string('mW1_65To105'),
                nbins = cms.untracked.int32(2),
                vmax = cms.untracked.double(2.0),
                vmin = cms.untracked.double(0.0)
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[9]'),
                name = cms.untracked.string('mW2_0To160'),
                nbins = cms.untracked.int32(2),
                vmax = cms.untracked.double(2.0),
                vmin = cms.untracked.double(0.0)
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[10]'),
                name = cms.untracked.string('mH_105To160'),
                nbins = cms.untracked.int32(2),
                vmax = cms.untracked.double(2.0),
                vmin = cms.untracked.double(0.0)
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[11]'),
                name = cms.untracked.string('mH_40To210'),
                nbins = cms.untracked.int32(2),
                vmax = cms.untracked.double(2.0),
                vmin = cms.untracked.double(0.0)
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[12]'),
                name = cms.untracked.string('AtLeastTwoLeps')
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[13]'),
                name = cms.untracked.string('TwoDiffLeps')
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[14]'),
                name = cms.untracked.string('TwoGoodMuons')
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[15]'),
                name = cms.untracked.string('TwoGoodEles')
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[16]'),
                name = cms.untracked.string('passLepDR')
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[17]'),
                name = cms.untracked.string('passMetPt')
            ), 
            cms.PSet(
                expr = cms.string('Cut_Variables[17]'),
                name = cms.untracked.string('FL_Lep_Flavor')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Photon.p4().pt()'),
                name = cms.untracked.string('lp_pt')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Photon.p4().eta()'),
                name = cms.untracked.string('lp_eta')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Photon.superCluster().eta()'),
                name = cms.untracked.string('lp_SC_eta')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Photon.p4().phi()'),
                name = cms.untracked.string('lp_phi')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Photon.p4().E()'),
                name = cms.untracked.string('lp_E')
            ), 
            cms.PSet(
                expr = cms.string("Leading_Photon.energyAtStep(\'initial\')"),
                name = cms.untracked.string('lp_initE')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Photon.old_r9()'),
                name = cms.untracked.string('lp_r9')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Photon.full5x5_r9()'),
                name = cms.untracked.string('lp_full5x5_r9')
            ), 
            cms.PSet(
                expr = cms.string('lp_Hgg_MVA()'),
                name = cms.untracked.string('lp_Hgg_MVA')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Photon.passElectronVeto()'),
                name = cms.untracked.string('lp_passElectronVeto')
            ), 
            cms.PSet(
                expr = cms.string('Leading_Photon.hasPixelSeed'),
                name = cms.untracked.string('lp_hasPixelSeed')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Photon.p4().pt()'),
                name = cms.untracked.string('slp_pt')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Photon.p4().eta()'),
                name = cms.untracked.string('slp_eta')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Photon.superCluster().eta()'),
                name = cms.untracked.string('slp_SC_eta')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Photon.p4().phi()'),
                name = cms.untracked.string('slp_phi')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Photon.p4().E()'),
                name = cms.untracked.string('slp_E')
            ), 
            cms.PSet(
                expr = cms.string("Subleading_Photon.energyAtStep(\'initial\')"),
                name = cms.untracked.string('slp_initE')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Photon.old_r9()'),
                name = cms.untracked.string('slp_r9')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Photon.full5x5_r9()'),
                name = cms.untracked.string('slp_full5x5_r9')
            ), 
            cms.PSet(
                expr = cms.string('slp_Hgg_MVA()'),
                name = cms.untracked.string('slp_Hgg_MVA')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Photon.passElectronVeto()'),
                name = cms.untracked.string('slp_passElectronVeto')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_Photon.hasPixelSeed'),
                name = cms.untracked.string('slp_hasPixelSeed')
            ), 
            cms.PSet(
                expr = cms.string('Leading_lepton.pt()'),
                name = cms.untracked.string('Leading_lepton_pt')
            ), 
            cms.PSet(
                expr = cms.string('Leading_lepton.eta()'),
                name = cms.untracked.string('Leading_lepton_eta')
            ), 
            cms.PSet(
                expr = cms.string('Leading_lepton.phi()'),
                name = cms.untracked.string('Leading_lepton_phi')
            ), 
            cms.PSet(
                expr = cms.string('Leading_lepton.E()'),
                name = cms.untracked.string('Leading_lepton_E')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_lepton.pt()'),
                name = cms.untracked.string('Subleading_lepton_pt')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_lepton.eta()'),
                name = cms.untracked.string('Subleading_lepton_eta')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_lepton.phi()'),
                name = cms.untracked.string('Subleading_lepton_phi')
            ), 
            cms.PSet(
                expr = cms.string('Subleading_lepton.E()'),
                name = cms.untracked.string('Subleading_lepton_E')
            ), 
            cms.PSet(
                expr = cms.string('MET.pt()'),
                name = cms.untracked.string('Met_pt')
            )
         ) )
    )),
    className = cms.untracked.string('DiPhotonTagDumper'),
    classifierCfg = cms.PSet(
        categories = cms.VPSet(cms.PSet(
            cut = cms.string('hasSyst("") '),
            name = cms.untracked.string('')
        )),
        remap = cms.untracked.VPSet(cms.untracked.PSet(
            dst = cms.untracked.string('HHWWggTag'),
            src = cms.untracked.string('flashggHHWWggTag')
        ))
    ),
    dumpGlobalVariables = cms.untracked.bool(True),
    dumpHistos = cms.untracked.bool(False),
    dumpTrees = cms.untracked.bool(True),
    dumpWorkspace = cms.untracked.bool(False),
    generatorInfo = cms.InputTag("generator"),
    globalVariables = cms.PSet(
        dataPu = cms.vdouble(
            6.245e-06, 2.63e-05, 4.92e-05, 9.084e-05, 9.854e-05, 
            0.0001426, 0.0001557, 0.0001656, 0.0002269, 0.0005395, 
            0.001076, 0.002034, 0.003219, 0.004616, 0.006528, 
            0.009201, 0.01283, 0.01707, 0.02125, 0.0251, 
            0.02847, 0.03118, 0.03325, 0.03486, 0.03626, 
            0.03758, 0.0387, 0.03937, 0.03946, 0.03892, 
            0.03782, 0.03627, 0.03435, 0.03211, 0.02967, 
            0.02719, 0.02482, 0.02264, 0.0207, 0.01907, 
            0.01784, 0.01709, 0.01685, 0.0171, 0.01771, 
            0.01849, 0.01916, 0.01945, 0.01911, 0.01804, 
            0.01627, 0.01399, 0.01147, 0.008976, 0.006728, 
            0.004848, 0.003375, 0.002281, 0.001504, 0.0009715, 
            0.0006178, 0.0003882, 0.0002419, 0.0001501, 9.294e-05, 
            5.768e-05, 3.598e-05, 2.263e-05, 1.437e-05, 9.233e-06, 
            5.996e-06, 3.933e-06, 2.601e-06, 1.731e-06, 1.157e-06, 
            7.743e-07, 5.184e-07, 3.466e-07, 2.311e-07, 1.535e-07, 
            1.015e-07, 6.676e-08, 4.365e-08, 2.836e-08, 1.829e-08, 
            1.171e-08, 7.437e-09, 4.685e-09, 2.926e-09, 1.812e-09, 
            1.111e-09, 6.754e-10, 4.066e-10, 2.424e-10, 1.431e-10, 
            8.363e-11, 4.839e-11, 2.771e-11, 1.571e-11, 8.814e-12
        ),
        extraFloats = cms.PSet(

        ),
        mcPu = cms.vdouble(
            0.0238775, 0.000874622, 0.00124831, 0.00153105, 0.00147725, 
            0.00141303, 0.00126538, 0.00115647, 0.00218504, 0.00171699, 
            0.00229043, 0.00333221, 0.0048993, 0.00663561, 0.00897475, 
            0.011538, 0.0141801, 0.0169121, 0.0192551, 0.0214591, 
            0.0231318, 0.0243014, 0.0251415, 0.0257144, 0.0264036, 
            0.0272533, 0.0279565, 0.028333, 0.0282152, 0.0281867, 
            0.0280371, 0.0282786, 0.0282462, 0.0279432, 0.0276964, 
            0.0270571, 0.0259487, 0.0247456, 0.0239501, 0.0231562, 
            0.0214979, 0.0197288, 0.0179504, 0.0162761, 0.0148308, 
            0.0136544, 0.0125744, 0.0122772, 0.0120571, 0.0118004, 
            0.0120413, 0.0120674, 0.0120442, 0.0120637, 0.0119306, 
            0.0121372, 0.0119726, 0.0117524, 0.0113325, 0.0105063, 
            0.00941031, 0.00811139, 0.00662999, 0.00554745, 0.00434088, 
            0.00362642, 0.00318208, 0.00228125, 0.00171769, 0.00117662, 
            0.000909775, 0.000725548, 0.000478647, 0.000399337, 0.000367371, 
            0.000333013, 0.000231815, 0.000234494, 0.000226693, 0.000381801, 
            0.000485566, 0.000441125, 0.000234348, 0.000323903, 0.000166324, 
            0.000254228, 0.000143739, 0.000292395, 0.000254309, 0.000174261, 
            8.52316e-05, 5.89512e-05, 1.01815e-05, 3.82778e-05, 2.63483e-05, 
            0.000187418, 1.01005e-05, 2.22584e-05, 3.01709e-05, 3.36291e-05
        ),
        puBins = cms.vdouble(
            0.0, 1.0, 2.0, 3.0, 4.0, 
            5.0, 6.0, 7.0, 8.0, 9.0, 
            10.0, 11.0, 12.0, 13.0, 14.0, 
            15.0, 16.0, 17.0, 18.0, 19.0, 
            20.0, 21.0, 22.0, 23.0, 24.0, 
            25.0, 26.0, 27.0, 28.0, 29.0, 
            30.0, 31.0, 32.0, 33.0, 34.0, 
            35.0, 36.0, 37.0, 38.0, 39.0, 
            40.0, 41.0, 42.0, 43.0, 44.0, 
            45.0, 46.0, 47.0, 48.0, 49.0, 
            50.0, 51.0, 52.0, 53.0, 54.0, 
            55.0, 56.0, 57.0, 58.0, 59.0, 
            60.0, 61.0, 62.0, 63.0, 64.0, 
            65.0, 66.0, 67.0, 68.0, 69.0, 
            70.0, 71.0, 72.0, 73.0, 74.0, 
            75.0, 76.0, 77.0, 78.0, 79.0, 
            80.0, 81.0, 82.0, 83.0, 84.0, 
            85.0, 86.0, 87.0, 88.0, 89.0, 
            90.0, 91.0, 92.0, 93.0, 94.0, 
            95.0, 96.0, 97.0, 98.0, 99.0
        ),
        puInfo = cms.InputTag("slimmedAddPileupInfo"),
        puReWeight = cms.bool(True),
        rho = cms.InputTag("fixedGridRhoAll"),
        useTruePu = cms.bool(True),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    intLumi = cms.untracked.double(1000.0),
    lumiWeight = cms.double(1.08733561742e-05),
    maxCandPerEvent = cms.int32(-1),
    nameTemplate = cms.untracked.string('$PROCESS_$SQRTS_$CLASSNAME_$SUBCAT_$LABEL'),
    processId = cms.string('ggF_node8_WWgg_lnulnugg'),
    processIndex = cms.int32(-2147483647),
    quietRooFit = cms.untracked.bool(True),
    reweighGGHforNNLOPS = cms.untracked.bool(False),
    splitPdfByStage0Cat = cms.untracked.bool(False),
    src = cms.InputTag("flashggSystTagMerger"),
    workspaceName = cms.untracked.string('cms_hgg_$SQRTS')
)


process.MessageLogger = cms.Service("MessageLogger",
    FrameworkJobReport = cms.untracked.PSet(
        FwkJob = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000),
            optionalPSet = cms.untracked.bool(True)
        ),
        default = cms.untracked.PSet(
            limit = cms.untracked.int32(0)
        ),
        optionalPSet = cms.untracked.bool(True)
    ),
    categories = cms.untracked.vstring(
        'FwkJob', 
        'FwkReport', 
        'FwkSummary', 
        'Root_NoDictionary'
    ),
    cerr = cms.untracked.PSet(
        FwkJob = cms.untracked.PSet(
            limit = cms.untracked.int32(0),
            optionalPSet = cms.untracked.bool(True)
        ),
        FwkReport = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000),
            optionalPSet = cms.untracked.bool(True),
            reportEvery = cms.untracked.int32(1000000)
        ),
        FwkSummary = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000),
            optionalPSet = cms.untracked.bool(True),
            reportEvery = cms.untracked.int32(1)
        ),
        INFO = cms.untracked.PSet(
            limit = cms.untracked.int32(0)
        ),
        Root_NoDictionary = cms.untracked.PSet(
            limit = cms.untracked.int32(0),
            optionalPSet = cms.untracked.bool(True)
        ),
        default = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000)
        ),
        noTimeStamps = cms.untracked.bool(False),
        optionalPSet = cms.untracked.bool(True),
        threshold = cms.untracked.string('INFO')
    ),
    cerr_stats = cms.untracked.PSet(
        optionalPSet = cms.untracked.bool(True),
        output = cms.untracked.string('cerr'),
        threshold = cms.untracked.string('WARNING')
    ),
    cout = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    ),
    debugModules = cms.untracked.vstring(),
    debugs = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    ),
    default = cms.untracked.PSet(

    ),
    destinations = cms.untracked.vstring(
        'warnings', 
        'errors', 
        'infos', 
        'debugs', 
        'cout', 
        'cerr'
    ),
    errors = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    ),
    fwkJobReports = cms.untracked.vstring('FrameworkJobReport'),
    infos = cms.untracked.PSet(
        Root_NoDictionary = cms.untracked.PSet(
            limit = cms.untracked.int32(0),
            optionalPSet = cms.untracked.bool(True)
        ),
        optionalPSet = cms.untracked.bool(True),
        placeholder = cms.untracked.bool(True)
    ),
    statistics = cms.untracked.vstring('cerr_stats'),
    suppressDebug = cms.untracked.vstring(),
    suppressInfo = cms.untracked.vstring(),
    suppressWarning = cms.untracked.vstring(),
    warnings = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    )
)


process.RandomNumberGeneratorService = cms.Service("RandomNumberGeneratorService",
    flashggDifferentialPhoIdInputsCorrection = cms.PSet(
        initialSeed = cms.untracked.uint32(90)
    )
)


process.TFileService = cms.Service("TFileService",
    fileName = cms.string('HHWWgg_v2-6_Trees_X600_Test/output_GluGluToHHTo_WWgg_lnulnugg_node8.root')
)


process.CSCGeometryESModule = cms.ESProducer("CSCGeometryESModule",
    alignmentsLabel = cms.string(''),
    appendToDataLabel = cms.string(''),
    applyAlignment = cms.bool(True),
    debugV = cms.untracked.bool(False),
    useCentreTIOffsets = cms.bool(False),
    useDDD = cms.bool(False),
    useGangedStripsInME1a = cms.bool(True),
    useOnlyWiresInME1a = cms.bool(False),
    useRealWireGeometry = cms.bool(True)
)


process.CaloGeometryBuilder = cms.ESProducer("CaloGeometryBuilder",
    SelectedCalos = cms.vstring(
        'HCAL', 
        'ZDC', 
        'CASTOR', 
        'EcalBarrel', 
        'EcalEndcap', 
        'EcalPreshower', 
        'TOWER'
    )
)


process.CaloTopologyBuilder = cms.ESProducer("CaloTopologyBuilder")


process.CaloTowerGeometryFromDBEP = cms.ESProducer("CaloTowerGeometryFromDBEP",
    applyAlignment = cms.bool(False)
)


process.CaloTowerTopologyEP = cms.ESProducer("CaloTowerTopologyEP")


process.CastorDbProducer = cms.ESProducer("CastorDbProducer",
    appendToDataLabel = cms.string('')
)


process.CastorGeometryFromDBEP = cms.ESProducer("CastorGeometryFromDBEP",
    applyAlignment = cms.bool(False)
)


process.DTGeometryESModule = cms.ESProducer("DTGeometryESModule",
    alignmentsLabel = cms.string(''),
    appendToDataLabel = cms.string(''),
    applyAlignment = cms.bool(True),
    fromDDD = cms.bool(False)
)


process.EcalBarrelGeometryFromDBEP = cms.ESProducer("EcalBarrelGeometryFromDBEP",
    applyAlignment = cms.bool(True)
)


process.EcalElectronicsMappingBuilder = cms.ESProducer("EcalElectronicsMappingBuilder")


process.EcalEndcapGeometryFromDBEP = cms.ESProducer("EcalEndcapGeometryFromDBEP",
    applyAlignment = cms.bool(True)
)


process.EcalLaserCorrectionService = cms.ESProducer("EcalLaserCorrectionService")


process.EcalPreshowerGeometryFromDBEP = cms.ESProducer("EcalPreshowerGeometryFromDBEP",
    applyAlignment = cms.bool(True)
)


process.EcalTrigTowerConstituentsMapBuilder = cms.ESProducer("EcalTrigTowerConstituentsMapBuilder",
    MapFile = cms.untracked.string('Geometry/EcalMapping/data/EndCap_TTMap.txt')
)


process.GlobalTrackingGeometryESProducer = cms.ESProducer("GlobalTrackingGeometryESProducer")


process.HcalAlignmentEP = cms.ESProducer("HcalAlignmentEP")


process.HcalGeometryFromDBEP = cms.ESProducer("HcalGeometryFromDBEP",
    applyAlignment = cms.bool(True)
)


process.MuonDetLayerGeometryESProducer = cms.ESProducer("MuonDetLayerGeometryESProducer")


process.MuonNumberingInitialization = cms.ESProducer("MuonNumberingInitialization")


process.ParabolicParametrizedMagneticFieldProducer = cms.ESProducer("AutoParametrizedMagneticFieldProducer",
    label = cms.untracked.string('ParabolicMf'),
    valueOverride = cms.int32(-1),
    version = cms.string('Parabolic')
)


process.RPCGeometryESModule = cms.ESProducer("RPCGeometryESModule",
    compatibiltyWith11 = cms.untracked.bool(True),
    useDDD = cms.untracked.bool(False)
)


process.SiStripRecHitMatcherESProducer = cms.ESProducer("SiStripRecHitMatcherESProducer",
    ComponentName = cms.string('StandardMatcher'),
    NSigmaInside = cms.double(3.0),
    PreFilter = cms.bool(False)
)


process.StripCPEfromTrackAngleESProducer = cms.ESProducer("StripCPEESProducer",
    ComponentName = cms.string('StripCPEfromTrackAngle'),
    ComponentType = cms.string('StripCPEfromTrackAngle'),
    parameters = cms.PSet(
        mLC_P0 = cms.double(-0.326),
        mLC_P1 = cms.double(0.618),
        mLC_P2 = cms.double(0.3),
        mTEC_P0 = cms.double(-1.885),
        mTEC_P1 = cms.double(0.471),
        mTIB_P0 = cms.double(-0.742),
        mTIB_P1 = cms.double(0.202),
        mTID_P0 = cms.double(-1.427),
        mTID_P1 = cms.double(0.433),
        mTOB_P0 = cms.double(-1.026),
        mTOB_P1 = cms.double(0.253),
        maxChgOneMIP = cms.double(6000.0),
        useLegacyError = cms.bool(False)
    )
)


process.TrackerRecoGeometryESProducer = cms.ESProducer("TrackerRecoGeometryESProducer")


process.VolumeBasedMagneticFieldESProducer = cms.ESProducer("VolumeBasedMagneticFieldESProducerFromDB",
    debugBuilder = cms.untracked.bool(False),
    label = cms.untracked.string(''),
    valueOverride = cms.int32(-1)
)


process.XMLFromDBSource = cms.ESProducer("XMLIdealGeometryESProducer",
    label = cms.string('Extended'),
    rootDDName = cms.string('cms:OCMS')
)


process.ZdcGeometryFromDBEP = cms.ESProducer("ZdcGeometryFromDBEP",
    applyAlignment = cms.bool(False)
)


process.fakeForIdealAlignment = cms.ESProducer("FakeAlignmentProducer",
    appendToDataLabel = cms.string('fakeForIdeal')
)


process.hcalDDDRecConstants = cms.ESProducer("HcalDDDRecConstantsESModule",
    appendToDataLabel = cms.string('')
)


process.hcalDDDSimConstants = cms.ESProducer("HcalDDDSimConstantsESModule",
    appendToDataLabel = cms.string('')
)


process.hcalTopologyIdeal = cms.ESProducer("HcalTopologyIdealEP",
    Exclude = cms.untracked.string(''),
    MergePosition = cms.untracked.bool(False),
    appendToDataLabel = cms.string('')
)


process.hcal_db_producer = cms.ESProducer("HcalDbProducer",
    dump = cms.untracked.vstring(''),
    file = cms.untracked.string('')
)


process.idealForDigiCSCGeometry = cms.ESProducer("CSCGeometryESModule",
    alignmentsLabel = cms.string('fakeForIdeal'),
    appendToDataLabel = cms.string('idealForDigi'),
    applyAlignment = cms.bool(False),
    debugV = cms.untracked.bool(False),
    useCentreTIOffsets = cms.bool(False),
    useDDD = cms.bool(False),
    useGangedStripsInME1a = cms.bool(True),
    useOnlyWiresInME1a = cms.bool(False),
    useRealWireGeometry = cms.bool(True)
)


process.idealForDigiDTGeometry = cms.ESProducer("DTGeometryESModule",
    alignmentsLabel = cms.string('fakeForIdeal'),
    appendToDataLabel = cms.string('idealForDigi'),
    applyAlignment = cms.bool(False),
    fromDDD = cms.bool(False)
)


process.idealForDigiTrackerGeometry = cms.ESProducer("TrackerDigiGeometryESModule",
    alignmentsLabel = cms.string('fakeForIdeal'),
    appendToDataLabel = cms.string('idealForDigi'),
    applyAlignment = cms.bool(False),
    fromDDD = cms.bool(False)
)


process.siPixelQualityESProducer = cms.ESProducer("SiPixelQualityESProducer",
    ListOfRecordToMerge = cms.VPSet(
        cms.PSet(
            record = cms.string('SiPixelQualityFromDbRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiPixelDetVOffRcd'),
            tag = cms.string('')
        )
    ),
    siPixelQualityLabel = cms.string('')
)


process.siStripBackPlaneCorrectionDepESProducer = cms.ESProducer("SiStripBackPlaneCorrectionDepESProducer",
    BackPlaneCorrectionDeconvMode = cms.PSet(
        label = cms.untracked.string('deconvolution'),
        record = cms.string('SiStripBackPlaneCorrectionRcd')
    ),
    BackPlaneCorrectionPeakMode = cms.PSet(
        label = cms.untracked.string('peak'),
        record = cms.string('SiStripBackPlaneCorrectionRcd')
    ),
    LatencyRecord = cms.PSet(
        label = cms.untracked.string(''),
        record = cms.string('SiStripLatencyRcd')
    )
)


process.siStripGainESProducer = cms.ESProducer("SiStripGainESProducer",
    APVGain = cms.VPSet(
        cms.PSet(
            Label = cms.untracked.string(''),
            NormalizationFactor = cms.untracked.double(1.0),
            Record = cms.string('SiStripApvGainRcd')
        ), 
        cms.PSet(
            Label = cms.untracked.string(''),
            NormalizationFactor = cms.untracked.double(1.0),
            Record = cms.string('SiStripApvGain2Rcd')
        )
    ),
    AutomaticNormalization = cms.bool(False),
    appendToDataLabel = cms.string(''),
    printDebug = cms.untracked.bool(False)
)


process.siStripLorentzAngleDepESProducer = cms.ESProducer("SiStripLorentzAngleDepESProducer",
    LatencyRecord = cms.PSet(
        label = cms.untracked.string(''),
        record = cms.string('SiStripLatencyRcd')
    ),
    LorentzAngleDeconvMode = cms.PSet(
        label = cms.untracked.string('deconvolution'),
        record = cms.string('SiStripLorentzAngleRcd')
    ),
    LorentzAnglePeakMode = cms.PSet(
        label = cms.untracked.string('peak'),
        record = cms.string('SiStripLorentzAngleRcd')
    )
)


process.siStripQualityESProducer = cms.ESProducer("SiStripQualityESProducer",
    ListOfRecordToMerge = cms.VPSet(
        cms.PSet(
            record = cms.string('SiStripDetVOffRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripDetCablingRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('RunInfoRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadChannelRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadFiberRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadModuleRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadStripRcd'),
            tag = cms.string('')
        )
    ),
    PrintDebugOutput = cms.bool(False),
    ReduceGranularity = cms.bool(False),
    ThresholdForReducedGranularity = cms.double(0.3),
    UseEmptyRunInfo = cms.bool(False),
    appendToDataLabel = cms.string('')
)


process.sistripconn = cms.ESProducer("SiStripConnectivity")


process.stripCPEESProducer = cms.ESProducer("StripCPEESProducer",
    ComponentName = cms.string('stripCPE'),
    ComponentType = cms.string('SimpleStripCPE'),
    parameters = cms.PSet(

    )
)


process.trackerGeometryDB = cms.ESProducer("TrackerDigiGeometryESModule",
    alignmentsLabel = cms.string(''),
    appendToDataLabel = cms.string(''),
    applyAlignment = cms.bool(True),
    fromDDD = cms.bool(False)
)


process.trackerNumberingGeometryDB = cms.ESProducer("TrackerGeometricDetESModule",
    appendToDataLabel = cms.string(''),
    fromDDD = cms.bool(False)
)


process.trackerTopology = cms.ESProducer("TrackerTopologyEP",
    appendToDataLabel = cms.string('')
)


process.GlobalTag = cms.ESSource("PoolDBESSource",
    DBParameters = cms.PSet(
        authenticationPath = cms.untracked.string(''),
        authenticationSystem = cms.untracked.int32(0),
        messageLevel = cms.untracked.int32(0),
        security = cms.untracked.string('')
    ),
    DumpStat = cms.untracked.bool(False),
    ReconnectEachRun = cms.untracked.bool(False),
    RefreshAlways = cms.untracked.bool(False),
    RefreshEachRun = cms.untracked.bool(False),
    RefreshOpenIOVs = cms.untracked.bool(False),
    connect = cms.string('frontier://FrontierProd/CMS_CONDITIONS'),
    globaltag = cms.string('94X_mc2017_realistic_v17'),
    pfnPostfix = cms.untracked.string(''),
    pfnPrefix = cms.untracked.string(''),
    snapshotTime = cms.string(''),
    toGet = cms.VPSet()
)


process.HcalTimeSlewEP = cms.ESSource("HcalTimeSlewEP",
    appendToDataLabel = cms.string('HBHE'),
    timeSlewParametersM2 = cms.VPSet(
        cms.PSet(
            slope = cms.double(-3.178648),
            tmax = cms.double(16.0),
            tzero = cms.double(23.960177)
        ), 
        cms.PSet(
            slope = cms.double(-1.5610227),
            tmax = cms.double(10.0),
            tzero = cms.double(11.977461)
        ), 
        cms.PSet(
            slope = cms.double(-1.075824),
            tmax = cms.double(6.25),
            tzero = cms.double(9.109694)
        )
    ),
    timeSlewParametersM3 = cms.VPSet(
        cms.PSet(
            cap = cms.double(6.0),
            tspar0 = cms.double(12.2999),
            tspar0_siPM = cms.double(0.0),
            tspar1 = cms.double(-2.19142),
            tspar1_siPM = cms.double(0.0),
            tspar2 = cms.double(0.0),
            tspar2_siPM = cms.double(0.0)
        ), 
        cms.PSet(
            cap = cms.double(6.0),
            tspar0 = cms.double(15.5),
            tspar0_siPM = cms.double(0.0),
            tspar1 = cms.double(-3.2),
            tspar1_siPM = cms.double(0.0),
            tspar2 = cms.double(32.0),
            tspar2_siPM = cms.double(0.0)
        ), 
        cms.PSet(
            cap = cms.double(6.0),
            tspar0 = cms.double(12.2999),
            tspar0_siPM = cms.double(0.0),
            tspar1 = cms.double(-2.19142),
            tspar1_siPM = cms.double(0.0),
            tspar2 = cms.double(0.0),
            tspar2_siPM = cms.double(0.0)
        ), 
        cms.PSet(
            cap = cms.double(6.0),
            tspar0 = cms.double(12.2999),
            tspar0_siPM = cms.double(0.0),
            tspar1 = cms.double(-2.19142),
            tspar1_siPM = cms.double(0.0),
            tspar2 = cms.double(0.0),
            tspar2_siPM = cms.double(0.0)
        )
    )
)


process.eegeom = cms.ESSource("EmptyESSource",
    firstValid = cms.vuint32(1),
    iovIsRunNotTime = cms.bool(True),
    recordName = cms.string('EcalMappingRcd')
)


process.es_hardcode = cms.ESSource("HcalHardcodeCalibrations",
    GainWidthsForTrigPrims = cms.bool(False),
    HBRecalibration = cms.bool(False),
    HBmeanenergies = cms.FileInPath('CalibCalorimetry/HcalPlugins/data/meanenergiesHB.txt'),
    HBreCalibCutoff = cms.double(20.0),
    HERecalibration = cms.bool(False),
    HEmeanenergies = cms.FileInPath('CalibCalorimetry/HcalPlugins/data/meanenergiesHE.txt'),
    HEreCalibCutoff = cms.double(20.0),
    HFRecalParameterBlock = cms.PSet(
        HFdepthOneParameterA = cms.vdouble(
            0.004123, 0.00602, 0.008201, 0.010489, 0.013379, 
            0.016997, 0.021464, 0.027371, 0.034195, 0.044807, 
            0.058939, 0.125497
        ),
        HFdepthOneParameterB = cms.vdouble(
            -4e-06, -2e-06, 0.0, 4e-06, 1.5e-05, 
            2.6e-05, 6.3e-05, 8.4e-05, 0.00016, 0.000107, 
            0.000425, 0.000209
        ),
        HFdepthTwoParameterA = cms.vdouble(
            0.002861, 0.004168, 0.0064, 0.008388, 0.011601, 
            0.014425, 0.018633, 0.023232, 0.028274, 0.035447, 
            0.051579, 0.086593
        ),
        HFdepthTwoParameterB = cms.vdouble(
            -2e-06, -0.0, -7e-06, -6e-06, -2e-06, 
            1e-06, 1.9e-05, 3.1e-05, 6.7e-05, 1.2e-05, 
            0.000157, -3e-06
        )
    ),
    HFRecalibration = cms.bool(False),
    SiPMCharacteristics = cms.VPSet(
        cms.PSet(
            crosstalk = cms.double(0.0),
            nonlin1 = cms.double(1.0),
            nonlin2 = cms.double(0.0),
            nonlin3 = cms.double(0.0),
            pixels = cms.int32(36000)
        ), 
        cms.PSet(
            crosstalk = cms.double(0.0),
            nonlin1 = cms.double(1.0),
            nonlin2 = cms.double(0.0),
            nonlin3 = cms.double(0.0),
            pixels = cms.int32(2500)
        ), 
        cms.PSet(
            crosstalk = cms.double(0.17),
            nonlin1 = cms.double(1.00985),
            nonlin2 = cms.double(7.84089e-06),
            nonlin3 = cms.double(2.86282e-10),
            pixels = cms.int32(27370)
        ), 
        cms.PSet(
            crosstalk = cms.double(0.196),
            nonlin1 = cms.double(1.00546),
            nonlin2 = cms.double(6.40239e-06),
            nonlin3 = cms.double(1.27011e-10),
            pixels = cms.int32(38018)
        ), 
        cms.PSet(
            crosstalk = cms.double(0.17),
            nonlin1 = cms.double(1.00985),
            nonlin2 = cms.double(7.84089e-06),
            nonlin3 = cms.double(2.86282e-10),
            pixels = cms.int32(27370)
        ), 
        cms.PSet(
            crosstalk = cms.double(0.196),
            nonlin1 = cms.double(1.00546),
            nonlin2 = cms.double(6.40239e-06),
            nonlin3 = cms.double(1.27011e-10),
            pixels = cms.int32(38018)
        ), 
        cms.PSet(
            crosstalk = cms.double(0.0),
            nonlin1 = cms.double(1.0),
            nonlin2 = cms.double(0.0),
            nonlin3 = cms.double(0.0),
            pixels = cms.int32(0)
        )
    ),
    hb = cms.PSet(
        darkCurrent = cms.vdouble(0.0),
        doRadiationDamage = cms.bool(False),
        gain = cms.vdouble(0.19),
        gainWidth = cms.vdouble(0.0),
        mcShape = cms.int32(125),
        pedestal = cms.double(3.285),
        pedestalWidth = cms.double(0.809),
        photoelectronsToAnalog = cms.double(0.3305),
        qieOffset = cms.vdouble(-0.49, 1.8, 7.2, 37.9),
        qieSlope = cms.vdouble(0.912, 0.917, 0.922, 0.923),
        qieType = cms.int32(0),
        recoShape = cms.int32(105),
        zsThreshold = cms.int32(8)
    ),
    hbUpgrade = cms.PSet(
        darkCurrent = cms.vdouble(0.01, 0.015),
        doRadiationDamage = cms.bool(True),
        gain = cms.vdouble(0.0006252),
        gainWidth = cms.vdouble(0),
        mcShape = cms.int32(206),
        pedestal = cms.double(17.3),
        pedestalWidth = cms.double(1.5),
        photoelectronsToAnalog = cms.double(40.0),
        qieOffset = cms.vdouble(0.0, 0.0, 0.0, 0.0),
        qieSlope = cms.vdouble(0.05376, 0.05376, 0.05376, 0.05376),
        qieType = cms.int32(2),
        radiationDamage = cms.PSet(
            depVsNeutrons = cms.vdouble(5.543e-10, 8.012e-10),
            depVsTemp = cms.double(0.0631),
            intlumiOffset = cms.double(150),
            intlumiToNeutrons = cms.double(367000000.0),
            temperatureBase = cms.double(20),
            temperatureNew = cms.double(-5)
        ),
        recoShape = cms.int32(206),
        zsThreshold = cms.int32(16)
    ),
    he = cms.PSet(
        darkCurrent = cms.vdouble(0.0),
        doRadiationDamage = cms.bool(False),
        gain = cms.vdouble(0.23),
        gainWidth = cms.vdouble(0),
        mcShape = cms.int32(125),
        pedestal = cms.double(3.163),
        pedestalWidth = cms.double(0.9698),
        photoelectronsToAnalog = cms.double(0.3305),
        qieOffset = cms.vdouble(-0.38, 2.0, 7.6, 39.6),
        qieSlope = cms.vdouble(0.912, 0.916, 0.92, 0.922),
        qieType = cms.int32(0),
        recoShape = cms.int32(105),
        zsThreshold = cms.int32(9)
    ),
    heUpgrade = cms.PSet(
        darkCurrent = cms.vdouble(0.01, 0.015),
        doRadiationDamage = cms.bool(True),
        gain = cms.vdouble(0.0006252),
        gainWidth = cms.vdouble(0),
        mcShape = cms.int32(206),
        pedestal = cms.double(17.3),
        pedestalWidth = cms.double(1.5),
        photoelectronsToAnalog = cms.double(40.0),
        qieOffset = cms.vdouble(0.0, 0.0, 0.0, 0.0),
        qieSlope = cms.vdouble(0.05376, 0.05376, 0.05376, 0.05376),
        qieType = cms.int32(2),
        radiationDamage = cms.PSet(
            depVsNeutrons = cms.vdouble(5.543e-10, 8.012e-10),
            depVsTemp = cms.double(0.0631),
            intlumiOffset = cms.double(75),
            intlumiToNeutrons = cms.double(29200000.0),
            temperatureBase = cms.double(20),
            temperatureNew = cms.double(5)
        ),
        recoShape = cms.int32(206),
        zsThreshold = cms.int32(16)
    ),
    hf = cms.PSet(
        darkCurrent = cms.vdouble(0.0),
        doRadiationDamage = cms.bool(False),
        gain = cms.vdouble(0.14, 0.135),
        gainWidth = cms.vdouble(0.0, 0.0),
        mcShape = cms.int32(301),
        pedestal = cms.double(9.354),
        pedestalWidth = cms.double(2.516),
        photoelectronsToAnalog = cms.double(0.0),
        qieOffset = cms.vdouble(-0.87, 1.4, 7.8, -29.6),
        qieSlope = cms.vdouble(0.359, 0.358, 0.36, 0.367),
        qieType = cms.int32(0),
        recoShape = cms.int32(301),
        zsThreshold = cms.int32(-9999)
    ),
    hfUpgrade = cms.PSet(
        darkCurrent = cms.vdouble(0.0),
        doRadiationDamage = cms.bool(False),
        gain = cms.vdouble(0.14, 0.135),
        gainWidth = cms.vdouble(0.0, 0.0),
        mcShape = cms.int32(301),
        pedestal = cms.double(13.33),
        pedestalWidth = cms.double(3.33),
        photoelectronsToAnalog = cms.double(0.0),
        qieOffset = cms.vdouble(0.0697, -0.7405, 12.38, -671.9),
        qieSlope = cms.vdouble(0.297, 0.298, 0.298, 0.313),
        qieType = cms.int32(1),
        recoShape = cms.int32(301),
        zsThreshold = cms.int32(-9999)
    ),
    ho = cms.PSet(
        darkCurrent = cms.vdouble(0.0),
        doRadiationDamage = cms.bool(False),
        gain = cms.vdouble(0.006, 0.0087),
        gainWidth = cms.vdouble(0.0, 0.0),
        mcShape = cms.int32(201),
        pedestal = cms.double(12.06),
        pedestalWidth = cms.double(0.6285),
        photoelectronsToAnalog = cms.double(4.0),
        qieOffset = cms.vdouble(-0.44, 1.4, 7.1, 38.5),
        qieSlope = cms.vdouble(0.907, 0.915, 0.92, 0.921),
        qieType = cms.int32(0),
        recoShape = cms.int32(201),
        zsThreshold = cms.int32(24)
    ),
    iLumi = cms.double(-1.0),
    killHE = cms.bool(False),
    testHEPlan1 = cms.bool(False),
    testHFQIE10 = cms.bool(False),
    toGet = cms.untracked.vstring('GainWidths'),
    useHBUpgrade = cms.bool(False),
    useHEUpgrade = cms.bool(False),
    useHFUpgrade = cms.bool(False),
    useHOUpgrade = cms.bool(True),
    useIeta18depth1 = cms.bool(True),
    useLayer0Weight = cms.bool(False)
)


process.jec = cms.ESSource("PoolDBESSource",
    DBParameters = cms.PSet(
        messageLevel = cms.untracked.int32(0)
    ),
    connect = cms.string('frontier://FrontierProd/CMS_CONDITIONS'),
    timetype = cms.string('runnumber'),
    toGet = cms.VPSet(cms.PSet(
        label = cms.untracked.string('AK4PFchs'),
        record = cms.string('JetCorrectionsRecord'),
        tag = cms.string('JetCorrectorParametersCollection_Fall17_17Nov2017_V32_102X_MC_AK4PFchs')
    ))
)


process.prefer("es_hardcode")

process.prefer("jec")

process.ak4CaloL2L3ResidualCorrectorTask = cms.Task(process.ak4CaloL2L3ResidualCorrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector, process.ak4CaloResidualCorrector)


process.ak4PFCHSL2L3ResidualCorrectorTask = cms.Task(process.ak4PFCHSL2L3ResidualCorrector, process.ak4PFCHSL2RelativeCorrector, process.ak4PFCHSL3AbsoluteCorrector, process.ak4PFCHSResidualCorrector)


process.ak4CaloL1L2L3ResidualCorrectorTask = cms.Task(process.ak4CaloL1L2L3ResidualCorrector, process.ak4CaloL1OffsetCorrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector, process.ak4CaloResidualCorrector)


process.ak4PFPuppiL1L2L3ResidualCorrectorTask = cms.Task(process.ak4PFPuppiL1L2L3ResidualCorrector, process.ak4PFPuppiL1OffsetCorrector, process.ak4PFPuppiL2RelativeCorrector, process.ak4PFPuppiL3AbsoluteCorrector, process.ak4PFPuppiResidualCorrector)


process.ak4L1JPTOffsetCorrectorTask = cms.Task(process.ak4CaloL1OffsetCorrector, process.ak4L1JPTOffsetCorrector)


process.ak4JPTL1L2L3ResidualCorrectorTask = cms.Task(process.ak4JPTL1L2L3ResidualCorrector, process.ak4JPTL2RelativeCorrector, process.ak4JPTL3AbsoluteCorrector, process.ak4JPTResidualCorrector, process.ak4L1JPTOffsetCorrectorTask)


process.ak4PFL1L2L3CorrectorTask = cms.Task(process.ak4PFL1L2L3Corrector, process.ak4PFL1OffsetCorrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector)


process.ak4CaloL1L2L3CorrectorTask = cms.Task(process.ak4CaloL1L2L3Corrector, process.ak4CaloL1OffsetCorrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector)


process.ak4CaloL1FastL2L3CorrectorTask = cms.Task(process.ak4CaloL1FastL2L3Corrector, process.ak4CaloL1FastjetCorrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector)


process.ak4PFPuppiL1FastL2L3ResidualCorrectorTask = cms.Task(process.ak4PFPuppiL1FastL2L3ResidualCorrector, process.ak4PFPuppiL1FastjetCorrector, process.ak4PFPuppiL2RelativeCorrector, process.ak4PFPuppiL3AbsoluteCorrector, process.ak4PFPuppiResidualCorrector)


process.ak4CaloL2L3L6CorrectorTask = cms.Task(process.ak4CaloL2L3L6Corrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector, process.ak4CaloL6SLBCorrector)


process.ak4L1JPTFastjetCorrectorTask = cms.Task(process.ak4CaloL1FastjetCorrector, process.ak4L1JPTFastjetCorrector)


process.ak4PFL1FastL2L3CorrectorTask = cms.Task(process.ak4PFL1FastL2L3Corrector, process.ak4PFL1FastjetCorrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector)


process.ak4TrackL2L3CorrectorTask = cms.Task(process.ak4TrackL2L3Corrector, process.ak4TrackL2RelativeCorrector, process.ak4TrackL3AbsoluteCorrector)


process.ak4PFL2L3L6CorrectorTask = cms.Task(process.ak4PFL2L3L6Corrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector, process.ak4PFL6SLBCorrector)


process.ak4JPTL2L3ResidualCorrectorTask = cms.Task(process.ak4JPTL2L3ResidualCorrector, process.ak4JPTL2RelativeCorrector, process.ak4JPTL3AbsoluteCorrector, process.ak4JPTResidualCorrector, process.ak4L1JPTOffsetCorrectorTask)


process.ak4JPTL2L3CorrectorTask = cms.Task(process.ak4JPTL2L3Corrector, process.ak4JPTL2RelativeCorrector, process.ak4JPTL3AbsoluteCorrector, process.ak4L1JPTOffsetCorrectorTask)


process.ak4PFPuppiL1FastL2L3CorrectorTask = cms.Task(process.ak4PFPuppiL1FastL2L3Corrector, process.ak4PFPuppiL1FastjetCorrector, process.ak4PFPuppiL2RelativeCorrector, process.ak4PFPuppiL3AbsoluteCorrector)


process.ak4PFPuppiL1L2L3CorrectorTask = cms.Task(process.ak4PFPuppiL1L2L3Corrector, process.ak4PFPuppiL1OffsetCorrector, process.ak4PFPuppiL2RelativeCorrector, process.ak4PFPuppiL3AbsoluteCorrector)


process.ak4PFL1FastL2L3ResidualCorrectorTask = cms.Task(process.ak4PFL1FastL2L3ResidualCorrector, process.ak4PFL1FastjetCorrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector, process.ak4PFResidualCorrector)


process.ak4CaloL1FastL2L3ResidualCorrectorTask = cms.Task(process.ak4CaloL1FastL2L3ResidualCorrector, process.ak4CaloL1FastjetCorrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector, process.ak4CaloResidualCorrector)


process.ak4PFCHSL1FastL2L3CorrectorTask = cms.Task(process.ak4PFCHSL1FastL2L3Corrector, process.ak4PFCHSL1FastjetCorrector, process.ak4PFCHSL2RelativeCorrector, process.ak4PFCHSL3AbsoluteCorrector)


process.ak4PFL1L2L3ResidualCorrectorTask = cms.Task(process.ak4PFL1L2L3ResidualCorrector, process.ak4PFL1OffsetCorrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector, process.ak4PFResidualCorrector)


process.ak4PFL2L3ResidualCorrectorTask = cms.Task(process.ak4PFL2L3ResidualCorrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector, process.ak4PFResidualCorrector)


process.ak4JPTL1L2L3CorrectorTask = cms.Task(process.ak4JPTL1L2L3Corrector, process.ak4JPTL2RelativeCorrector, process.ak4JPTL3AbsoluteCorrector, process.ak4L1JPTOffsetCorrectorTask)


process.ak4PFCHSL2L3CorrectorTask = cms.Task(process.ak4PFCHSL2L3Corrector, process.ak4PFCHSL2RelativeCorrector, process.ak4PFCHSL3AbsoluteCorrector)


process.ak4CaloL2L3CorrectorTask = cms.Task(process.ak4CaloL2L3Corrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector)


process.ak4PFL1FastL2L3L6CorrectorTask = cms.Task(process.ak4PFL1FastL2L3L6Corrector, process.ak4PFL1FastjetCorrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector, process.ak4PFL6SLBCorrector)


process.ak4PFCHSL1L2L3CorrectorTask = cms.Task(process.ak4PFCHSL1L2L3Corrector, process.ak4PFCHSL1OffsetCorrector, process.ak4PFCHSL2RelativeCorrector, process.ak4PFCHSL3AbsoluteCorrector)


process.ak4PFCHSL1L2L3ResidualCorrectorTask = cms.Task(process.ak4PFCHSL1L2L3ResidualCorrector, process.ak4PFCHSL1OffsetCorrector, process.ak4PFCHSL2RelativeCorrector, process.ak4PFCHSL3AbsoluteCorrector, process.ak4PFCHSResidualCorrector)


process.ak4PFPuppiL2L3ResidualCorrectorTask = cms.Task(process.ak4PFPuppiL2L3ResidualCorrector, process.ak4PFPuppiL2RelativeCorrector, process.ak4PFPuppiL3AbsoluteCorrector, process.ak4PFPuppiResidualCorrector)


process.ak4PFPuppiL2L3CorrectorTask = cms.Task(process.ak4PFPuppiL2L3Corrector, process.ak4PFPuppiL2RelativeCorrector, process.ak4PFPuppiL3AbsoluteCorrector)


process.ak4JPTL1FastL2L3CorrectorTask = cms.Task(process.ak4JPTL1FastL2L3Corrector, process.ak4JPTL2RelativeCorrector, process.ak4JPTL3AbsoluteCorrector, process.ak4L1JPTFastjetCorrectorTask)


process.ak4PFCHSL1FastL2L3ResidualCorrectorTask = cms.Task(process.ak4PFCHSL1FastL2L3ResidualCorrector, process.ak4PFCHSL1FastjetCorrector, process.ak4PFCHSL2RelativeCorrector, process.ak4PFCHSL3AbsoluteCorrector, process.ak4PFCHSResidualCorrector)


process.ak4PFL2L3CorrectorTask = cms.Task(process.ak4PFL2L3Corrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector)


process.ak4CaloL1FastL2L3L6CorrectorTask = cms.Task(process.ak4CaloL1FastL2L3L6Corrector, process.ak4CaloL1FastjetCorrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector, process.ak4CaloL6SLBCorrector)


process.ak4JPTL1FastL2L3ResidualCorrectorTask = cms.Task(process.ak4JPTL1FastL2L3ResidualCorrector, process.ak4JPTL2RelativeCorrector, process.ak4JPTL3AbsoluteCorrector, process.ak4JPTResidualCorrector, process.ak4L1JPTFastjetCorrectorTask)


process.jetCorrectorsTask = cms.Task(process.ak4CaloL1FastL2L3CorrectorTask, process.ak4CaloL1FastL2L3L6CorrectorTask, process.ak4CaloL1FastL2L3ResidualCorrectorTask, process.ak4CaloL1L2L3CorrectorTask, process.ak4CaloL1L2L3ResidualCorrectorTask, process.ak4CaloL2L3CorrectorTask, process.ak4CaloL2L3L6CorrectorTask, process.ak4CaloL2L3ResidualCorrectorTask, process.ak4JPTL1FastL2L3CorrectorTask, process.ak4JPTL1FastL2L3ResidualCorrectorTask, process.ak4JPTL1L2L3CorrectorTask, process.ak4JPTL1L2L3ResidualCorrectorTask, process.ak4JPTL2L3CorrectorTask, process.ak4JPTL2L3ResidualCorrectorTask, process.ak4L1JPTFastjetCorrectorTask, process.ak4L1JPTOffsetCorrectorTask, process.ak4PFCHSL1FastL2L3CorrectorTask, process.ak4PFCHSL1FastL2L3ResidualCorrectorTask, process.ak4PFCHSL1L2L3CorrectorTask, process.ak4PFCHSL1L2L3ResidualCorrectorTask, process.ak4PFCHSL2L3CorrectorTask, process.ak4PFCHSL2L3ResidualCorrectorTask, process.ak4PFL1FastL2L3CorrectorTask, process.ak4PFL1FastL2L3L6CorrectorTask, process.ak4PFL1FastL2L3ResidualCorrectorTask, process.ak4PFL1L2L3CorrectorTask, process.ak4PFL1L2L3ResidualCorrectorTask, process.ak4PFL2L3CorrectorTask, process.ak4PFL2L3L6CorrectorTask, process.ak4PFL2L3ResidualCorrectorTask, process.ak4PFPuppiL1FastL2L3CorrectorTask, process.ak4PFPuppiL1FastL2L3ResidualCorrectorTask, process.ak4PFPuppiL1L2L3CorrectorTask, process.ak4PFPuppiL1L2L3ResidualCorrectorTask, process.ak4PFPuppiL2L3CorrectorTask, process.ak4PFPuppiL2L3ResidualCorrectorTask, process.ak4TrackL2L3CorrectorTask)


process.ak4JPTL2L3ResidualCorrectorChain = cms.Sequence(process.ak4JPTL2L3ResidualCorrectorTask)


process.ak4PFL1FastL2L3L6CorrectorChain = cms.Sequence(process.ak4PFL1FastL2L3L6CorrectorTask)


process.ak4L1JPTOffsetCorrectorChain = cms.Sequence(process.ak4L1JPTOffsetCorrectorTask)


process.ak4TrackL2L3CorrectorChain = cms.Sequence(process.ak4TrackL2L3CorrectorTask)


process.ak4PFPuppiL2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFPuppiL2L3ResidualCorrectorTask)


process.ak4JPTL1FastL2L3ResidualCorrectorChain = cms.Sequence(process.ak4JPTL1FastL2L3ResidualCorrectorTask)


process.ak4PFL2L3L6CorrectorChain = cms.Sequence(process.ak4PFL2L3L6CorrectorTask)


process.ak4PFL1L2L3CorrectorChain = cms.Sequence(process.ak4PFL1L2L3CorrectorTask)


process.ak4PFCHSL1FastL2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFCHSL1FastL2L3ResidualCorrectorTask)


process.ak4PFCHSL1FastL2L3CorrectorChain = cms.Sequence(process.ak4PFCHSL1FastL2L3CorrectorTask)


process.ak4CaloL1L2L3CorrectorChain = cms.Sequence(process.ak4CaloL1L2L3CorrectorTask)


process.finalFilter = cms.Sequence()


process.ak4PFCHSL1L2L3CorrectorChain = cms.Sequence(process.ak4PFCHSL1L2L3CorrectorTask)


process.genFilter = cms.Sequence()


process.ak4CaloL1FastL2L3ResidualCorrectorChain = cms.Sequence(process.ak4CaloL1FastL2L3ResidualCorrectorTask)


process.ak4PFL1FastL2L3CorrectorChain = cms.Sequence(process.ak4PFL1FastL2L3CorrectorTask)


process.jetCorrectorChain = cms.Sequence(process.ak4PFCHSL1FastL2L3CorrectorChain)


process.ak4CaloL2L3L6CorrectorChain = cms.Sequence(process.ak4CaloL2L3L6CorrectorTask)


process.penultimateFilter = cms.Sequence()


process.ak4JPTL2L3CorrectorChain = cms.Sequence(process.ak4JPTL2L3CorrectorTask)


process.ak4CaloL2L3CorrectorChain = cms.Sequence(process.ak4CaloL2L3CorrectorTask)


process.ak4JPTL1L2L3ResidualCorrectorChain = cms.Sequence(process.ak4JPTL1L2L3ResidualCorrectorTask)


process.ak4PFPuppiL1L2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFPuppiL1L2L3ResidualCorrectorTask)


process.ak4PFPuppiL1FastL2L3CorrectorChain = cms.Sequence(process.ak4PFPuppiL1FastL2L3CorrectorTask)


process.ak4PFL1FastL2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFL1FastL2L3ResidualCorrectorTask)


process.extraDumpers = cms.Sequence()


process.ak4L1JPTFastjetCorrectorChain = cms.Sequence(process.ak4L1JPTFastjetCorrectorTask)


process.ak4JPTL1L2L3CorrectorChain = cms.Sequence(process.ak4JPTL1L2L3CorrectorTask)


process.ak4PFPuppiL1FastL2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFPuppiL1FastL2L3ResidualCorrectorTask)


process.ak4PFCHSL2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFCHSL2L3ResidualCorrectorTask)


process.dataRequirements = cms.Sequence()


process.jetSystematicsSequence = cms.Sequence(process.jetCorrectorChain+process.flashggJetSystematics0+process.flashggJetSystematics1+process.flashggJetSystematics2+process.flashggJetSystematics3+process.flashggJetSystematics4+process.flashggJetSystematics5+process.flashggJetSystematics6+process.flashggJetSystematics7+process.flashggJetSystematics8+process.flashggJetSystematics9+process.flashggJetSystematics10+process.flashggJetSystematics11)


process.systematicsTagSequences = cms.Sequence()


process.ak4CaloL1FastL2L3L6CorrectorChain = cms.Sequence(process.ak4CaloL1FastL2L3L6CorrectorTask)


process.flashggHHWWggTagSequence = cms.Sequence(process.flashggHHWWggTag)


process.ak4PFL2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFL2L3ResidualCorrectorTask)


process.ak4PFCHSL2L3CorrectorChain = cms.Sequence(process.ak4PFCHSL2L3CorrectorTask)


process.ak4PFPuppiL1L2L3CorrectorChain = cms.Sequence(process.ak4PFPuppiL1L2L3CorrectorTask)


process.ak4CaloL2L3ResidualCorrectorChain = cms.Sequence(process.ak4CaloL2L3ResidualCorrectorTask)


process.ak4PFCHSL1L2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFCHSL1L2L3ResidualCorrectorTask)


process.ak4PFL2L3CorrectorChain = cms.Sequence(process.ak4PFL2L3CorrectorTask)


process.ak4CaloL1L2L3ResidualCorrectorChain = cms.Sequence(process.ak4CaloL1L2L3ResidualCorrectorTask)


process.ak4CaloL1FastL2L3CorrectorChain = cms.Sequence(process.ak4CaloL1FastL2L3CorrectorTask)


process.ak4PFPuppiL2L3CorrectorChain = cms.Sequence(process.ak4PFPuppiL2L3CorrectorTask)


process.ak4JPTL1FastL2L3CorrectorChain = cms.Sequence(process.ak4JPTL1FastL2L3CorrectorTask)


process.ak4PFL1L2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFL1L2L3ResidualCorrectorTask)


process.flashggTagSequence = cms.Sequence(process.flashggPreselectedDiPhotons+process.flashggDiPhotonMVA+process.flashggHHWWggTagSequence+process.flashggTagSorter)


process.p = cms.Path(process.dataRequirements+process.flashggMetFilters+process.genFilter+process.flashggDiPhotons+process.flashggDifferentialPhoIdInputsCorrection+process.flashggDiPhotonSystematics+process.flashggMetSystematics+process.flashggMuonSystematics+process.flashggElectronSystematics+process.flashggUnpackedJets+process.jetSystematicsSequence+process.flashggTagSequence+process.systematicsTagSequences+process.flashggSystTagMerger+process.penultimateFilter+process.finalFilter+process.tagsDumper)


